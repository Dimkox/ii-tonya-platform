from __future__ import annotations

import copy
import hashlib
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .cost_guard import GATE as PAID_RUN_GATE, prompt_cost_signals
from .risk_terms import has_term, load_vocabulary, uncovered_script
from .repo import RepoProfile, detect_repo
from .util import git_default_base, load_json, now_utc, tree_fingerprint, unique_ordered


INTENT_KEYWORDS: dict[str, tuple[str, ...]] = {
    'incident': ('incident', 'outage', 'авар', 'прод упал', 'production down', 'срочно почин', 'hotfix'),
    'bugfix': ('bug', 'fix', 'repair', 'ошиб', 'баг', 'сломал', 'не работает', 'исправ', 'regression', 'exception', 'fatal'),
    'review': ('review', 'ревью', 'проверь код', 'аудит кода', 'code review', 'pull request', ' pr '),
    'release': ('release', 'релиз', 'deploy', 'деплой', 'publish', 'выкат', 'rollback', 'canary'),
    'test': ('test', 'тест', 'coverage', 'покрытие', 'phpunit', 'cypress', 'playwright'),
    'refactor': ('refactor', 'рефактор', 'legacy', 'легаси', 'модерниз', 'переписать', 'передел'),
    'architecture': ('architecture', 'архитект', 'design system', 'новая подсистема', 'microservice', 'микросервис'),
    'research': ('research', 'исслед', 'разберись', 'проанализируй', 'сравни', 'spike'),
    'feature': ('feature', 'фича', 'добав', 'реализ', 'сделай', 'создай', 'build', 'implement', 'develop'),
    'docs': ('documentation', 'документац', 'readme', 'инструкц', 'описание'),
}

DOMAIN_KEYWORDS: dict[str, tuple[str, ...]] = {
    'bitrix': ('bitrix', 'битрикс', 'd7', 'инфоблок', 'iblock', 'highload', 'hl-блок', 'битрикс24', 'crm bitrix'),
    'php': ('php', 'composer', 'symfony', 'laravel', 'phpunit', 'phpstan'),
    'frontend': ('frontend', 'фронтенд', 'ui', 'интерфейс', 'javascript', 'typescript', 'react', 'vue', 'cypress', 'css'),
    'api': ('api', 'rest', 'graphql', 'endpoint', 'эндпоинт', 'openapi', 'webhook'),
    'event': ('event-driven', 'event', 'событи', 'asyncapi', 'kafka', 'rabbitmq', 'queue', 'очеред'),
    'data': ('sql', 'database', 'база данных', 'миграц', 'clickhouse', 'elasticsearch', 'opensearch', 'postgres', 'mysql', 'индекс'),
    'integration': ('integration', 'интеграц', '1c', '1с', 'sap', 'erp', 'wms', 'bitrix24 rest', 'external system', 'внешн'),
    'ai': ('rag', 'llm', ' ai ', 'искусственный интеллект', 'генеративн', 'нейросет', 'prompt injection', 'embedding', 'vector store', 'ai agent'),
    'infra': ('terraform', 'kubernetes', 'docker', 'ci/cd', 'github actions', 'инфраструктур', 'devops'),
    'security': ('security', 'безопасност', 'auth', 'oauth', 'permission', 'права', 'роль', 'pii', 'персональн', 'secret', 'prompt injection', 'tenant isolation', 'изоляц'),
}

# These explicit word aliases retain security meanings previously found through
# short stems, without matching unrelated words such as author or authority.
# matched_keywords records the canonical configured term, even for an alias.
SECURITY_KEYWORD_ALIASES: dict[str, tuple[str, ...]] = {
    'auth': (
        'authn', 'authz',
        'authenticate', 'authenticates', 'authenticated', 'authenticating',
        'authentication', 'authentications', 'authenticator', 'authenticators',
        'authorize', 'authorizes', 'authorized', 'authorizing',
        'authorization', 'authorizations',
        'authorise', 'authorises', 'authorised', 'authorising',
        'authorisation', 'authorisations',
        'reauthenticate', 'reauthenticates', 'reauthenticated', 'reauthenticating',
        'reauthentication', 'reauthentications',
        'unauthenticated', 'unauthorized', 'unauthorised',
    ),
    'роль': ('ролью',),
}

# The risk vocabulary lives in .getzilla/config/risk-terms/: English base plus language packs
# (getzilla.risk_terms). A trailing "*" in a term matches a word prefix.

FOLLOW_UP_RE = re.compile(
    r'^\s*(?:да|нет|ок|окей|ok|okay|делай|давай|продолжай|продолжи|согласен|согласна|go|go\s+on|continue|next|yes|no'
    r'|и|ну|далее|дальше|и\s+дальше|и\s+что|(?:и\s+)?(?:что|че|чё)\s+дальше|(?:что|че|чё)\s+там(?:\s+ещ[её])?(?:\s+не\s+так)?'
    r'|где\s+(?:результат|pr|пр)|статус|status|what\s+next|what\'s\s+next'
    r'|вариант\s+[abcабв123]|[abcабв123])\s*[.!?…]*\s*$',
    re.IGNORECASE,
)
# Harness envelopes (a finished background command or subagent, a system reminder) arrive as prompts but
# carry no user intent (#185). A prompt made only of them keeps the active route like a short reply.
SYSTEM_ENVELOPE_RE = re.compile(r'<(task-notification|system-reminder)>.*?</\1>', re.DOTALL)
CLOSED_ROUTE_STATUSES = frozenset({'ready', 'released', 'completed', 'cancelled', 'archived'})
FEATURE_LIKE_INTENTS = frozenset({'feature', 'architecture', 'refactor', 'research'})
DEFAULT_ANALYSIS_CAP = 10
_ROUTE_STATE_UNSET = object()

DEFAULT_ROUTING: dict[str, Any] = {
    'schema_version': 1,
    'max_parallel_analysis': DEFAULT_ANALYSIS_CAP,
    'write_roles': [
        'ai_implementer',
        'bitrix_implementer',
        'data_implementer',
        'frontend_implementer',
        'general_implementer',
        'integration_implementer',
        'php_implementer',
    ],
    'analysis_floors': {
        'always': ['repo_explorer'],
        'feature_like': ['task_analyst'],
        'standard': ['architect', 'docs_researcher'],
    },
    'analysis_domain_agents': {
        'bitrix': ['bitrix_architect'],
        'api': ['integration_architect'],
        'event': ['integration_architect'],
        'integration': ['integration_architect'],
        'data': ['data_architect'],
        'ai': ['ai_architect'],
    },
    'review_floors': {
        'delivery': ['code_reviewer'],
        'docs': ['code_reviewer'],
        'review_intent': ['code_reviewer'],
        'release': ['release_reviewer'],
    },
    'review_domain_agents': {
        'bitrix': ['bitrix_reviewer'],
        'data': ['data_reviewer'],
        'security': ['security_reviewer'],
        'ai': ['security_reviewer'],
        'integration': ['security_reviewer'],
    },
    'review_risk_agents': {
        'high': ['security_reviewer', 'release_reviewer'],
    },
}


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if isinstance(item, str) and item.strip()]


def _analysis_cap(config: dict[str, Any]) -> int:
    raw = config.get('max_parallel_analysis', DEFAULT_ANALYSIS_CAP)
    if isinstance(raw, bool) or not isinstance(raw, int) or raw < 1:
        return DEFAULT_ANALYSIS_CAP
    return raw


def load_routing_config(root: Path) -> dict[str, Any]:
    data = load_json(root / '.getzilla/config/routing.json', None)
    merged = copy.deepcopy(DEFAULT_ROUTING)
    if not isinstance(data, dict):
        return merged
    cap = data.get('max_parallel_analysis')
    if isinstance(cap, int) and not isinstance(cap, bool) and cap >= 1:
        merged['max_parallel_analysis'] = cap
    roles = _string_list(data.get('write_roles'))
    if roles:
        merged['write_roles'] = roles
    for key in (
        'analysis_floors',
        'analysis_domain_agents',
        'review_floors',
        'review_domain_agents',
        'review_risk_agents',
    ):
        value = data.get(key)
        if not isinstance(value, dict):
            continue
        base = merged.setdefault(key, {})
        if not isinstance(base, dict):
            merged[key] = value
            continue
        for sub, items in value.items():
            if isinstance(items, list):
                base[str(sub)] = _string_list(items)
    return merged


@dataclass
class Route:
    schema_version: int
    route_id: str
    created_at: str
    session_id: str
    task: str
    intent: str
    domains: list[str]
    task_domains: list[str]
    risk: str
    complexity: str
    repo: dict[str, object]
    base_commit: str | None
    base_fingerprint: str
    primary_skill: str
    workflow_skills: list[str]
    analysis_agents: list[str]
    write_agent: str | None
    review_agents: list[str]
    allowed_agents: list[str]
    quality_profiles: list[str]
    required_evidence: list[str]
    human_gates: list[str]
    delivery_expected: bool
    status: str = 'routed'
    rationale: list[str] = field(default_factory=list)
    matched_keywords: dict[str, list[str]] = field(default_factory=dict)
    delivery_lane: str = 'full'
    risk_assessment: dict[str, object] = field(default_factory=lambda: {'schema_version': 1, 'status': 'provisional'})

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def _score(text: str, mapping: dict[str, tuple[str, ...]]) -> dict[str, int]:
    lowered = f' {text.lower()} '
    scores: dict[str, int] = {}
    for label, keywords in mapping.items():
        score = sum(2 if ' ' in word.strip() else 1 for word in keywords if word in lowered)
        if score:
            scores[label] = score
    return scores


def _has_operational_intent(text: str) -> bool:
    """Recognize bounded EN/RU requests, never grant operational authority.

    Quotes and historical/negative instruction prefixes are context. A current
    command can still target an artifact built in the past or exclude a deploy
    destination. Semicolons/contrast reset instruction scope; comma/and lists
    preserve negation, history and descriptive plan infinitives.
    """
    lowered = text.lower()
    lowered = re.sub(
        r'```[\s\S]*?(?:```|$)|`[^`]*(?:`|$)|"[^"]*(?:"|$)|'
        r'“[^”]*(?:”|$)|«[^»]*(?:»|$)|'
        r"(?<!\w)'(?:[^']|(?<=\w)'(?=\w))*(?:'(?!\w)|$)",
        ' ', lowered,
    )
    request = (
        r'^(?:(?:please|kindly|пожалуйста)\s+)?'
        r'(?:(?:can|could|would|will)\s+you\s+(?:please\s+)?|'
        r'(?:i|we)\s+(?:want|need)\s+(?:you\s+)?to\s+|'
        r'(?:нужно|надо|необходимо|прошу|хочу)\s+(?:тебя\s+)?)?'
    )
    command = re.compile(request + (
        r'(?P<action>release|deploy|publish|rollback|roll\s+back|'
        r'выпусти(?:те)?|выпустить|опубликуй(?:те)?|опубликовать|'
        r'задеплой(?:те)?|задеплоить|разверни(?:те)?|развернуть|'
        r'выкати(?:те)?|выкатить|откати(?:те)?|откатить)\b'
    ))
    prepare = re.compile(request + (
        r'(?:prepare|ship|cut|create|make|run|подготовь(?:те)?|подготовить|'
        r'сделай(?:те)?|сделать|создай(?:те)?|создать|запусти(?:те)?)\s+'
        r'(?:(?:a|the|this|new|production|новый)\s+)*'
        r'(?:release|deployment|canary\s+rollout|релиз)\b'
    ))
    descriptive = re.compile(
        r'^\s*(?:notes?|plans?|checklists?|readiness|workflows?|polic(?:y|ies)|pipelines?|'
        r'process(?:es)?|scripts?|installers?|jobs?|commands?|paths?|guides?|documentation|'
        r'план\w*|чеклист\w*|заметк\w*)\b'
    )
    historical = re.compile(
        r"^\s*(?:yesterday(?!['’]s\b)|previously|historically|"
        r'last\s+(?:week|month|year)|вчера|ранее|исторически)\b|'
        r'^\s*(?:on\s+)?\d{4}-\d{2}-\d{2}\b'
    )
    negative = re.compile(request + (
        r"(?:do\s+not|don['’]t|never|not(?:\s+to)?|no\s+need\s+to|не|нельзя)\b"
    ))
    past_statement = re.compile(
        r'^\s*(?:(?:the|a|this|этот)\s+)?'
        r'(?:(?!(?:that|which|who|котор\w*)\b)[\w.-]+\s+){0,3}'
        r'(?:was|were|has\s+been|had\s+been|был\w*)\b'
    )
    plan_infinitive = re.compile(
        r'\b(?:plans?|checklists?|instructions?)\b.*\bto\s+'
        r'(?:release|deploy|publish|rollback|roll\s+back)\b|'
        r'\bплан(?:а|ы|ов)?\s*:?\s*(?:развернуть|опубликовать|выпустить|'
        r'выкатить|откатить|задеплоить)\b'
    )
    for clause in re.split(r'[;\n!?]|(?<!\d)\.|\.(?!\d)|\b(?:but|however|но|однако|зато)\b', lowered):
        historical_context = False
        negated = False
        plan_context = False
        for part in re.split(r',|\b(?:and(?:\s+then)?|then|и(?:\s+затем)?|затем)\b', clause):
            part = re.sub(r'^\s*(?:now|теперь|сейчас)\s+', '', part).strip()
            historical_context = historical_context or bool(historical.match(part))
            negated = negated or bool(negative.match(part))
            if historical_context or negated or plan_context:
                continue
            match = command.match(part) or prepare.match(part)
            if not match:
                plan_context = bool(plan_infinitive.search(part))
                continue
            tail = part[match.end():]
            if past_statement.match(tail):
                historical_context = True
                continue
            # A direct publish/deploy is an action even when its object is notes;
            # "release notes" and "prepare a release plan" are descriptive nouns.
            if (match.re is prepare or match.group('action') == 'release') and descriptive.match(tail):
                continue
            return True
    return False


LEADING_BUILD = re.compile(
    r'^\s*(?:please\s+|пожалуйста,?\s+)?'
    r'(?:implement|build|create|add|develop|introduce|'
    r'реализ\w*|внедр\w*|добав\w*|созда\w*|разработа\w*|'
    # "Сделай ревью / аудит / исследование" asks for a review, not for a build.
    r'сдела\w*(?!\s+(?:ревью|review|аудит|обзор|исследован|research|анализ)))\b',
    re.IGNORECASE,
)
# Routes without a write owner: a build imperative never lands on them.
PROCESS_INTENTS = frozenset({'review', 'research'})
# A docs route keeps its writer, so it stays docs when the document is the object of the verb.
DOCS_OBJECT_WORDS = 4


def _docs_is_object(text: str, build: re.Match[str]) -> bool:
    head = ' '.join(text[build.end():].split()[:DOCS_OBJECT_WORDS]).lower()
    return any(word in head for word in INTENT_KEYWORDS['docs'])


PASTED_MATERIAL_MIN_CHARS = 1500
_PASTED_MARKERS = (
    re.compile(r'^\s{0,3}#{1,6}\s+\S', re.MULTILINE),           # Markdown heading
    re.compile(r'^\s*(?:```|~~~)', re.MULTILINE),              # fenced code block
    re.compile(r'^\s*\|.*\|\s*$(?:\n^\s*\|.*\|\s*$)+', re.MULTILINE),  # table: two or more rows
)
_LIST_ITEM = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S', re.MULTILINE)


def _is_pasted_material(text: str) -> bool:
    """A long message shaped like a document (a CVE list, a review, a report), not a task.

    Words in such a message describe its subject, so they say little about what the task changes.
    Short task prompts never match, whatever they mention.
    """
    if len(text) < PASTED_MATERIAL_MIN_CHARS:
        return False
    return any(marker.search(text) for marker in _PASTED_MARKERS) or len(_LIST_ITEM.findall(text)) > 10


def _best_intent(text: str, *, operational_intent: bool, pasted: bool = False) -> str:
    scores = _score(text, INTENT_KEYWORDS)
    scores.pop('release', None)
    if re.search(r'\b(?:dated|historical|archive|archives|lessons)\b|истори|архив|урок', text, re.I) and not re.search(r'\b(?:outage|down|unavailable|ongoing)\b|недоступ|авари', text, re.I):
        scores.pop('incident', None)
    if operational_intent:
        scores['release'] = 1
    if not scores:
        return 'feature'

    # Active incidents retain containment priority. Explicit operational requests
    # then outrank defect/review/PR transport; incidental release nouns do not.
    # A task that opens with a build imperative ("Implement ...", "Реализуй ...") is delivery work:
    # later process words ("independent reviews", "research", "documentation") must not turn it
    # into a read-only route without a write owner, or into a lighter docs route.
    build = LEADING_BUILD.match(text)
    for intent in ('incident', 'release', 'bugfix', 'review', 'refactor', 'architecture', 'research', 'docs'):
        if scores.get(intent):
            if pasted and intent == 'incident':
                continue  # pasted material that discusses incidents is not an active incident
            if build and intent in PROCESS_INTENTS:
                continue
            if build and intent == 'docs' and not _docs_is_object(text, build):
                continue
            return intent

    lowered = text.lower().strip()
    test_primary = (
        re.search(
            r'^(?:добав(?:ь|ить)|напиш(?:и|ите)|созда(?:й|йте)|сдела(?:й|йте))\s+'
            r'(?:(?:регрессионн|интеграционн|юнит|unit|e2e|phpunit|cypress|playwright)\w*\s+)*'
            r'(?:тест|tests?|coverage)',
            lowered,
        )
        or re.search(r'^(?:покрой|покрыть)\b.*\b(?:тест|coverage)', lowered)
    )
    if scores.get('test') and (test_primary or not scores.get('feature')):
        return 'test'
    if scores.get('feature') or build:
        return 'feature'
    if scores.get('test'):
        return 'test'
    if pasted:
        scores.pop('incident', None)
    return next(iter(scores), 'feature')


def _matched_domain_keywords(text: str) -> dict[str, list[str]]:
    """Bound short tokens and explicit security aliases; report canonical terms.

    Longer stems and phrases retain their existing substring matching.
    """
    lowered = f' {text.lower()} '
    matches: dict[str, list[str]] = {}
    for domain, keywords in sorted(DOMAIN_KEYWORDS.items()):
        found = []
        for keyword in keywords:
            term = keyword.strip()
            if re.fullmatch(r'\w{1,4}', term):
                aliases = SECURITY_KEYWORD_ALIASES.get(term, ()) if domain == 'security' else ()
                matched = any(_has_term(lowered, word) for word in (term, *aliases))
            else:
                matched = keyword in lowered
            if matched:
                found.append(term)
        if found:
            matches[domain] = sorted(set(found))
    return matches


def _domains(text: str, repo: RepoProfile) -> tuple[list[str], list[str], dict[str, list[str]]]:
    matches = _matched_domain_keywords(text)
    scores = {domain: sum(2 if ' ' in word else 1 for word in words) for domain, words in matches.items()}
    task_domains = sorted(scores, key=lambda domain: (-scores[domain], domain))
    combined = unique_ordered([*task_domains, *repo.domains]) or ['generic']
    return combined, task_domains, matches


def _has_term(text: str, term: str) -> bool:
    """Whole-word term match with "*" word stems (see getzilla.risk_terms.has_term)."""
    return has_term(text, term)


def _risk(text: str, intent: str, domains: list[str]) -> tuple[str, list[str]]:
    rationale: list[str] = []
    try:
        vocabulary = load_vocabulary()
    except (OSError, ValueError) as error:
        # A broken vocabulary must not make every prompt look harmless.
        return 'medium', [f'risk vocabulary unavailable ({str(error)[:120]}); medium-risk floor']
    high = [word for word in vocabulary.high if _has_term(text, word)]
    medium = [word for word in vocabulary.medium if _has_term(text, word)]
    if high or intent in {'incident', 'release'} or 'security' in domains:
        rationale.append('high-risk signal: ' + ', '.join(high[:5]) if high else f'high-risk intent/domain: {intent}')
        return 'high', rationale
    if medium or intent in {'architecture', 'refactor'} or any(d in domains for d in ('integration', 'data', 'api', 'event', 'ai')):
        rationale.append('medium-risk integration, contract, data, AI, or modernization work')
        return 'medium', rationale
    script = uncovered_script(text, vocabulary)
    if script is not None:
        rationale.append(f'PROMPT_LANGUAGE_NOT_COVERED:{script}: no risk-terms pack reads this prompt; medium-risk floor. '
                         'Add one: getzilla risk-terms scaffold --lang <code> --script ' + script)
        return 'medium', rationale
    rationale.append('bounded change without high-risk signals')
    return 'low', rationale


# Explicit task focus on these keeps the full controller even at low risk.
LIGHT_LANE_EXCLUDED_DOMAINS = frozenset({'security', 'ai', 'integration', 'data', 'infra', 'api', 'event'})


def _complexity(intent: str, risk: str, domains: list[str], text: str) -> str:
    if risk == 'high' or intent in {'architecture', 'incident', 'release'} or len(domains) >= 4:
        return 'high-risk'
    if risk == 'low' and intent in {'bugfix', 'docs', 'test'} and len(text) < 300 and len(domains) <= 2:
        return 'micro'
    return 'standard'


def is_system_notice(prompt: str) -> bool:
    """True when the prompt holds harness envelopes and nothing else."""
    text = prompt or ''
    return bool(SYSTEM_ENVELOPE_RE.search(text)) and not SYSTEM_ENVELOPE_RE.sub('', text).strip()


def should_reuse_active_route(prompt: str) -> bool:
    return bool(FOLLOW_UP_RE.match(prompt or '')) or is_system_notice(prompt)


def can_reuse_active_route(prompt: str, existing: dict | None, session_id: str | None) -> bool:
    if not existing or not should_reuse_active_route(prompt):
        return False
    if existing.get('session_id') != session_id:
        return False
    if existing.get('status') in CLOSED_ROUTE_STATUSES:
        return False
    return True


def is_development_prompt(prompt: str, repo: RepoProfile) -> bool:
    if should_reuse_active_route(prompt):
        return False
    scores = _score(prompt, INTENT_KEYWORDS)
    if scores:
        return True
    technical = bool(_matched_domain_keywords(prompt))
    return technical and len(prompt.strip()) > 12


def build_route(
    root: Path,
    prompt: str,
    session_id: str = 'manual',
    *,
    base_commit_override: str | None | object = _ROUTE_STATE_UNSET,
    base_fingerprint_override: str | object = _ROUTE_STATE_UNSET,
) -> Route:
    repo = detect_repo(root)
    operational_intent = _has_operational_intent(prompt)
    pasted = _is_pasted_material(prompt)
    intent = _best_intent(prompt, operational_intent=operational_intent, pasted=pasted)
    domains, task_domains, matched_keywords = _domains(prompt, repo)
    # Risk and size come from what the task is about; a repository that also contains API, data or
    # security code does not make every prompt in it medium. The diff escalates the route later.
    risk, rationale = _risk(prompt, intent, task_domains)
    if pasted and risk == 'high' and not operational_intent:
        # Pasted material names risky subjects without asking to change them; the diff, not its
        # words, decides high risk (verification escalates the route on the exact-head diff).
        risk = 'medium'
        rationale.append('PASTED_MATERIAL: risk words in a pasted document cap at medium; the diff escalates')
    try:
        cost_signal = prompt_cost_signals(prompt)
    except (OSError, ValueError):
        cost_signal = None
    if cost_signal is not None:
        if risk == 'low':
            risk = 'medium'
        rationale.append(cost_signal.rationale)
    complexity = _complexity(intent, risk, task_domains, prompt)

    cfg = load_routing_config(root)
    floors = cfg.get('analysis_floors') if isinstance(cfg.get('analysis_floors'), dict) else {}
    analysis: list[str] = list(_string_list(floors.get('always')))
    feature_like = intent in FEATURE_LIKE_INTENTS
    if feature_like:
        analysis.extend(_string_list(floors.get('feature_like')))
    if complexity != 'micro':
        analysis.extend(_string_list(floors.get('standard')))
    elif feature_like:
        analysis.append('architect')
    domain_agents = cfg.get('analysis_domain_agents') if isinstance(cfg.get('analysis_domain_agents'), dict) else {}
    for domain in domains:
        analysis.extend(_string_list(domain_agents.get(domain)))
    cap = _analysis_cap(cfg)
    analysis = unique_ordered(analysis)[:cap]

    no_write_intents = {'review', 'research', 'release'}
    write_agent: str | None = None
    if intent not in no_write_intents:
        explicit = set(task_domains)
        # Explicit task focus wins over repository background. This matters in
        # polyglot and Bitrix repositories where not every change is a D7 change.
        if 'ai' in explicit:
            write_agent = 'ai_implementer'
        elif 'frontend' in explicit and 'bitrix' not in explicit:
            write_agent = 'frontend_implementer'
        elif 'data' in explicit and 'integration' not in explicit:
            write_agent = 'data_implementer'
        elif any(d in explicit for d in ('integration', 'api', 'event')) and 'bitrix' not in explicit:
            write_agent = 'integration_implementer'
        elif 'bitrix' in explicit or 'bitrix' in repo.domains:
            write_agent = 'bitrix_implementer'
        elif 'php' in explicit or 'php' in repo.domains:
            write_agent = 'php_implementer'
        elif 'frontend' in domains:
            write_agent = 'frontend_implementer'
        else:
            write_agent = 'general_implementer'

    review_floors = cfg.get('review_floors') if isinstance(cfg.get('review_floors'), dict) else {}
    # Intent selects implementation support, not source-risk audits.
    review = ['code_reviewer'] if write_agent or intent in {'review', 'release'} else []
    if review:
        review += _string_list(review_floors.get('delivery'))

    # Low-risk micro and standard work takes the light lane: one analysis agent, one reviewer
    # who also reads the tests, no durable change package. High risk, sensitive task domains,
    # paid or production work keep the full controller; verification still escalates on the diff.
    production = operational_intent or (not pasted and any(
        _has_term(prompt, word) for word in ('production', 'прод', 'deploy', 'деплой')))
    light = (
        risk == 'low' and complexity in {'micro', 'standard'} and write_agent is not None
        and intent not in {'release', 'architecture', 'incident'} and cost_signal is None and not production
        and not set(task_domains) & LIGHT_LANE_EXCLUDED_DOMAINS
    )
    if light:
        # Drop only the generic floors; domain specialists (Bitrix, PHP, frontend) stay.
        generic_analysis = set(_string_list(floors.get('feature_like'))) | set(_string_list(floors.get('standard'))) | {'architect'}
        analysis = [agent for agent in analysis if agent not in generic_analysis
                    or agent in _string_list(floors.get('always'))]
        review = list(_string_list(review_floors.get('light')) or ['code_reviewer']) + review
    delivery_lane = 'light' if light else 'full'

    workflow_skills = ['getzilla-delivery']
    intent_skill = {
        'bugfix': 'bugfix-workflow',
        'incident': 'incident-response',
        'feature': 'feature-workflow',
        'architecture': 'feature-workflow',
        'refactor': 'legacy-modernization',
        'release': 'release-readiness',
        'review': 'verification-evidence',
        'test': 'verification-evidence',
        'research': 'task-triage',
        'docs': 'task-triage',
    }.get(intent, 'feature-workflow')
    workflow_skills.append(intent_skill)
    if operational_intent:
        workflow_skills.append('release-readiness')
    for domain, skill in [
        ('bitrix', 'bitrix-development'),
        ('api', 'api-event-change'),
        ('event', 'api-event-change'),
        ('data', 'data-change'),
        ('integration', 'enterprise-integration'),
        ('frontend', 'frontend-change'),
        ('ai', 'ai-rag-change'),
        ('security', 'security-sensitive-change'),
    ]:
        if domain in domains:
            workflow_skills.append(skill)

    profiles = ['base']
    for domain, profile in [
        ('php', 'php'), ('bitrix', 'bitrix'), ('frontend', 'frontend'),
        ('api', 'contracts'), ('event', 'contracts'), ('data', 'data'),
        ('integration', 'integration'), ('ai', 'ai'), ('infra', 'infra'),
    ]:
        if domain in domains:
            profiles.append(profile)

    evidence: list[str] = []
    if write_agent or intent in {'review', 'release', 'test'}:
        evidence.append('verification')
    if 'code_reviewer' in review:
        evidence.append('code_review')
    if 'test_reviewer' in review:
        evidence.append('test_review')
    if 'bitrix_reviewer' in review:
        evidence.append('bitrix_review')
    if 'security_reviewer' in review:
        evidence.append('security_review')
    if 'data_reviewer' in review:
        evidence.append('data_review')
    if 'release_reviewer' in review:
        evidence.append('release_review')

    human_gates: list[str] = []
    if cost_signal is not None:
        human_gates.append(PAID_RUN_GATE)
    if complexity == 'high-risk' or intent == 'architecture':
        human_gates.append('scope_and_design_approval')
    if any(d in domains for d in ('integration', 'data')) and risk == 'high':
        human_gates.append('migration_or_external_write_approval')
    if production:
        human_gates.append('production_action_approval')

    delivery_expected = intent != 'research'
    base_fingerprint = (
        tree_fingerprint(root)
        if base_fingerprint_override is _ROUTE_STATE_UNSET
        else str(base_fingerprint_override)
    )
    base_commit = (
        git_default_base(root)
        if base_commit_override is _ROUTE_STATE_UNSET
        else base_commit_override
    )
    route_seed = f'{session_id}|{prompt}|{base_fingerprint}'
    route_id = hashlib.sha256(route_seed.encode()).hexdigest()[:12]
    allowed = unique_ordered([*analysis, *(review or []), *([write_agent] if write_agent else [])])

    rationale.extend([
        f'intent={intent}',
        f'domains={",".join(domains)}',
        f'repository={repo.kind}',
        f'write-owner={write_agent or "none"}',
        f'analysis-wave={len(analysis)}/{cap}',
    ])

    return Route(
        schema_version=1,
        route_id=route_id,
        created_at=now_utc(),
        session_id=session_id,
        task=prompt.strip(),
        intent=intent,
        domains=domains,
        task_domains=task_domains,
        matched_keywords=matched_keywords,
        risk=risk,
        complexity=complexity,
        repo=repo.to_dict(),
        base_commit=base_commit if isinstance(base_commit, str) or base_commit is None else None,
        base_fingerprint=base_fingerprint,
        primary_skill='getzilla-delivery',
        workflow_skills=unique_ordered(workflow_skills),
        analysis_agents=unique_ordered(analysis),
        write_agent=write_agent,
        review_agents=unique_ordered(review),
        allowed_agents=allowed,
        quality_profiles=unique_ordered(profiles),
        required_evidence=unique_ordered(evidence),
        human_gates=human_gates,
        delivery_expected=delivery_expected,
        rationale=rationale,
        delivery_lane=delivery_lane,
    )


RISK_ORDER = {'low': 0, 'medium': 1, 'high': 2}
REVIEW_EVIDENCE = {
    'code_reviewer': 'code_review', 'test_reviewer': 'test_review', 'bitrix_reviewer': 'bitrix_review',
    'security_reviewer': 'security_review', 'data_reviewer': 'data_review', 'release_reviewer': 'release_review',
}


def escalate_route(route: dict[str, object], risk: str, root: Path, *, force_full: bool = False) -> dict[str, object]:
    """Reviewers and evidence a route needs at `risk`; only ever adds to the route, never removes.

    The prompt decided the route's risk; the exact-head diff may show more. At high risk the route
    gets the configured high-risk and release reviewers, exactly as if the prompt had said so.
    """
    route_risk = str(route.get('risk') or 'low')
    effective = risk if RISK_ORDER.get(risk, 0) > RISK_ORDER.get(route_risk, 0) else route_risk
    reviewers = [str(item) for item in route.get('review_agents') or []]
    evidence = [str(item) for item in route.get('required_evidence') or []]
    added_reviewers: list[str] = []
    if route.get('delivery_lane') == 'light' and (force_full or effective != 'low'):
        cfg = load_routing_config(root)
        floors = cfg.get('review_floors') or {}
        added_reviewers.extend(agent for agent in _string_list(floors.get('delivery')) if agent not in reviewers)
    added_evidence = [REVIEW_EVIDENCE[agent] for agent in added_reviewers
                      if agent in REVIEW_EVIDENCE and REVIEW_EVIDENCE[agent] not in evidence]
    return {'route_risk': route_risk, 'effective_risk': effective,
            'review_agents': unique_ordered([*reviewers, *added_reviewers]),
            'required_evidence': unique_ordered([*evidence, *added_evidence]),
            'added_reviewers': added_reviewers, 'added_evidence': added_evidence}


def trivial_waiver(route: dict[str, object], effective_risk: str, profile: str, root: Path) -> list[str]:
    """Evidence a proven-trivial change no longer needs: delivery-floor reviews beyond the trivial floor.

    Only when the exact-head diff is prose-only (`profile == 'trivial'`) and nothing raised the risk
    above low. Verification and at least one independent review always stay; risk and domain
    reviews are never waived.
    """
    if profile != 'trivial' or effective_risk != 'low' or str(route.get('risk') or 'low') != 'low':
        return []
    cfg = load_routing_config(root)
    floors = cfg.get('review_floors') if isinstance(cfg.get('review_floors'), dict) else {}
    trivial = set(_string_list(floors.get('trivial'))) or {'code_reviewer'}
    delivery = _string_list(floors.get('delivery'))
    waivable = {REVIEW_EVIDENCE[agent] for agent in delivery if agent not in trivial and agent in REVIEW_EVIDENCE}
    kept_reviews = {REVIEW_EVIDENCE[agent] for agent in trivial if agent in REVIEW_EVIDENCE}
    required = [str(item) for item in route.get('required_evidence') or []]
    if not kept_reviews & set(required):
        return []  # never leave a route without an independent review
    return [kind for kind in required if kind in waivable]


def route_context(route: Route | dict[str, object]) -> str:
    data = route.to_dict() if isinstance(route, Route) else route
    analysis = ', '.join(data.get('analysis_agents', [])) or 'none'
    reviews = ', '.join(data.get('review_agents', [])) or 'none'
    skills = ', '.join(f'${name}' for name in data.get('workflow_skills', []))
    gates = ', '.join(data.get('human_gates', [])) or 'none'
    return (
        'ADAPTIVE GROK ROUTE\n'
        f"Route ID: {data.get('route_id')}\n"
        f"Intent: {data.get('intent')} | Risk: {data.get('risk')} | Complexity: {data.get('complexity')} "
        f"| Lane: {data.get('delivery_lane', 'full')}\n"
        f"Domains: {', '.join(data.get('domains', []))} (task focus: {', '.join(data.get('task_domains', [])) or 'repository default'})\n"
        f"Required skills: {skills}\n"
        f"Parallel read-only analysis agents: {analysis}\n"
        f"Single write owner: {data.get('write_agent') or 'none'}\n"
        f"Parallel review agents after implementation: {reviews}\n"
        f"Quality profiles: {', '.join(data.get('quality_profiles', []))}\n"
        f"Human gates: {gates}\n"
        'Use /getzilla-delivery. Do not spawn agents outside the route. '
        'Run every listed read-only analysis agent in parallel (cap is a ceiling, not a quota). '
        'Keep exactly one write owner.'
        + (' Paid or unbounded operation: put cost-contract.json (provider, max_calls, max_spend_usd_cents, stop_condition, '
           'alert, limit_symbol) in the change package, test the limit, and do not run it live before paid_run_approval.'
           if PAID_RUN_GATE in data.get('human_gates', []) else '')
    )
