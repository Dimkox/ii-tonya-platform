from __future__ import annotations

import ast
from collections import deque
import hashlib
import json
import re
import sys
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Mapping, NamedTuple

from .architecture import (
    ArchitectureError,
    ArchitectureSnapshot,
    SCHEMA_REFERENCE_AMBIGUOUS,
    SCHEMA_REFERENCE_ID_FIRST,
    SCHEMA_REFERENCE_PATH_FIRST,
    SCHEMA_REFERENCE_UNRESOLVED,
    SCHEMA_REFERENCE_UNSAFE,
    architecture_digests,
    compare_contracts,
    contract_inventory_digest,
    load_architecture,
    schema_reference_identity_path,
    schema_reference_parts,
    schema_reference_target_path,
)
from .architecture_diff import (
    ADOPTION_BASE_SHA,
    ArchitectureChange,
    ArchitectureDiff,
    ChangedArtifact,
    diff_architecture,
    git_tree_paths,
    read_diff_file,
    read_diff_files,
)
from .queue_provenance import QueueAnalysisLimit, analyze_queue_tree, literal_patch_members, _CONTAINER_MUTATORS

FITNESS_CATEGORIES = (
    "background_job",
    "change_separation",
    "code_budget",
    "contract_compatibility",
    "forbidden_edge",
    "governance_promotion",
    "migration_safety",
    "module_boundary",
    "network_client",
    "production_import",
    "secret_flow",
    "tenant_authorization",
    "workspace_trust",
)
RISK_ORDER = {"green": 0, "yellow": 1, "red": 2}
MAX_ANALYZED_PYTHON_FILES = 2_000
MAX_ANALYZED_AST_NODES = 200_000
MAX_QUEUE_ADAPTER_MODULES = 48
MAX_QUEUE_ANALYSIS_BYTES = 2 * 1024 * 1024
MAX_QUEUE_ANALYSIS_AST_NODES = 400_000
MAX_QUEUE_ANALYSIS_WORK = 4096
QUEUE_PROJECTION_WORK_NODES = 128
MAX_QUEUE_ADAPTER_DEPTH = 8
MAX_QUEUE_SOURCE_ROOTS = 64
MAX_QUEUE_DEPENDENCY_WORK = 4_096
MAX_MIGRATION_WORK = 4_096
MAX_MIGRATION_FINDINGS = 256
MAX_MIGRATION_BATCH_PATHS = 8
MAX_MIGRATION_BYTES = 8 * 1024 * 1024
MAX_MIGRATION_STATEMENTS = 4_096
_PYTHON_SUFFIXES = {".py", ".pyi"}
_NETWORK_IMPORTS = {
    "aiohttp": "https",
    "docker": "docker_api",
    "ftplib": "ftp",
    "http.client": "https",
    "httpx": "https",
    "imaplib": "imap",
    "poplib": "pop3",
    "psycopg": "postgresql",
    "psycopg2": "postgresql",
    "requests": "https",
    "smtplib": "smtp",
    "socket": "tcp",
    "urllib": "https",
    "urllib.request": "https",
    "xmlrpc.client": "https",
}
_NETWORK_APPLICABILITY_TOKENS = {
    "connect",
    "connection",
    "ftp",
    "grpc",
    "http",
    "https",
    "imap",
    "network",
    "paramiko",
    "pop",
    "request",
    "smtp",
    "socket",
    "ssh",
    "tls",
    "urlopen",
    "websocket",
    "websockets",
}
_CLOUD_SDK_NETWORK_FACTORIES = {
    "boto3": {"client", "resource", "session"},
    "botocore": {"client", "create_client", "get_session", "session"},
}
_QUEUE_IMPORTS = {"celery", "confluent_kafka", "kafka", "kombu", "pika", "queue", "redis", "rq"}
_QUEUE_ADAPTER_MODULE_TOKENS = {
    *_QUEUE_IMPORTS,
    "background",
    "job",
    "jobs",
    "task",
    "tasks",
    "worker",
    "workers",
}
_FRAMEWORK_IMPORTS = {"django", "fastapi", "flask", "litestar", "starlette"}
_GOVERNANCE_IMPORTS = {"getzilla", "architecture", "engineering", "scripts", "tests"}
_GOVERNANCE_PATHS = (".grok", ".getzilla", "architecture", "docs", "engineering", "scripts", "tests")
_GOVERNANCE_FITNESS_PATHS = (
    ".getzilla/getzilla/governance.py",
    "schemas/canonical-example.schema.json",
    "schemas/debt-entry.schema.json",
    "schemas/governance-rule.schema.json",
    "scripts/getzilla_governance.py",
)
_GOVERNANCE_REGISTRIES = (
    ("governance/canonical-examples/index.json", "examples"),
    ("governance/debt/index.json", "entries"),
    ("governance/rules/index.json", "rules"),
)
_GOVERNANCE_SCHEMA_PATHS = (
    "schemas/canonical-example.schema.json",
    "schemas/debt-entry.schema.json",
    "schemas/governance-rule.schema.json",
)
_GOVERNANCE_SCHEMA_DIGESTS = {
    "schemas/canonical-example.schema.json": "1b32818fae37b2f6fbab1855d90e7edefb90f28c6491b661b47afcf4d438a846",
    "schemas/debt-entry.schema.json": "6eec2d5a9d1f465be38796c08cb5639c27452aa717d0e3eada5706904d533f42",
    "schemas/governance-rule.schema.json": "4c5f7c11d37aa330c3596ab423762c71c7eb259e7cfea3aba3f506cc4525382f",
}
_GOVERNANCE_HANDOFF_SCHEMA = "schemas/governance-handoff-v1.schema.json"
_GOVERNANCE_HANDOFF_SCHEMA_DIGEST = (
    "3527385869bc73f628e1dc0e22025d3e54b7e3972aba3703f9b579146a8c80ba"
)
_GOVERNANCE_PROJECTIONS = {"decisions.md", "mistakes.md"}
_GOVERNANCE_VERSION = 1
_MAX_GOVERNANCE_NODES = 100_000
_MAX_GOVERNANCE_DEPTH = 64
_MIGRATION_CANONICAL = re.compile(r"^(?P<group>00(?:1_schema|2_operational_indexes|3_database_roles))$")
_MIGRATION_PHASE = re.compile(r"^(?P<group>.+?)[_-](?P<phase>expand|migrate|contract)(?:[_-].*)?$")
# Raw SHA-256 pins originate only from independent review of frozen actual SQL.
# Reviewed source bacb5346a95d25166e1f7c597b3f91bd5935c234; provenance is
# engineering/changes/20261005-task-249e86/evidence/reviewed-sql-pin-provenance.md.
# Forward 005 source 1f48c4ccc84192780395b18957ba8c9779e30f00; provenance is
# engineering/changes/20261005-task-249e86/evidence/forward-005-pin-provenance.md.
# Callers, environment and CLI supply no authority or semantic phase proof.
_REVIEWED_TRUST_CI_MIGRATIONS: dict[str, str] = {
    "trust-ci/sql/004_public_admission.sql":
        "610b8fa6b759c69578bc18b007484db1c4e19cba5f613c7bd482e68badac646e",
    "trust-ci/sql/005_public_pending_bootstrap.sql":
        "19b5aa4a0400ba4fae605a0f0b89d77c448c222a20089d39ebfb86f84958cd03",
}
_PUBLIC_MIGRATION_PRIMARY = "trust-ci/sql/004_public_admission.sql"
_PUBLIC_MIGRATION_MIRROR = "trust-ci/src/adaptive_trust_ci/resources/004_public_admission.sql"
_PUBLIC_MIGRATION_MIRRORS = {
    _PUBLIC_MIGRATION_PRIMARY: _PUBLIC_MIGRATION_MIRROR,
    "trust-ci/sql/005_public_pending_bootstrap.sql":
        "trust-ci/src/adaptive_trust_ci/resources/005_public_pending_bootstrap.sql",
}
_PUBLIC_WORKER_SOURCES = frozenset(
    f"trust-ci/src/adaptive_trust_ci/{filename}" for filename in (
        "public_models.py", "public_admission.py", "public_policy.py", "source_safety.py",
        "public_storage.py", "public_checkout.py", "public_runner.py",
    )
)
_PUBLIC_CONTRACT_BINDINGS = (
    ("github-public-lifecycle-projection", "CONTRACT-GITHUB-PUBLIC-LIFECYCLE-PROJECTION",
     "NODE-TRUST-CI-API", "json_schema", "consumer", "consumer_accepts_old", ("api.py", "webhooks.py")),
    ("trust-ci-public-profile-selection", "CONTRACT-TRUST-CI-PUBLIC-PROFILE-SELECTION",
     "NODE-TRUST-CI-WORKER", "json_schema", "consumer", "consumer_accepts_old", ("public_policy.py",)),
    ("trust-ci-public-effective-policy", "CONTRACT-TRUST-CI-PUBLIC-EFFECTIVE-POLICY",
     "NODE-TRUST-CI-WORKER", "json_schema", "bidirectional", "bidirectional", ("public_policy.py",)),
    ("trust-ci-public-attestation-envelope", "CONTRACT-TRUST-CI-PUBLIC-ATTESTATION-ENVELOPE",
     "NODE-TRUST-CI-WORKER", "signed_payload", "producer", "producer_accepted_by_old", ("public_runner.py",)),
)


def _canonical_bytes(value: Any) -> bytes:
    return (
        json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("ascii")


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _matches(path: str, prefixes: Iterable[str]) -> bool:
    return any(path == prefix or path.startswith(prefix + "/") for prefix in prefixes)


def _is_governance_or_test_path(path: str) -> bool:
    return _matches(path, _GOVERNANCE_PATHS) or "tests" in PurePosixPath(path).parts[:-1]


@dataclass(frozen=True)
class ApplicabilityEvidence:
    predicate: str
    scanned_scope: tuple[str, ...]
    reason_code: str
    inventory_digest: str


@dataclass(frozen=True)
class FitnessResult:
    category: str
    status: str
    rule_ids: tuple[str, ...]
    findings: tuple[str, ...]
    applicability: ApplicabilityEvidence


@dataclass(frozen=True)
class FitnessReport:
    results: tuple[FitnessResult, ...]
    status: str
    pre_risk: str
    escalation: str
    post_risk: str
    triggers: tuple[str, ...]
    exemption_state: str
    required_scopes: tuple[str, ...]
    evidence_digest: str


class _QueueProvenanceResult(NamedTuple):
    state: str
    reason: str
    signals: tuple[str, ...]
    paths: tuple[str, ...] = ()
    limits: tuple[tuple[str, str, str], ...] = ()


class _QueueSourceFootprint(NamedTuple):
    path: str
    digest: str
    size: int
    nodes: int = 0


class _QueueFootprint(NamedTuple):
    side: str
    sources: tuple[_QueueSourceFootprint, ...] = ()
    work: tuple[tuple[str, int], ...] = ()


class _QueueBudget:
    """One importer/side ledger; cache reuse cannot remove logical charges."""

    def __init__(self, side: str) -> None:
        self.side = side
        self.sources: dict[tuple[str, str], _QueueSourceFootprint] = {}
        self.work: dict[str, int] = {}
        self.frames: list[dict[str, Any]] = []
        self.source_bytes = self.ast_nodes = self.logical_work = self.actual_work = 0
        self.summary_work = 0
        self.root_steps = 0

    def source(self, path: str, value: bytes, nodes: int = 0) -> None:
        self._source(_QueueSourceFootprint(path, hashlib.sha256(value).hexdigest(), len(value), nodes))

    def _source(self, item: _QueueSourceFootprint) -> None:
        key = (item.path, item.digest)
        previous = self.sources.get(key)
        # Every inspected source counts, including the importer, declarations
        # and transitive cache hits. Cache warmth cannot change admission.
        if previous is None and len({source.path for source in self.sources.values()} | {item.path}) > MAX_QUEUE_ADAPTER_MODULES:
            raise ArchitectureError('queue adapter module limit exceeded', code='limit')
        byte_total = self.source_bytes + (0 if previous else item.size)
        node_total = self.ast_nodes + max(0, item.nodes - (previous.nodes if previous else 0))
        if byte_total > MAX_QUEUE_ANALYSIS_BYTES:
            raise ArchitectureError('queue aggregate source byte limit exceeded', code='limit')
        if node_total > MAX_QUEUE_ANALYSIS_AST_NODES:
            raise ArchitectureError('queue aggregate AST node limit exceeded', code='limit')
        self.source_bytes, self.ast_nodes = byte_total, node_total
        self.sources[key] = item._replace(nodes=max(item.nodes, previous.nodes if previous else 0))
        for frame in self.frames:
            existing = frame['sources'].get(key)
            frame['sources'][key] = item._replace(nodes=max(item.nodes, existing.nodes if existing else 0))

    def _work(self, key: str, cost: int) -> None:
        total = self.logical_work + max(0, cost - self.work.get(key, 0))
        if total > MAX_QUEUE_ANALYSIS_WORK:
            raise ArchitectureError('queue aggregate work limit exceeded', code='limit')
        self.logical_work = total
        self.work[key] = max(cost, self.work.get(key, 0))
        for frame in self.frames:
            frame['work'][key] = max(cost, frame['work'].get(key, 0))

    def step(self, *, request: bool = False, cost: int = 1) -> None:
        self.actual_work += cost
        if not request:
            self.summary_work += cost
            if self.summary_work > MAX_QUEUE_ANALYSIS_WORK:
                raise ArchitectureError('queue aggregate work limit exceeded', code='limit')
        if self.frames:
            frame = self.frames[-1]
            frame['own'] += cost
            self._work(frame['key'], frame['own'])
        else:
            self.root_steps += cost
            self._work('importer', self.root_steps)

    def enter(self, key: str) -> dict[str, Any]:
        frame: dict[str, Any] = {'key': key, 'own': 0, 'sources': {}, 'work': {}}
        self.frames.append(frame)
        return frame

    def leave(self, frame: dict[str, Any]) -> _QueueFootprint:
        if not self.frames or self.frames[-1] is not frame:
            raise ArchitectureError('queue work ledger scope mismatch', code='fitness')
        self.frames.pop()
        return _QueueFootprint(self.side, tuple(sorted(frame['sources'].values())), tuple(sorted(frame['work'].items())))

    def merge(self, footprint: _QueueFootprint | None) -> None:
        if footprint is None:
            return
        if footprint.side != self.side:
            raise ArchitectureError('queue source cache side mismatch', code='fitness')
        for source in footprint.sources:
            self._source(source)
        for key, cost in footprint.work:
            self._work(key, cost)


class _QueueAdapterResolution(NamedTuple):
    state: str
    reason: str
    exports: tuple[str, ...] = ()
    signals: tuple[str, ...] = ()
    declared_exports: tuple[str, ...] = ()
    sources: tuple[tuple[str, bytes, str], ...] = ()
    modules: frozenset[str] = frozenset()
    height: int = 1
    footprint: _QueueFootprint | None = None


class _QueueResolutionCache(NamedTuple):
    modules: tuple[str, ...]
    paths: tuple[str, ...]
    values: dict[str, _QueueAdapterResolution]
    demands: dict[tuple[str, frozenset[str] | None, bool], _QueueAdapterResolution]


class _QueueAdapterNamesResult(NamedTuple):
    names: frozenset[str]
    unsupported: bool
    modules: frozenset[str] = frozenset()
    height: int = 0


class _OperationDependencies(NamedTuple):
    names: frozenset[str]
    frontier: frozenset[str] = frozenset()
    frontier_imports: frozenset[str] = frozenset()
    exhausted: bool = False


def _applicability(predicate: str, scope: Iterable[str], reason_code: str) -> ApplicabilityEvidence:
    scanned = tuple(sorted(set(scope)))
    return ApplicabilityEvidence(
        predicate=predicate,
        scanned_scope=scanned,
        reason_code=reason_code,
        inventory_digest=_digest({"predicate": predicate, "scope": scanned}),
    )


def _result(
    category: str,
    *,
    status: str,
    rules: Iterable[str] = (),
    findings: Iterable[str] = (),
    predicate: str,
    scope: Iterable[str] = (),
    reason: str = "applicable",
) -> FitnessResult:
    if category not in FITNESS_CATEGORIES or status not in {
        "pass",
        "fail",
        "not_applicable",
        "unsupported",
    }:
        raise ArchitectureError("invalid fitness result", code="fitness")
    return FitnessResult(
        category=category,
        status=status,
        rule_ids=tuple(sorted(set(rules))),
        findings=tuple(sorted(set(findings))),
        applicability=_applicability(predicate, scope, reason),
    )


def _not_applicable(
    category: str, predicate: str, scope: Iterable[str], reason: str, rules: Iterable[str] = ()
) -> FitnessResult:
    return _result(
        category,
        status="not_applicable",
        rules=rules,
        predicate=predicate,
        scope=scope,
        reason=reason,
    )


def _model_changed(diff: ArchitectureDiff) -> bool:
    return diff.baseline_introduced or bool(diff.changes)


def _governance_path(path: str) -> bool:
    return _matches(path, ("governance",)) or path in _GOVERNANCE_FITNESS_PATHS


def _parse_governance_json(value: bytes | None, *, path: str) -> dict[str, Any]:
    if value is None:
        raise ArchitectureError(f"required governance document is missing: {path}", code="missing")

    def pairs(items: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, item in items:
            if key in result:
                raise ArchitectureError(
                    f"duplicate JSON key in governance document {path}: {key}",
                    code="schema",
                )
            result[key] = item
        return result

    def invalid_constant(constant: str) -> None:
        raise ArchitectureError(
            f"non-finite number in governance document {path}: {constant}",
            code="schema",
        )

    try:
        text = value.decode("utf-8")
        if text.startswith("\ufeff"):
            raise ArchitectureError(
                f"UTF-8 BOM is forbidden in governance document {path}", code="schema"
            )
        document = json.loads(
            text,
            object_pairs_hook=pairs,
            parse_constant=invalid_constant,
        )
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ArchitectureError(
            f"invalid governance JSON document {path}: {exc}", code="schema"
        ) from exc
    if not isinstance(document, dict):
        raise ArchitectureError(f"governance document must be an object: {path}", code="schema")

    nodes = 0
    stack: list[tuple[Any, int]] = [(document, 1)]
    while stack:
        item, depth = stack.pop()
        nodes += 1
        if nodes > _MAX_GOVERNANCE_NODES or depth > _MAX_GOVERNANCE_DEPTH:
            raise ArchitectureError(f"governance document exceeds limits: {path}", code="limit")
        if isinstance(item, dict):
            stack.extend((child, depth + 1) for child in item.values())
        elif isinstance(item, list):
            stack.extend((child, depth + 1) for child in item)
    return document


def _governance_registry(
    document: dict[str, Any], *, path: str, collection: str
) -> tuple[int, dict[str, dict[str, Any]]]:
    if set(document) != {"schema_version", "governance_id", collection}:
        raise ArchitectureError(f"unsupported governance registry shape: {path}", code="schema")
    version = document["schema_version"]
    if not isinstance(version, int) or isinstance(version, bool):
        raise ArchitectureError(f"unsupported governance schema version: {path}", code="version")
    if document["governance_id"] != "GOV-ADAPTIVE-GROK-M3":
        raise ArchitectureError(f"unsupported governance identity: {path}", code="version")
    records = document[collection]
    if not isinstance(records, list):
        raise ArchitectureError(f"unsupported governance registry collection: {path}", code="schema")
    identity_key = {
        "rules": "rule_id",
        "entries": "debt_id",
        "examples": "example_id",
    }[collection]
    indexed: dict[str, dict[str, Any]] = {}
    for record in records:
        if not isinstance(record, dict) or not isinstance(record.get(identity_key), str):
            raise ArchitectureError(f"unsupported governance record shape: {path}", code="schema")
        identity = record[identity_key]
        if identity in indexed:
            raise ArchitectureError(f"duplicate governance record identity: {identity}", code="schema")
        indexed[identity] = record
    return version, indexed


def _schema_version(document: dict[str, Any], *, path: str) -> int:
    try:
        value = document["properties"]["schema_version"]["const"]
    except (KeyError, TypeError) as exc:
        raise ArchitectureError(f"unsupported governance schema contract: {path}", code="schema") from exc
    if not isinstance(value, int) or isinstance(value, bool):
        raise ArchitectureError(f"unsupported governance schema contract: {path}", code="schema")
    return value


def _handoff_shape_matches(document: dict[str, Any]) -> bool:
    return _digest(document) == _GOVERNANCE_HANDOFF_SCHEMA_DIGEST


def _activation_findings(
    before: dict[str, dict[str, Any]], head: dict[str, dict[str, Any]]
) -> tuple[str, ...]:
    findings: list[str] = []
    for rule_id, prior in before.items():
        current = head.get(rule_id)
        if prior.get("status") == "active" and current is None:
            findings.append(f"{rule_id}: active rule deletion requires an explicit revocation")

    for rule_id, rule in head.items():
        prior = before.get(rule_id)
        promoted = rule.get("status") == "active" and (
            prior is None or prior.get("status") != "active" or prior != rule
        )
        if not promoted:
            continue
        author = rule.get("author")
        author_id = author.get("actor_id") if isinstance(author, dict) else None
        reviewers = rule.get("reviewed_by")
        independent_review = isinstance(reviewers, list) and any(
            isinstance(reviewer, dict)
            and reviewer.get("actor_kind") in {"human", "system"}
            and reviewer.get("actor_id") != author_id
            for reviewer in reviewers
        )
        approvals = rule.get("approved_by")
        independent_approval = isinstance(approvals, list) and any(
            isinstance(approval, dict)
            and approval.get("actor_kind") == "human"
            and approval.get("scope") == "governance"
            and approval.get("actor_id") != author_id
            for approval in approvals
        )
        evidence = rule.get("evidence")
        evidence_paths = {
            item.get("path")
            for item in evidence
            if isinstance(item, dict) and isinstance(item.get("path"), str)
        } if isinstance(evidence, list) else set()
        if not independent_review or not independent_approval or not evidence_paths:
            findings.append(
                f"{rule_id}: activation requires independent review, human governance approval, and evidence"
            )
        if evidence_paths and evidence_paths <= _GOVERNANCE_PROJECTIONS:
            findings.append(f"{rule_id}: projection-only evidence cannot supply governance authority")
        findings.append(f"{rule_id}: external exact-record governance authority is required")
    return tuple(sorted(findings))


def _governance_record_deletion_findings(
    base_debt: dict[str, dict[str, Any]],
    head_debt: dict[str, dict[str, Any]],
    base_examples: dict[str, dict[str, Any]],
    head_examples: dict[str, dict[str, Any]],
) -> tuple[str, ...]:
    findings: list[str] = []
    for debt_id, prior in base_debt.items():
        if debt_id in head_debt:
            continue
        if prior.get("status") in {"open", "repaying"}:
            findings.append(
                f"{debt_id}: live debt deletion requires an explicit terminal record"
            )
        else:
            findings.append(
                f"{debt_id}: terminal debt history must remain explicitly represented"
            )
    for example_id, prior in base_examples.items():
        if prior.get("status") == "active" and example_id not in head_examples:
            findings.append(
                f"{example_id}: active example deletion requires an explicit deprecated or revoked record"
            )
    return tuple(sorted(findings))


def _governance_promotion(root: Path, diff: ArchitectureDiff) -> FitnessResult:
    predicate = (
        "governance/**, the three governance registry schemas, governance.py, or "
        "getzilla_governance.py changed"
    )
    governed_scope = (*_GOVERNANCE_FITNESS_PATHS, "governance/**")
    applicable = tuple(path for path in diff.changed_paths if _governance_path(path))
    if not applicable:
        return _not_applicable(
            "governance_promotion",
            predicate,
            governed_scope,
            "governance_paths_unchanged",
            ("FIT-GOVERNANCE-PROMOTION",),
        )

    required_paths = tuple(
        sorted(
            {
                *(path for path, _collection in _GOVERNANCE_REGISTRIES),
                *_GOVERNANCE_SCHEMA_PATHS,
                _GOVERNANCE_HANDOFF_SCHEMA,
            }
        )
    )
    try:
        base_values = read_diff_files(root, diff, required_paths, side="base")
        head_values = read_diff_files(root, diff, required_paths, side="head")
        base_rules: dict[str, dict[str, Any]] = {}
        head_rules: dict[str, dict[str, Any]] = {}
        base_debt: dict[str, dict[str, Any]] = {}
        head_debt: dict[str, dict[str, Any]] = {}
        base_examples: dict[str, dict[str, Any]] = {}
        head_examples: dict[str, dict[str, Any]] = {}
        findings: list[str] = []
        for path, collection in _GOVERNANCE_REGISTRIES:
            head_version, head_records = _governance_registry(
                _parse_governance_json(head_values[path], path=path),
                path=path,
                collection=collection,
            )
            if base_values[path] is None:
                base_version, base_records = head_version, {}
            else:
                base_version, base_records = _governance_registry(
                    _parse_governance_json(base_values[path], path=path),
                    path=path,
                    collection=collection,
                )
            if head_version < base_version:
                findings.append(
                    f"{path}: governance schema downgrade {base_version} -> {head_version}"
                )
            elif base_version != _GOVERNANCE_VERSION or head_version != _GOVERNANCE_VERSION:
                raise ArchitectureError(
                    f"unknown governance schema version in {path}", code="version"
                )
            if collection == "rules":
                base_rules = base_records
                head_rules = head_records
            elif collection == "entries":
                base_debt = base_records
                head_debt = head_records
            elif collection == "examples":
                base_examples = base_records
                head_examples = head_records

        for path in _GOVERNANCE_SCHEMA_PATHS:
            head_schema = _parse_governance_json(head_values[path], path=path)
            base_schema = (
                head_schema
                if base_values[path] is None
                else _parse_governance_json(base_values[path], path=path)
            )
            head_version = _schema_version(head_schema, path=path)
            base_version = _schema_version(base_schema, path=path)
            if head_version < base_version:
                findings.append(
                    f"{path}: governance schema downgrade {base_version} -> {head_version}"
                )
            elif base_version != _GOVERNANCE_VERSION or head_version != _GOVERNANCE_VERSION:
                raise ArchitectureError(
                    f"unknown governance schema version in {path}", code="version"
                )
            expected_digest = _GOVERNANCE_SCHEMA_DIGESTS[path]
            if _digest(base_schema) != expected_digest:
                findings.append(f"{path}: base does not match the frozen v1 contract")
            if _digest(head_schema) != expected_digest:
                findings.append(f"{path}: head does not match the frozen v1 contract")

        handoff = _parse_governance_json(
            head_values[_GOVERNANCE_HANDOFF_SCHEMA], path=_GOVERNANCE_HANDOFF_SCHEMA
        )
        if not _handoff_shape_matches(handoff):
            findings.append("governance handoff does not match the frozen v1 contract")
        findings.extend(_activation_findings(base_rules, head_rules))
        findings.extend(
            _governance_record_deletion_findings(
                base_debt, head_debt, base_examples, head_examples
            )
        )
    except ArchitectureError as exc:
        return _result(
            "governance_promotion",
            status="unsupported",
            rules=("FIT-GOVERNANCE-PROMOTION",),
            findings=(f"unsupported governance analysis: {exc}",),
            predicate=predicate,
            scope=(*governed_scope, *applicable),
            reason="unsupported_governance_semantics",
        )
    return _result(
        "governance_promotion",
        status="fail" if findings else "pass",
        rules=("FIT-GOVERNANCE-PROMOTION",),
        findings=findings,
        predicate=predicate,
        scope=(*governed_scope, *applicable),
    )


def _forbidden_edges(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["forbidden_edges"]
    predicate = "forbidden edge rules exist and the architecture model changed"
    if not rules:
        return _not_applicable("forbidden_edge", predicate, (), "no_declared_rules")
    if not _model_changed(diff):
        return _not_applicable(
            "forbidden_edge", predicate, (), "architecture_unchanged", (rule["id"] for rule in rules)
        )
    nodes = {node["id"]: node for node in snapshot.system["nodes"]}
    findings = []
    for rule in rules:
        for edge in snapshot.system["edges"]:
            if (
                nodes[edge["from"]]["trust_domain"] in rule["from_trust_domains"]
                and nodes[edge["to"]]["trust_domain"] in rule["to_trust_domains"]
                and edge["type"] in rule["edge_types"]
            ):
                findings.append(f"{rule['id']}: forbidden edge {edge['id']}")
    return _result(
        "forbidden_edge",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=(edge["id"] for edge in snapshot.system["edges"]),
    )


def _python_paths(diff: ArchitectureDiff) -> tuple[str, ...]:
    paths = tuple(
        artifact.path
        for artifact in diff.artifacts
        if PurePosixPath(artifact.path).suffix in _PYTHON_SUFFIXES and artifact.status != "deleted"
    )
    if len(paths) > MAX_ANALYZED_PYTHON_FILES:
        raise ArchitectureError("Python analysis file limit exceeded", code="limit")
    return paths


class _PythonInventory:
    def __init__(self, root: Path, diff: ArchitectureDiff) -> None:
        self.root = root
        self.diff = diff
        self._trees: dict[str, ast.AST | SyntaxError] = {}

    def tree(self, path: str) -> ast.AST:
        cached = self._trees.get(path)
        if isinstance(cached, SyntaxError):
            raise cached
        if cached is not None:
            return cached
        value = read_diff_file(self.root, self.diff, path)
        if value is None:
            error = SyntaxError("source is unavailable")
            self._trees[path] = error
            raise error
        try:
            text = value.decode("utf-8")
            tree = ast.parse(text, filename=path)
        except (UnicodeDecodeError, SyntaxError) as exc:
            error = SyntaxError(str(exc))
            self._trees[path] = error
            raise error
        if sum(1 for _ in ast.walk(tree)) > MAX_ANALYZED_AST_NODES:
            raise ArchitectureError(f"Python AST node limit exceeded: {path}", code="limit")
        self._trees[path] = tree
        return tree


def _imports(tree: ast.AST) -> tuple[str, ...]:
    values: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            values.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            values.add(node.module)
    return tuple(sorted(values))



def _boundary_imports(python: _PythonInventory, path: str) -> tuple[tuple[str, tuple[str, ...]], ...]:
    """Direct imports with snapshot-bound relative identities, separate from queue analysis.

    The first field is the imported module; selected symbols are additional
    forbidden-prefix candidates, not module exceptions. Dynamic imports and
    transitive re-exports are outside this bounded direct-import analysis.
    """
    package: tuple[str, ...] | None = None
    records: set[tuple[str, tuple[str, ...]]] = set()
    for node in ast.walk(python.tree(path)):
        if isinstance(node, ast.Import):
            records.update((alias.name, ()) for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            if node.level:
                if package is None:
                    directories = PurePosixPath(path).parent.parts
                    if len(directories) > 64:
                        raise ArchitectureError("Python package ancestry limit exceeded", code="limit")
                    # A conventional src root takes precedence over package
                    # markers above it: factory/__init__.py cannot rename the
                    # runtime getzilla_factory package to factory.src.*.
                    src_roots = [index + 1 for index, part in enumerate(directories)
                                 if part == "src" and index + 1 < len(directories)]
                    if len(src_roots) > 1:
                        raise SyntaxError(f"ambiguous relative source root: {path}")
                    if src_roots:
                        # src-layout namespace packages are valid without an
                        # initializer (the real getzilla_delivery package).
                        package = directories[src_roots[0]:]
                    else:
                        # Ordinary packages need a snapshot initializer to
                        # establish their root; nested namespace dirs remain.
                        for index in range(len(directories)):
                            initializer = "/".join((*directories[:index + 1], "__init__.py"))
                            if read_diff_file(python.root, python.diff, initializer) is not None:
                                package = directories[index:]
                                break
                    if not package or any(not part.isidentifier() for part in package):
                        raise SyntaxError(f"relative package context unavailable: {path}")
                remove = node.level - 1
                if remove >= len(package):
                    raise SyntaxError(f"relative import escapes package: {path}")
                prefix = package[:len(package) - remove]
                module = ".".join((*prefix, *(() if not module else module.split("."))))
            selected = tuple(sorted(alias.name for alias in node.names))
            records.add((module, selected))
    return tuple(sorted(records))


def _network_protocol(imported: str) -> str | None:
    if imported == "urllib.parse" or imported.startswith("urllib.parse."):
        return None
    matches = [
        (len(family), protocol)
        for family, protocol in _NETWORK_IMPORTS.items()
        if imported == family or imported.startswith(family + ".")
    ]
    return None if not matches else max(matches)[1]


def _httpx_uses_bounded_uds(tree: ast.AST) -> bool:
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = node.func.attr if isinstance(node.func, ast.Attribute) else node.func.id if isinstance(node.func, ast.Name) else ""
        if name not in {"HTTPTransport", "AsyncHTTPTransport"}:
            continue
        for keyword in node.keywords:
            if keyword.arg == "uds":
                return True
    return False


def _socket_uses_only_unix(tree: ast.AST) -> bool:
    attributes = {
        node.attr
        for node in ast.walk(tree)
        if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "socket"
    }
    return "AF_UNIX" in attributes and not ({"AF_INET", "AF_INET6", "create_connection"} & attributes)


def _import_targets(tree: ast.AST) -> set[str]:
    targets: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            targets.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            targets.update(f"{node.module}.{alias.name}" for alias in node.names)
    return targets


def _called_imports(tree: ast.AST) -> set[tuple[str, str]]:
    aliases: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name.split(".")[0]] = alias.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = f"{node.module}.{alias.name}"
    called: set[tuple[str, str]] = set()
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        parts: list[str] = []
        value: ast.AST = node.func
        while isinstance(value, ast.Attribute):
            parts.append(value.attr)
            value = value.value
        if isinstance(value, ast.Name) and value.id in aliases:
            imported = aliases[value.id]
            chain = ".".join((imported, *reversed(parts)))
            called.add((imported, chain))
    return called


def _module_boundaries(
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
) -> FitnessResult:
    rules = snapshot.rules["path_boundaries"]
    predicate = "changed Python sources match a declared module-boundary source prefix"
    if not rules:
        return _not_applicable("module_boundary", predicate, (), "no_declared_rules")
    applicable = tuple(
        path
        for path in _python_paths(diff)
        if any(_matches(path, rule["source_prefixes"]) for rule in rules)
    )
    if not applicable:
        return _not_applicable(
            "module_boundary", predicate, _python_paths(diff), "no_matching_changed_source",
            (rule["id"] for rule in rules),
        )
    findings: list[str] = []
    try:
        for path in applicable:
            imports = _boundary_imports(python, path)
            for rule in rules:
                if not _matches(path, rule["source_prefixes"]):
                    continue
                forbidden = {
                    prefix.replace("/", ".").replace("-", "_").lstrip(".")
                    for prefix in rule["forbidden_dependency_prefixes"]
                }
                if "trust_ci" in forbidden:
                    forbidden.add("adaptive_trust_ci")
                allowed = set(rule.get("allowed_dependency_modules", ()))
                for module, selected in imports:
                    if module in allowed:
                        continue
                    candidates = {module, *(f"{module}.{name}" for name in selected)}
                    for imported in sorted(candidates):
                        if any(imported == prefix or imported.startswith(prefix + ".") for prefix in forbidden):
                            findings.append(f"{rule['id']}: {path} imports forbidden {imported}")
    except SyntaxError as exc:
        return _result(
            "module_boundary",
            status="unsupported",
            rules=(rule["id"] for rule in rules),
            findings=(f"Python source analysis unsupported: {exc}",),
            predicate=predicate,
            scope=applicable,
            reason="unparseable_source",
        )
    return _result(
        "module_boundary",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=applicable,
    )


def _contract_compatibility(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["contract_policies"]
    predicate = "declared contract policy intersects an added, removed, or changed contract"
    if not rules:
        return _not_applicable("contract_compatibility", predicate, (), "no_declared_rules")
    directly_changed_ids = {
        item.id for item in diff.changes if item.kind == "contract"
    }
    if not directly_changed_ids:
        return _not_applicable(
            "contract_compatibility", predicate, (), "contracts_unchanged", (rule["id"] for rule in rules)
        )
    before = {item.id: item for item in (diff._base_state.contracts if diff._base_state else ())}
    after = {item.id: item for item in diff._head_state.contracts}
    unattributed_references: dict[str, list[str]] = {}
    changed_ids = _contract_dependency_closure(
        directly_changed_ids, before, after, unattributed_references
    )
    findings: list[str] = []
    unsupported: list[str] = []
    used_rules: set[str] = set()
    comparison_budget = [0]
    for identity in sorted(changed_ids):
        old, new = before.get(identity), after.get(identity)
        record = new if new is not None else old
        if record is None:
            raise ArchitectureError("changed contract is absent from both states", code="fitness")
        kind = record.kind
        matching = [rule for rule in rules if kind in rule["contract_kinds"]]
        used_rules.update(rule["id"] for rule in matching)
        if not matching:
            unsupported.append(f"{identity}: no compatibility policy for {kind}")
        elif old is None:
            continue
        elif new is None:
            findings.append(f"{identity}: declared contract removed")
        else:
            for rule in matching:
                result = compare_contracts(
                    old,
                    new,
                    rule["compatibility"],
                    base_inventory=tuple(before.values()),
                    head_inventory=tuple(after.values()),
                    _work_budget=comparison_budget,
                )
                if result.status == "unsupported":
                    unsupported.append(f"{identity}: unsupported compatibility semantics")
                elif result.status != "compatible":
                    findings.append(f"{identity}: {','.join(result.reasons)}")
    #: An unattributed reference is reported only where it can have cost a re-verification,
    #: which is where the referrer is itself inside the certified scope: that is the case in
    #: which the unattributed candidate could otherwise be lost even if a concrete path
    #: resolves in the comparator. A pull request that touches nothing related must not have
    #: somebody else's collision charged to it, and must certainly not abort -- that was the non-self-healing
    #: wedge: the pull request repairing the collision inherits the poisoned base it must fix.
    # Bound presentation only, after both inventory traversals and their refusal checks.
    for identity in sorted(changed_ids & unattributed_references.keys()):
        details = sorted(set(unattributed_references[identity]))
        unsupported.extend(
            f"{identity}: unattributed reference: {detail}"
            for detail in details[:_UNATTRIBUTED_REFERENCE_LIMIT]
        )
        hidden = len(details) - _UNATTRIBUTED_REFERENCE_LIMIT
        if hidden > 0:
            # The plural prefix sorts after the detail lines in the shared _result helper.
            unsupported.append(
                f"{identity}: unattributed references: (+{hidden} more unattributed references)"
            )
    if unsupported:
        status = "unsupported"
    elif findings:
        status = "fail"
    else:
        status = "pass"
    return _result(
        "contract_compatibility",
        status=status,
        rules=used_rules,
        findings=(*findings, *unsupported),
        predicate=predicate,
        scope=changed_ids,
        reason="unsupported_contract_semantics" if unsupported else "applicable",
    )


#: Declared contracts named in one ``$id`` ambiguity message before the list is elided.
_AMBIGUITY_OWNER_LIMIT = 5
#: Unique unattributed reference details displayed per in-scope referrer, before a summary.
_UNATTRIBUTED_REFERENCE_LIMIT = 5


def _reverse_contract_dependencies(
    inventory: dict[str, Any],
    *,
    fail_closed: bool,
    unattributed: dict[str, list[str]],
) -> dict[str, set[str]]:
    """Declared target identity -> referrer identities, for a single inventory state.

    The map is the closure's whole dependency structure: every direct edge the gate will
    re-verify transitively, so it is also the unit a reviewer can count.  A contract that
    ``$ref``s its own declared ``$id`` (or its own path) contributes **no** edge -- identity is
    per contract, requirements.md forbids the self edge, and a changed contract is already
    re-verified by the changed-contract row, so omitting it cannot narrow what the gate reads.
    Reference bases are interpreted only through
    ``_external_contract_reference_paths``/``architecture.schema_reference_target_path``.
    """
    reverse_dependencies: dict[str, set[str]] = {}
    records = tuple(inventory.values())
    by_path = {record.path: record.id for record in records}
    paths_by_schema_id: dict[str, list[str]] = {}
    for record in records:
        schema_id = record.document.get("$id") if isinstance(record.document, dict) else None
        if isinstance(schema_id, str):
            paths_by_schema_id.setdefault(schema_id, []).append(record.path)
    declared_paths = frozenset(by_path)
    for record in records:
        signals: list[str] = []
        for target_path in _external_contract_reference_paths(
            record,
            paths_by_schema_id,
            declared_paths,
            fail_closed=fail_closed,
            signals=signals,
        ):
            target_id = by_path.get(target_path)
            if target_id is not None and target_id != record.id:
                reverse_dependencies.setdefault(target_id, set()).add(record.id)
        if signals:
            unattributed.setdefault(record.id, []).extend(signals)
    return reverse_dependencies


def _contract_dependency_closure(
    changed_ids: set[str],
    before: dict[str, Any],
    after: dict[str, Any],
    unattributed: dict[str, list[str]] | None = None,
) -> set[str]:
    """Return changed contracts plus declared contracts that reference them.

    ``unattributed`` is an optional output map: every reference this walk could not
    attribute because two declared contracts carry the same ``$id`` is recorded there under
    its referrer's identity.  It is a signal, not an abort: see
    ``_reference_identity_candidates``.
    """

    reverse_dependencies: dict[str, set[str]] = {}
    collected: dict[str, list[str]] = {} if unattributed is None else unattributed
    #: The head inventory is the state being certified, so a reference that names nothing but
    #: a shared ``$id`` there fails closed.  The base inventory is inherited authored state:
    #: aborting on it would block every contract pull request against that base *and* the one
    #: pull request that repairs it, because the repair's own base is the poisoned state.  A
    #: base-side ambiguity is therefore degraded to an attributed signal, which is also how
    #: the comparator treats the same reference per pair.
    for inventory, fail_closed in ((before, False), (after, True)):
        for target_id, dependents in _reverse_contract_dependencies(
            inventory, fail_closed=fail_closed, unattributed=collected
        ).items():
            reverse_dependencies.setdefault(target_id, set()).update(dependents)

    closure = set(changed_ids)
    pending = deque(sorted(changed_ids))
    while pending:
        identity = pending.popleft()
        for dependent in sorted(reverse_dependencies.get(identity, ())):
            if dependent not in closure:
                closure.add(dependent)
                pending.append(dependent)
    return closure


def _unattributable_reference_detail(
    failure: str,
    reference_base: str,
    referrer_path: str,
    paths_by_schema_id: Mapping[str, list[str]],
) -> str:
    """Name the offending reference, the contracts that collide over it and who referenced it.

    Both the abort and the signal have to be actionable without reading the inventory, so the
    text carries the colliding ``$id``, the declared paths that carry it and the referrer that
    hit it.  The carrier list is bounded because the inventory is capped at ``MAX_CONTRACTS``
    and an unbounded message would crowd out the rest of the finding.
    """
    if failure != SCHEMA_REFERENCE_AMBIGUOUS:
        return failure
    owners = sorted(set(paths_by_schema_id.get(reference_base, ())))
    shown = owners[:_AMBIGUITY_OWNER_LIMIT]
    hidden = len(owners) - len(shown)
    suffix = f" (+{hidden} more)" if hidden > 0 else ""
    return (
        f"{failure} '{reference_base}' declared by {', '.join(shown)}{suffix}"
        f"; referenced by {referrer_path}"
    )


def _reference_identity_candidates(
    referrer_path: str,
    reference_base: str,
    paths_by_schema_id: dict[str, list[str]],
    declared_paths: frozenset[str],
    *,
    fail_closed: bool,
    signals: list[str],
) -> set[str]:
    """Every declared contract path a single ``$ref`` base can name, under either table.

    Both look-ups go through the comparator's shared grammar, so no third interpretation of
    a ``$ref`` can appear here.  The result is a union rather than a choice: dependency
    identity conservatively retains both candidates when two tables disagree, even though
    the comparator chooses an existing concrete path before a competing ``$id``.

    A reference that two declared contracts collide over is never *silent*: the detail lands
    in ``signals`` for the referrer and makes its in-scope fitness row unsupported even if
    the comparator can resolve a concrete path. ``fail_closed`` then
    decides only the extra step of whether the whole run aborts.  In the certified (head)
    state a look-up that misses for a reason outside ``SCHEMA_REFERENCE_UNRESOLVED`` (an
    ``$id`` shared by two declared contracts, for example) with no path candidate aborts,
    because guessing which claimant to attach would silently verify the wrong one and a
    collision in the state under certification must not pass.  In the inherited base state the
    same reference is skipped, not fatal: an ``$id`` collision authored by one contributor
    would otherwise wedge every other contributor's gate run *and* the pull request that
    removes the collision, so recovery would require reverting this gate change.  When the
    path table did name a contract the ambiguity never aborts in either state -- the named
    path is attached, the unattributable claimants are not.  A reason outside the deny-list
    fails closed in both states: the deny-list is a deny-list, and its two relief rules are
    ``$id`` ambiguity (signalled, fatal only in the certified state) and the declined
    relative path resolved immediately below -- never a silent drop.

    ``SCHEMA_REFERENCE_UNSAFE`` is on this side of the deny-list for one reason (finding C2):
    it says *"this base is a relative path and the strict grammar refused it"* -- ``./x.json``,
    a segment holding a space or a ``+`` -- and the repository's own path rules permit such a
    path, so the pre-issue-#146 closure had already attached a dependent to whatever was
    declared there.  Dropping the edge would be a new silent under-verification, the exact
    defect this change removes, so the base is resolved for identity through
    ``architecture.schema_reference_identity_path``: the same fold the old closure used, now
    single-sourced.  A declined path that names no declared contract yields no edge and raises
    nothing, which is AC-004: there was never a dependent to lose.
    """
    candidates: set[str] = set()
    failures: list[str] = []
    for precedence in (SCHEMA_REFERENCE_PATH_FIRST, SCHEMA_REFERENCE_ID_FIRST):
        target_path, failure = schema_reference_target_path(
            referrer_path,
            reference_base,
            paths_by_schema_id,
            declared_paths,
            precedence=precedence,
        )
        if target_path is not None:
            candidates.add(target_path)
            continue
        if failure in SCHEMA_REFERENCE_UNRESOLVED:
            continue
        if failure == SCHEMA_REFERENCE_UNSAFE:
            identity_path, _reason = schema_reference_identity_path(
                referrer_path, reference_base
            )
            if identity_path is not None and identity_path in declared_paths:
                candidates.add(identity_path)
            continue
        failures.append(failure)
    if SCHEMA_REFERENCE_AMBIGUOUS in failures:
        signals.append(
            _unattributable_reference_detail(
                SCHEMA_REFERENCE_AMBIGUOUS, reference_base, referrer_path, paths_by_schema_id
            )
        )
    if not candidates and failures:
        for failure in failures:
            if failure == SCHEMA_REFERENCE_AMBIGUOUS and not fail_closed:
                continue
            raise ArchitectureError(
                _unattributable_reference_detail(
                    failure, reference_base, referrer_path, paths_by_schema_id
                ),
                code="contract",
            )
    return candidates


def _external_contract_reference_paths(
    record: Any,
    paths_by_schema_id: dict[str, list[str]],
    declared_paths: frozenset[str],
    *,
    fail_closed: bool,
    signals: list[str],
) -> set[str]:
    """Declared contract paths this record's ``$ref`` values point at.

    The reference grammar is the comparator's: ``architecture.schema_reference_target_path``
    is the only place a ``$ref`` base is interpreted, so a dependent that references a
    contract by ``$id`` or through ``file#/$defs/...`` cannot be dropped from the closure.
    Reverse edges take the **union** of the declared-path and declared-``$id`` candidates
    rather than one table's precedence: for dependency identity the safe answer is to
    re-verify every contract a ``$ref`` can name, which can only ever widen the re-verified
    set. The comparator chooses the concrete path first; retaining the competing ID edge
    here preserves conservative scope without letting claimant bytes redirect that verdict.
    A reference that does not name a declared contract yields no edge; a reference two
    declared contracts collide over is reported through ``signals`` and aborts the run only
    where ``fail_closed`` says the colliding state is the one being certified.  An edge is
    never lost because the strict grammar refused a relative path the repository could declare
    -- that case is resolved for identity, see ``_reference_identity_candidates`` (finding C2).
    The returned set may name the referrer's own path; a self reference is not a dependency and
    is excluded where the reverse map is built (finding C3).
    """
    references: set[str] = set()
    pending: list[Any] = [record.document]
    while pending:
        value = pending.pop()
        if isinstance(value, dict):
            reference = value.get("$ref")
            if isinstance(reference, str) and not reference.startswith("#"):
                reference_base, _fragment = schema_reference_parts(reference)
                if reference_base:
                    references.update(
                        _reference_identity_candidates(
                            record.path,
                            reference_base,
                            paths_by_schema_id,
                            declared_paths,
                            fail_closed=fail_closed,
                            signals=signals,
                        )
                    )
            pending.extend(value.values())
        elif isinstance(value, list):
            pending.extend(value)
    return references


def _repository_paths(root: Path, diff: ArchitectureDiff, prefixes: tuple[str, ...]) -> tuple[str, ...]:
    if diff.head_kind == "commit":
        if diff.head_sha is None:
            raise ArchitectureError("commit diff is missing exact head_sha", code="git")
        return git_tree_paths(root, diff.head_sha, prefixes)
    base_paths = set(git_tree_paths(root, diff.base_sha, prefixes))
    for artifact in diff.artifacts:
        if not _matches(artifact.path, prefixes):
            continue
        if artifact.status == "deleted":
            base_paths.discard(artifact.path)
        else:
            base_paths.add(artifact.path)
    return tuple(sorted(base_paths))


def _migration_phase(path: str) -> tuple[str, str] | None:
    if path in _PUBLIC_MIGRATION_MIRRORS:
        # Identity is counted even when its bytes are unreviewed and denied.
        return PurePosixPath(path).stem, "reviewed_bytes"
    match = _MIGRATION_PHASE.fullmatch(PurePosixPath(path).stem.lower()) or _MIGRATION_CANONICAL.fullmatch(PurePosixPath(path).stem.lower())
    if match is None and path.startswith("factory/src/getzilla_factory/resources/"):
        match = re.fullmatch(r"(?P<group>[0-9]{3}_[a-z0-9_]+)", PurePosixPath(path).stem.lower())
    return None if match is None else (match.group("group"), match.groupdict().get("phase") or "legacy")


def _migration_roots(snapshot: ArchitectureSnapshot, prefixes: tuple[str, ...]) -> tuple[str, ...]:
    primary = set(prefixes)
    return tuple(sorted(primary | {
        path for node in snapshot.system["nodes"] if primary & set(node["repository_paths"])
        for path in node["repository_paths"]
        if PurePosixPath(path).name.lower() in {"resources", "migrations"}
    }))


def _bounded_migrate_predicate(statement: str) -> bool:
    where = re.search(r"\bWHERE\b(?P<predicate>.*?)(?:\bRETURNING\b|$)", statement)
    predicate = where.group("predicate") if where else ""
    identifier = r"[A-Z_][A-Z0-9_.]*"
    operand = r"(?:\?|\$[0-9]+|%S|:[A-Z_][A-Z0-9_]*|[-+]?[0-9]+)"
    pattern = (rf"\s*(?P<column>{identifier})\s*(?P<first>>=?|<=?)\s*{operand}\s+AND\s+"
               rf"(?P=column)\s*(?P<second>>=?|<=?)\s*{operand}\s*")
    match = re.fullmatch(pattern, predicate)
    between = re.fullmatch(rf"\s*{identifier}\s+BETWEEN\s+{operand}\s+AND\s+{operand}\s*", predicate)
    return bool(between or match and (match["first"].startswith(">") != match["second"].startswith(">")))


class _MigrationPlan(NamedTuple):
    rule: dict[str, Any]
    roots: tuple[str, ...]
    relevant: tuple[ChangedArtifact, ...]
    primary: tuple[ChangedArtifact, ...]
    head_paths: tuple[str, ...]
    copies: dict[str, tuple[str, ...]]


class _MigrationAnalysis:
    def __init__(self) -> None:
        self.plans: list[_MigrationPlan] = []
        self.root_plans: dict[str, list[int]] = {}
        self.scope: tuple[str, ...] = ()
        self.issues: list[tuple[bool, str]] = []
        self.statements = self.work = 0
        self.reviewed_bytes: list[str] = []

    def bound(self, amount: int) -> None:
        self.work += amount
        if self.work > MAX_MIGRATION_WORK:
            raise ArchitectureError("migration aggregate work limit exceeded", code="limit")

    def record(self, unsupported: bool, message: str) -> None:
        if len(self.issues) >= MAX_MIGRATION_FINDINGS - 1:
            raise ArchitectureError("migration finding limit exceeded", code="limit")
        self.issues.append((unsupported, message))

    def read(self, root: Path, diff: ArchitectureDiff, paths: Iterable[str]) -> dict[str, bytes | None]:
        values: dict[str, bytes | None] = {}
        ordered = tuple(sorted(set(paths)))
        total = 0
        for start in range(0, len(ordered), MAX_MIGRATION_BATCH_PATHS):
            batch = read_diff_files(root, diff, ordered[start:start + MAX_MIGRATION_BATCH_PATHS])
            total += sum(len(value or b"") for value in batch.values())
            if total > MAX_MIGRATION_BYTES:
                raise ArchitectureError("migration aggregate byte limit exceeded", code="limit")
            values.update(batch)
        return values

    def source(self, rule_id: str, path: str, phase: str, source: str) -> None:
        found = False
        statements = (re.sub(r"--[^\n]*", "", part[0]).strip() for part in re.finditer(r"(?m)(?:--[^\n]*(?:\n|$)|[^;])+", source))
        for statement in filter(None, statements):
            found = True
            if (statement_limit := self.statements >= MAX_MIGRATION_STATEMENTS) or len(self.issues) >= MAX_MIGRATION_FINDINGS - 1:
                raise ArchitectureError("migration statement work limit exceeded" if statement_limit else "migration finding limit exceeded", code="limit")
            self.statements += 1
            normalized = " ".join(statement.upper().split())
            verb = normalized.split()[0]
            unbounded = phase == "migrate" and verb in {"UPDATE", "DELETE"} and (
                not re.search(r"\bWHERE\b", normalized)
                or re.search(r"\bWHERE\b.*(?:\b1\s*=\s*1\b|\bTRUE\b)", normalized)
            )
            unproven = (phase == "migrate" and verb in {"UPDATE", "DELETE"}
                        and not unbounded and not _bounded_migrate_predicate(normalized))
            checks = (
                (phase != "contract" and re.search(r"\b(DROP|TRUNCATE)\b|\bALTER TABLE\b.*\bDROP\b", normalized), False, "destructive SQL outside contract phase"),
                (phase == "expand" and " NOT NULL" in normalized, False, "NOT NULL is unsafe in expand phase"),
                (phase == "expand" and not re.match(r"^(CREATE TABLE|CREATE (UNIQUE )?INDEX CONCURRENTLY|ALTER TABLE .* ADD )", normalized), True, "unsupported expand SQL semantics"),
                (unbounded, False, f"unbounded {verb} in migrate phase"),
                (unproven, True, "migrate bounded/resumable predicate is unproven"),
                (phase == "migrate" and verb not in {"UPDATE", "DELETE"}, True, "unsupported bounded INSERT semantics" if verb == "INSERT" else "unsupported migrate SQL semantics"),
                (phase == "contract" and re.match(r"^ALTER TABLE\b.*\bADD\b", normalized), False, "expansive SQL in contract phase"),
                (phase == "contract" and not re.match(r"^(ALTER TABLE .* DROP|DROP|TRUNCATE)\b", normalized), True, "unsupported contract SQL semantics"),
            )
            if issue := next(((unsupported, message) for applies, unsupported, message in checks if applies), None):
                self.record(issue[0], f"{rule_id}: {issue[1]}: {path}")
        if not found:
            self.record(True, f"{rule_id}: migration contains no analyzable SQL: {path}")

    def check(self, plan: _MigrationPlan, blobs: dict[str, bytes | None]) -> None:
        rule, rule_id = plan.rule, plan.rule["id"]
        changed_primary = {
            item.path[len(prefix):].lstrip("/") for item in plan.primary for prefix in rule["path_prefixes"]
            if _matches(item.path, (prefix,))
        }
        for item in plan.relevant:
            relative = next(item.path[len(prefix):].lstrip("/") for prefix in plan.roots if _matches(item.path, (prefix,)))
            if item not in plan.primary and relative not in changed_primary:
                self.record(False, f"{rule_id}: migration mirror differs: {item.path}")
            if rule["immutable_history"] and item.status in {"modified", "deleted"}:
                self.record(False, f"{rule_id}: immutable migration history changed: {item.path}")
        phases, version_groups, phase_paths = {}, {}, set()
        for path in plan.head_paths:
            parsed = _migration_phase(path)
            if parsed is None:
                if Path(path).suffix.lower() == ".sql":
                    self.record(True, f"{rule_id}: migration phase cannot be derived: {path}")
                continue
            group, phase = parsed
            phases.setdefault(group, set()).add(phase)
            if (match := re.match(r"^(?:v)?(?P<version>[0-9]+)(?:[_-].*)?$", group)) is None:
                self.record(True, f"{rule_id}: migration version cannot be derived: {path}")
                continue
            version = int(match.group("version"))
            version_groups.setdefault(version, set()).add((group, phase == "legacy"))
            if (version, group, phase) in phase_paths:
                self.record(False, f"{rule_id}: duplicate migration artifact for {version}/{group}/{phase}: {path}")
            phase_paths.add((version, group, phase))
        for version, groups in version_groups.items():
            if len(groups) > 1:
                self.record(False, f"{rule_id}: duplicate migration version {version}: {','.join(sorted(group for group, _ in groups))}")
        if version_groups and set(version_groups) != set(range(1, max(version_groups) + 1)):
            self.record(False, f"{rule_id}: migration version history is not contiguous")
        for item in plan.primary:
            if item.status == "deleted":
                self.record(False, f"{rule_id}: migration history removed: {item.path}")
                continue
            parsed = _migration_phase(item.path)
            if parsed is None:
                self.record(True, f"{rule_id}: migration phase cannot be derived: {item.path}")
                continue
            if parsed[1] == "reviewed_bytes":
                mirror = _PUBLIC_MIGRATION_MIRRORS[item.path]
                value = blobs.get(item.path)
                digest = hashlib.sha256(value).hexdigest() if value is not None else None
                approved = (
                    rule_id == "FIT-TRUST-CI-SQL-HISTORY"
                    and rule["immutable_history"]
                    and rule["path_prefixes"] == ["trust-ci/sql"]
                    and set(rule["required_phases"]) == {"expand", "migrate", "contract"}
                    and item.path in _PUBLIC_MIGRATION_MIRRORS
                    and digest is not None
                    and digest == _REVIEWED_TRUST_CI_MIGRATIONS.get(item.path)
                    and plan.copies[item.path] == (mirror,)
                    and blobs.get(mirror) == value
                )
                if approved:
                    self.reviewed_bytes.append(f"{item.path} raw_sha256={digest}")
                else:
                    self.record(True, f"{rule_id}: unreviewed Trust CI migration bytes or missing exact mirror: {item.path}")
                # This is named byte compatibility, never generic SQL phase proof.
                continue
            missing = sorted(set(rule["required_phases"]) - phases.get(parsed[0], set()))
            if missing:
                self.record(False, f"{rule_id}: migration {parsed[0]} missing phases: {','.join(missing)}")
            value = blobs.get(item.path)
            if value is None:
                self.record(True, f"{rule_id}: migration source unavailable: {item.path}")
                continue
            try:
                source = value.decode("utf-8")
            except UnicodeDecodeError:
                self.record(True, f"{rule_id}: migration is not UTF-8: {item.path}")
                continue
            self.source(rule_id, item.path, parsed[1], source)
            for mirror in plan.copies[item.path]:
                mirror_value = blobs.get(mirror)
                if mirror_value != value:
                    self.record(False, f"{rule_id}: migration mirror {'missing' if mirror_value is None else 'differs'}: {mirror}")


def _migration_safety(root: Path, snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["migration_policies"]
    predicate = "changed SQL paths match a declared migration-history or derived mirror prefix"
    if not rules:
        return _not_applicable("migration_safety", predicate, (), "no_declared_rules")
    analysis = _MigrationAnalysis()
    try:
        analysis.bound(sum(len(rule["path_prefixes"]) for rule in rules) * sum(
            max(1, len(node["repository_paths"])) for node in snapshot.system["nodes"]))
        seeds = []
        for rule in rules:
            mirrors = tuple(
                (prefix, tuple(path for path in _migration_roots(snapshot, (prefix,)) if path != prefix))
                for prefix in rule["path_prefixes"])
            analysis.bound(len(roots := tuple(sorted(set(rule["path_prefixes"]).union(*(paths for _, paths in mirrors))))))
            seeds.append((rule, roots, mirrors))
            for migration_root in roots:
                analysis.root_plans.setdefault(migration_root, []).append(len(seeds) - 1)
        sql = tuple(item for item in diff.artifacts if PurePosixPath(item.path).suffix.lower() == ".sql")
        analysis.bound(len(sql) * max(1, root_memberships := sum(len(v) for v in analysis.root_plans.values())))
        matches = {item.path: {index for prefix, indices in analysis.root_plans.items()
                               if _matches(item.path, (prefix,)) for index in indices}
                   for item in sql}
        applicable = tuple(item for item in sql if matches[item.path])
        analysis.bound(root_memberships + len(applicable) * len(seeds))
        inventory = _repository_paths(root, diff, tuple(analysis.root_plans))
        analysis.scope = (*analysis.root_plans, *inventory, *(item.path for item in applicable))
        analysis.bound(len(inventory) * max(len(seeds), sum(len(rule["path_prefixes"]) for rule in rules))
                       + 2 * len(applicable) * max(1, root_memberships))
        if not applicable:
            return _not_applicable("migration_safety", predicate, analysis.scope,
                                   "no_matching_sql_change", (rule["id"] for rule in rules))
        reads: set[str] = set()
        for index, (rule, roots, mirrors) in enumerate(seeds):
            relevant = tuple(item for item in applicable if index in matches[item.path])
            primary = tuple(item for item in relevant if _matches(item.path, tuple(rule["path_prefixes"])))
            head_paths = tuple(path for path in inventory if _matches(path, tuple(rule["path_prefixes"])))
            copies: dict[str, tuple[str, ...]] = {}
            reads.update(item.path for item in primary if item.status != "deleted")
            for item in primary:
                prefix = next(path for path in rule["path_prefixes"] if _matches(item.path, (path,)))
                relative = item.path[len(prefix):].lstrip("/")
                copies[item.path] = tuple(
                    f"{mirror}/{relative}" for prefix, mirror_roots in mirrors
                    if _matches(item.path, (prefix,)) for mirror in mirror_roots)
                reads.update(copies[item.path])
            analysis.plans.append(_MigrationPlan(rule, roots, relevant, primary, head_paths, copies))
        analysis.bound(len(reads))
        blobs = analysis.read(root, diff, reads)
        for plan in analysis.plans:
            analysis.check(plan, blobs)
    except ArchitectureError as exc:
        analysis.issues.append((True, str(exc)))
    unsupported = any(item[0] for item in analysis.issues)
    status = "unsupported" if unsupported else ("fail" if analysis.issues else "pass")
    if analysis.reviewed_bytes:
        predicate += "; reviewed Trust CI byte compatibility, not semantic phase proof: " + repr(analysis.reviewed_bytes)
    return _result("migration_safety", status=status, rules=(rule["id"] for rule in rules),
                   findings=(item[1] for item in analysis.issues), predicate=predicate, scope=analysis.scope,
                   reason=("unsupported_migration_semantics" if unsupported else
                           "reviewed_trust_ci_migration_byte_compatibility" if status == "pass" and analysis.reviewed_bytes
                           else "applicable"))


def _tenant_authorization(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["tenant_authorization_policies"]
    predicate = "tenant-scoped declared data is covered and authorized on every architecture edge"
    tenant_data = {item["id"] for item in snapshot.system["data_classifications"] if item["tenant_scoped"]}
    if not tenant_data:
        return _not_applicable("tenant_authorization", predicate, (), "no_tenant_scoped_data")
    if not _model_changed(diff):
        return _not_applicable(
            "tenant_authorization", predicate, (), "architecture_unchanged", (rule["id"] for rule in rules)
        )
    edges = [edge for edge in snapshot.system["edges"] if tenant_data & set(edge["allowed_data"])]
    covered = {item for rule in rules for item in rule["data_classifications"]}
    missing = tenant_data - covered
    findings = [f"unauthenticated tenant edge {edge['id']}"
                for edge in edges if edge["authentication"] == "none"]
    unsupported = [f"missing tenant policy coverage: {','.join(sorted(missing))}"] if missing else []
    unsupported.extend(
        f"{rule['id']}: model v1 has no tenant-filter edge field"
        for edge in edges for rule in rules if rule["require_tenant_filter"]
        and set(edge["allowed_data"]) & set(rule["data_classifications"]) & tenant_data)
    status = "unsupported" if unsupported else ("fail" if findings else "pass")
    return _result("tenant_authorization", status=status, rules=(rule["id"] for rule in rules),
                   findings=(*findings, *unsupported), predicate=predicate,
                   scope=(*tenant_data, *(edge["id"] for edge in edges)),
                   reason="unsupported_tenant_semantics" if status == "unsupported" else "applicable")


def _owner_for_path(snapshot: ArchitectureSnapshot, path: str) -> dict[str, Any] | None:
    matches = [
        (len(repository_path), node)
        for node in snapshot.system["nodes"]
        for repository_path in node["repository_paths"]
        if _matches(path, (repository_path,))
    ]
    if not matches:
        return None
    specificity = max(length for length, _ in matches)
    owners = {node["id"]: node for length, node in matches if length == specificity}
    if len(owners) != 1:
        raise ArchitectureError(
            f"ambiguous repository owner for {path}: {sorted(owners)}",
            code="fitness",
        )
    return next(iter(owners.values()))


def _project_import_roots(
    snapshot: ArchitectureSnapshot, diff: ArchitectureDiff, root: Path
) -> set[str]:
    prefixes = tuple(
        sorted(
            {
                repository_path
                for node in snapshot.system["nodes"]
                for repository_path in node["repository_paths"]
            }
        )
    )
    paths = _repository_paths(root, diff, prefixes) if prefixes else ()
    roots = set(_GOVERNANCE_IMPORTS)
    for prefix in prefixes:
        parts = PurePosixPath(prefix).parts
        if "src" in parts:
            index = parts.index("src") + 1
            if index < len(parts) and not parts[index].endswith(tuple(_PYTHON_SUFFIXES)):
                roots.add(parts[index])
    for path in paths:
        if PurePosixPath(path).suffix not in _PYTHON_SUFFIXES:
            continue
        matching = [prefix for prefix in prefixes if _matches(path, (prefix,))]
        if not matching:
            continue
        prefix = max(matching, key=len)
        relative = path[len(prefix) :].lstrip("/")
        if not relative:
            roots.add(PurePosixPath(prefix).stem)
            continue
        if relative == "__init__.py":
            roots.add(PurePosixPath(prefix).name)
        first = relative.split("/", 1)[0]
        roots.add(PurePosixPath(first).stem if first.endswith(tuple(_PYTHON_SUFFIXES)) else first)
    return roots


def _is_external_import(imported: str, project_roots: set[str]) -> bool:
    top = imported.split(".")[0]
    return top not in sys.stdlib_module_names and top not in project_roots


def _network_call_is_applicable(
    imported: str, call: str, project_roots: set[str]
) -> bool:
    if not _is_external_import(imported, project_roots):
        return False
    family = imported.split(".")[0].lower()
    factory = call.rsplit(".", 1)[-1].lower()
    if factory.endswith(("error", "exception", "warning")):
        return False
    if factory in _CLOUD_SDK_NETWORK_FACTORIES.get(family, set()):
        return True
    tokens = {
        token.lower()
        for token in re.findall(
            r"[A-Z]+(?=[A-Z][a-z]|[^A-Za-z]|$)|[A-Z]?[a-z]+|[0-9]+",
            f"{imported}.{call}",
        )
    }
    return bool(tokens & _NETWORK_APPLICABILITY_TOKENS)


def _network_clients(
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
) -> FitnessResult:
    rules = snapshot.rules["network_policies"]
    predicate = "changed owned Python source imports a bounded network-client family"
    if not rules:
        return _not_applicable("network_client", predicate, (), "no_declared_rules")
    clients: list[tuple[str, str, dict[str, Any] | None]] = []
    unsupported: list[str] = []
    project_roots = _project_import_roots(snapshot, diff, python.root)
    for path in _python_paths(diff):
        owner = _owner_for_path(snapshot, path)
        try:
            tree = python.tree(path)
            imports = _import_targets(tree)
        except SyntaxError as exc:
            unsupported.append(f"{path}: {exc}")
            continue
        for imported in imports:
            protocol = _network_protocol(imported)
            if protocol:
                if imported.split(".")[0] == "httpx" and protocol == "https" and _httpx_uses_bounded_uds(tree):
                    protocol = "unix_http"
                if imported.split(".")[0] == "socket" and protocol == "tcp" and _socket_uses_only_unix(tree):
                    protocol = "unix_http"
                clients.append((path, protocol, owner))
        for imported, call in _called_imports(tree):
            if _network_protocol(imported) is not None:
                continue
            if _network_call_is_applicable(imported, call, project_roots):
                unsupported.append(f"{path}: unsupported external-client semantics for {call}")
    if unsupported:
        return _result(
            "network_client",
            status="unsupported",
            rules=(rule["id"] for rule in rules),
            findings=unsupported,
            predicate=predicate,
            scope=_python_paths(diff),
            reason="unparseable_source",
        )
    if not clients:
        return _not_applicable(
            "network_client", predicate, _python_paths(diff), "no_network_client",
            (rule["id"] for rule in rules),
        )
    findings: list[str] = []
    edges = snapshot.system["edges"]
    for path, protocol, owner in clients:
        if owner is None:
            findings.append(f"unowned network client {protocol} in {path}")
            continue
        matching_rules = [rule for rule in rules if owner["type"] in rule["node_types"]]
        if not matching_rules:
            findings.append(f"no network policy for {protocol} in {path} for {owner['id']}")
            continue
        for rule in matching_rules:
            declared = any(
                edge["from"] == owner["id"] and edge["protocol"] == protocol for edge in edges
            )
            if protocol not in rule["allowed_protocols"] or (rule["require_declared_edge"] and not declared):
                findings.append(
                    f"{rule['id']}: undeclared network client {protocol} in {path} for {owner['id']}"
                )
    return _result(
        "network_client",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=(item[0] for item in clients),
    )


def _production_imports(diff: ArchitectureDiff, python: _PythonInventory) -> FitnessResult:
    predicate = "changed production Python source imports test or governance modules"
    applicable = tuple(
        path for path in _python_paths(diff) if not _is_governance_or_test_path(path)
    )
    if not applicable:
        return _not_applicable(
            "production_import", predicate, _python_paths(diff), "no_changed_production_source"
        )
    findings: list[str] = []
    try:
        for path in applicable:
            for imported in _imports(python.tree(path)):
                if imported.split(".")[0] in _GOVERNANCE_IMPORTS:
                    findings.append(f"{path} imports governance/test module {imported}")
    except SyntaxError as exc:
        return _result(
            "production_import",
            status="unsupported",
            findings=(f"Python source analysis unsupported: {exc}",),
            predicate=predicate,
            scope=applicable,
            reason="unparseable_source",
        )
    return _result(
        "production_import",
        status="fail" if findings else "pass",
        findings=findings,
        predicate=predicate,
        scope=applicable,
    )


def _trust_ci_metadata_paths(diff: ArchitectureDiff) -> tuple[str, ...]:
    """Qualify source bindings, never runtime authority, from validated paired states."""
    if diff._base_state is None:
        return ()
    base = diff._base_state.snapshot.system
    head = diff._head_state.snapshot.system
    before = {node["id"]: node for node in base["nodes"]}
    artifacts = {item.path: item for item in diff.artifacts}

    def changed_bytes(path: str) -> bool:
        item = artifacts.get(path)
        return bool(item is not None and item.status in {"added", "modified"}
                    and item.head_digest is not None and item.head_size > 0
                    and item.head_digest != item.base_digest)

    # Remove only exact newly added public descriptors and owner memberships.
    # The existing envelope comparison below then checks every surrounding field.
    old_contracts = {item["id"]: item for item in base["contracts"]}
    new_contracts = {item["id"]: item for item in head["contracts"]}
    public_paths: list[str] = []
    admitted: dict[str, str] = {}
    for name, identity, owner, kind, role, compatibility, filenames in _PUBLIC_CONTRACT_BINDINGS:
        if identity in old_contracts or identity not in new_contracts:
            continue
        path = f"engineering/contracts/schemas/{name}.v1.json"
        descriptor = {"id": identity, "path": path, "version": "1", "kind": kind,
                      "role": role, "compatibility": compatibility}
        owners = [node for node in head["nodes"] if identity in node["public_contracts"]]
        if (new_contracts[identity] != descriptor or not changed_bytes(path)
                or len(owners) != 1 or owners[0]["id"] != owner or owner not in before):
            return ()
        paired = tuple(f"trust-ci/src/adaptive_trust_ci/{filename}" for filename in filenames)
        if not any(
            changed_bytes(source_path)
            and source_path in owners[0]["repository_paths"]
            and [node["id"] for node in head["nodes"] if source_path in node["repository_paths"]] == [owner]
            for source_path in paired
        ):
            return ()
        admitted[identity] = owner
        public_paths.append(path)
    if admitted:
        head = {
            **head,
            "contracts": [item for item in head["contracts"] if item["id"] not in admitted],
            "nodes": [{**node, "public_contracts": [identity for identity in node["public_contracts"]
                        if admitted.get(identity) != node["id"]]} for node in head["nodes"]],
        }
    after = {node["id"]: node for node in head["nodes"]}
    domains = {domain["id"] for domain in base["trust_domains"] if domain["kind"] == "trust_ci_control"}

    def properties(node: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in node.items() if key != "repository_paths"}

    def source(path: str) -> bool:
        return (
            str(PurePosixPath(path)) == path
            and ".." not in PurePosixPath(path).parts
            and not any(character in path for character in "*?[]\\")
            and path.startswith("trust-ci/src/adaptive_trust_ci/")
            and path.endswith(".py")
            and changed_bytes(path)
        )

    qualified: list[str] = []
    same_envelope = (
        {key: value for key, value in base.items() if key != "nodes"}
        == {key: value for key, value in head.items() if key != "nodes"}
        and before.keys() == after.keys()
        and all(properties(before[key]) == properties(after[key]) for key in before)
    )
    bindings_valid = same_envelope
    changed_bindings = False
    if same_envelope:
        old_owners: dict[str, set[str]] = {}
        new_owners: dict[str, set[str]] = {}
        for identity in before:
            old_paths = set(before[identity]["repository_paths"])
            new_paths = set(after[identity]["repository_paths"])
            if old_paths == new_paths:
                continue
            changed_bindings = True
            node = before[identity]
            worker_extension = (
                identity == "NODE-TRUST-CI-WORKER"
                and node["type"] == "worker"
                and node["trust_domain"] == "TD-TRUST-CI-EXECUTION"
                and node["owner"] == "Trust CI operators"
                and node["runtime"]["kind"] == "container"
                and old_paths <= new_paths
                and new_paths - old_paths <= _PUBLIC_WORKER_SOURCES
            )
            if not worker_extension and (node["trust_domain"] not in domains
                                        or node["type"] not in {"service", "datastore", "local_component"}):
                bindings_valid = False
            for path in old_paths ^ new_paths:
                if not source(path):
                    bindings_valid = False
        for identity, node in before.items():
            for path in node["repository_paths"]:
                old_owners.setdefault(path, set()).add(identity)
        for identity, node in after.items():
            for path in node["repository_paths"]:
                new_owners.setdefault(path, set()).add(identity)
        for path in old_owners.keys() | new_owners.keys():
            old = old_owners.get(path, set())
            new = new_owners.get(path, set())
            if old == new:
                continue
            if not old and len(new) == 1:
                # A new exact source registration cannot expand an existing prefix owner.
                if any(_matches(path, node["repository_paths"]) for node in before.values()):
                    bindings_valid = False
                continue
            # Approved correction: store.py is the API's existing PostgreSQL client,
            # not the PostgreSQL server. No other ownership transfer is metadata.
            api = before.get("NODE-TRUST-CI-API", {})
            postgres = before.get("NODE-TRUST-CI-POSTGRES", {})
            if not (
                path == "trust-ci/src/adaptive_trust_ci/store.py"
                and old == {"NODE-TRUST-CI-POSTGRES"}
                and new == {"NODE-TRUST-CI-API"}
                and api.get("type") == "service"
                and api.get("runtime", {}).get("kind") == "container"
                and postgres.get("type") == "datastore"
                and postgres.get("runtime", {}).get("kind") == "postgresql"
                and api.get("owner") == postgres.get("owner") == "Trust CI operators"
                and api.get("trust_domain") == postgres.get("trust_domain")
                and api.get("trust_domain") in domains
            ):
                bindings_valid = False
    if bindings_valid and changed_bindings and "architecture/system.yaml" in diff.changed_paths:
        qualified.append("architecture/system.yaml")
    if bindings_valid and same_envelope and admitted and "architecture/system.yaml" in diff.changed_paths:
        qualified.extend(("architecture/system.yaml", *public_paths))

    contract_path = "engineering/contracts/openapi/trust-ci.v1.json"
    old_contracts = {item["id"]: item for item in base["contracts"]}
    new_contracts = {item["id"]: item for item in head["contracts"]}
    contract = old_contracts.get("CONTRACT-TRUST-CI-OPENAPI")
    owners = {identity for identity, node in before.items() if "CONTRACT-TRUST-CI-OPENAPI" in node["public_contracts"]}
    head_owners = {identity for identity, node in after.items() if "CONTRACT-TRUST-CI-OPENAPI" in node["public_contracts"]}
    if (
        contract_path in diff.changed_paths
        and contract is not None
        and contract == new_contracts.get("CONTRACT-TRUST-CI-OPENAPI")
        and contract["path"] == contract_path
        and contract["kind"] == "openapi"
        and contract["role"] == contract["compatibility"] == "bidirectional"
        and owners == head_owners == {"NODE-TRUST-CI-API"}
        and properties(before["NODE-TRUST-CI-API"]) == properties(after["NODE-TRUST-CI-API"])
        and before["NODE-TRUST-CI-API"]["trust_domain"] in domains
        and before["NODE-TRUST-CI-API"]["type"] == "service"
    ):
        qualified.append(contract_path)
    return tuple(sorted(set(qualified)))


def _change_separation(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["change_separation_policies"]
    predicate = "changed paths intersect an implementation or Trust CI separation boundary"
    if not rules:
        return _not_applicable("change_separation", predicate, diff.changed_paths, "no_declared_rules")
    metadata = _trust_ci_metadata_paths(diff)
    predicate += "; qualified Trust CI metadata from paired source/owner bindings: " + repr(metadata)
    findings: list[str] = []
    applicable = False
    for rule in rules:
        implementation = tuple(path for path in diff.changed_paths if path not in metadata and _matches(path, rule["implementation_prefixes"]))
        trust_ci = tuple(path for path in diff.changed_paths if _matches(path, rule["trust_ci_prefixes"]))
        applicable = applicable or bool(implementation or trust_ci)
        if implementation and trust_ci:
            findings.append(f"{rule['id']}: implementation and trust-ci mutations are mixed")
    if not applicable:
        return _not_applicable(
            "change_separation", predicate, diff.changed_paths, "no_separation_path_changed",
            (rule["id"] for rule in rules),
        )
    return _result(
        "change_separation",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=diff.changed_paths,
    )


_COMPLEXITY_NODES = (
    ast.AsyncFor,
    ast.BoolOp,
    ast.comprehension,
    ast.ExceptHandler,
    ast.For,
    ast.If,
    ast.IfExp,
    ast.Match,
    ast.Try,
    ast.While,
)


def _code_budget(
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
) -> FitnessResult:
    rules = snapshot.rules["code_budgets"]
    predicate = "changed code intersects a declared changed-code budget"
    if not rules:
        return _not_applicable("code_budget", predicate, diff.changed_paths, "no_declared_rules")
    findings: list[str] = []
    unsupported: list[str] = []
    applicable_paths: set[str] = set()
    for rule in rules:
        artifacts = [item for item in diff.artifacts if _matches(item.path, rule["path_prefixes"])]
        if not artifacts:
            continue
        applicable_paths.update(item.path for item in artifacts)
        changed_bytes = sum(max(item.base_size, item.head_size) for item in artifacts)
        unknown_line_items = [
            item.path
            for item in artifacts
            if item.added_lines is None or item.deleted_lines is None
        ]
        unsupported.extend(
            f"{rule['id']}: unknown line statistics for {path}"
            for path in unknown_line_items
        )
        changed_lines = sum(
            item.added_lines + item.deleted_lines
            for item in artifacts
            if item.added_lines is not None and item.deleted_lines is not None
        )
        complexity = 0
        for item in artifacts:
            if PurePosixPath(item.path).suffix not in _PYTHON_SUFFIXES:
                continue
            try:
                tree = python.tree(item.path) if item.status != "deleted" else ast.parse(
                    (read_diff_file(python.root, diff, item.path, "base") or b"").decode("utf-8"),
                    filename=item.path,
                )
            except (SyntaxError, UnicodeDecodeError) as exc:
                unsupported.append(f"{rule['id']}: cannot analyze {item.path}: {exc}")
                continue
            complexity += sum(isinstance(node, _COMPLEXITY_NODES) for node in ast.walk(tree))
        metrics = {
            "max_changed_bytes": changed_bytes,
            "max_changed_lines": changed_lines,
            "max_ast_complexity": complexity,
        }
        for field, actual in metrics.items():
            if actual > rule[field]:
                findings.append(f"{rule['id']}: {field} {actual} exceeds {rule[field]}")
    if not applicable_paths:
        return _not_applicable(
            "code_budget", predicate, diff.changed_paths, "no_budget_path_changed",
            (rule["id"] for rule in rules),
        )
    status = "unsupported" if unsupported else ("fail" if findings else "pass")
    return _result(
        "code_budget",
        status=status,
        rules=(rule["id"] for rule in rules),
        findings=(*findings, *unsupported),
        predicate=predicate,
        scope=applicable_paths,
        reason="unsupported_source" if unsupported else "applicable",
    )


def _operation_dependencies(
    tree: ast.AST,
    *,
    work_limit: int = MAX_QUEUE_DEPENDENCY_WORK,
    requested: frozenset[str] = frozenset(),
) -> _OperationDependencies:
    """Return names that can feed a changed callable/decorator expression."""
    dependencies: set[str] = set(requested)
    for node in ast.walk(tree):
        values: list[ast.AST] = []
        if isinstance(node, ast.Call):
            values.append(node.func)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            values.extend(node.decorator_list)
        for value in values:
            dependencies.update(
                child.id for child in ast.walk(value) if isinstance(child, ast.Name)
            )
    assignments: dict[str, set[str]] = {}
    imported_names = {
        alias.asname or alias.name for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)
        for alias in node.names
    }
    def target_names(target: ast.AST) -> set[str]:
        if isinstance(target, ast.Name):
            return {target.id}
        if isinstance(target, ast.Starred):
            return target_names(target.value)
        if isinstance(target, (ast.List, ast.Tuple)):
            return set().union(*(target_names(item) for item in target.elts))
        if isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name):
            return {target.value.id}
        return set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                for name in target_names(target):
                    assignments.setdefault(name, set()).update(
                        child.id
                        for child in ast.walk(node.value)
                        if isinstance(child, ast.Name)
                    )
        elif isinstance(node, ast.AnnAssign) and node.value is not None:
            for name in target_names(node.target):
                assignments.setdefault(name, set()).update(
                    child.id
                    for child in ast.walk(node.value)
                    if isinstance(child, ast.Name)
                )
        elif (
            isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Attribute)
            and isinstance(node.value.func.value, ast.Name)
            and node.value.func.attr in {"append", "extend"}
        ):
            assignments.setdefault(node.value.func.value.id, set()).update(
                child.id
                for argument in node.value.args
                for child in ast.walk(argument)
                if isinstance(child, ast.Name)
            )
    pending = deque(sorted(dependencies))
    processed: set[str] = set()
    work = 0
    while pending:
        name = pending.popleft()
        if name in processed:
            continue
        if work >= work_limit:
            frontier = {name, *pending}
            unresolved = set(frontier)
            unresolved_pending = deque(sorted(frontier))
            while unresolved_pending:
                unresolved_name = unresolved_pending.popleft()
                for dependency in sorted(assignments.get(unresolved_name, ())):
                    if dependency not in unresolved:
                        unresolved.add(dependency)
                        unresolved_pending.append(dependency)
            return _OperationDependencies(
                frozenset(dependencies), frozenset(unresolved),
                frozenset(unresolved & imported_names), True
            )
        work += 1
        processed.add(name)
        for dependency in sorted(assignments.get(name, ())):
            if dependency not in dependencies:
                dependencies.add(dependency)
                pending.append(dependency)
    return _OperationDependencies(frozenset(dependencies))


def _declared_module_exports(tree: ast.Module) -> tuple[str, ...]:
    declared: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            declared.add(node.name)
        elif isinstance(node, ast.Assign):
            declared.update(target.id for target in node.targets if isinstance(target, ast.Name))
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            declared.add(node.target.id)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            declared.update(alias.asname or alias.name for alias in node.names)
    return tuple(sorted(declared))


@lru_cache(maxsize=256)
def _queue_export_slice(tree: ast.Module, requested: frozenset[str]) -> ast.Module:
    """Demand closure for unchanged dependencies, retaining possible rebinding.

    Function returns have their own dependency closure. Dynamic namespaces keep
    the full bounded analysis rather than pretending an export is ordinary.
    """
    if any(isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
           and node.func.id in {'exec', 'eval', 'globals', 'locals', 'setattr', 'delattr'}
           for node in ast.walk(tree)):
        return tree

    shadowed = {node.id for node in ast.walk(tree) if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store)}
    shadowed.update(node.name for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.ClassDef)))
    shadowed.update(alias.asname or alias.name for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom)) for alias in node.names)
    shadowed.update(node.arg for node in ast.walk(tree) if isinstance(node, ast.arg))
    shadowed.update(node.name for node in ast.walk(tree) if isinstance(node, (ast.ExceptHandler, ast.MatchAs, ast.MatchStar)) and node.name)

    class Scalars(ast.NodeTransformer):
        def visit_JoinedStr(self, node):
            if any(isinstance(child, (ast.Call, ast.NamedExpr, ast.Yield, ast.YieldFrom)) for child in ast.walk(node)):
                return self.generic_visit(node)
            return ast.Constant(value='')

        def visit_Call(self, node):
            effects = any(isinstance(child, (ast.Call, ast.NamedExpr, ast.Yield, ast.YieldFrom))
                          for argument in (*node.args, *(item.value for item in node.keywords)) for child in ast.walk(argument))
            if not effects and isinstance(node.func, ast.Name) and node.func.id in {'str', 'bytes', 'int', 'float', 'bool', 'len'} - shadowed:
                return ast.Constant(value=None)
            return self.generic_visit(node)

    import copy
    tree = Scalars().visit(copy.deepcopy(tree))

    @lru_cache(maxsize=None)
    def names(node: ast.AST) -> set[str]:
        return {item.id for item in ast.walk(node) if isinstance(item, ast.Name)}

    @lru_cache(maxsize=None)
    def writes(node: ast.AST) -> set[str]:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            return {node.name}
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            return {alias.asname or alias.name.split('.')[0] for alias in node.names}
        targets = [item for item in ast.walk(node)
                   if isinstance(item, (ast.Name, ast.Attribute, ast.Subscript))
                   and isinstance(item.ctx, (ast.Store, ast.Del))]
        return set().union(*(names(item) for item in targets)) if targets else set()

    memo: dict[tuple[int, frozenset[str], bool, int], list[ast.stmt]] = {}

    def closure(body: list[ast.stmt], seeds: set[str], *, returns: bool = False, depth: int = 0) -> list[ast.stmt]:
        if depth > 64:
            raise ArchitectureError('queue export syntax depth limit exceeded', code='limit')
        key = (id(body), frozenset(seeds), returns, depth)
        if key in memo:
            return memo[key]
        selected: dict[int, ast.stmt] = {}
        wanted = set(seeds)
        for _ in range(MAX_QUEUE_DEPENDENCY_WORK):
            previous = (len(wanted), len(selected))
            for index, node in enumerate(body):
                wildcard = isinstance(node, ast.ImportFrom) and any(alias.name == '*' for alias in node.names)
                mutation = isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and bool(names(node) & wanted)
                returning = returns and not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and any(isinstance(item, (ast.Return, ast.Yield, ast.YieldFrom)) for item in ast.walk(node))
                if not (writes(node) & wanted or wildcard or mutation or returning):
                    continue
                chosen = node
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    chosen = copy.copy(node)
                    chosen.body = closure(node.body, set(), returns=True, depth=depth + 1) or [ast.Pass()]
                    chosen.returns = None
                    chosen.args = copy.deepcopy(node.args)
                    for argument in (*chosen.args.posonlyargs, *chosen.args.args, *chosen.args.kwonlyargs,
                                     *([chosen.args.vararg] if chosen.args.vararg else []),
                                     *([chosen.args.kwarg] if chosen.args.kwarg else [])):
                        argument.annotation = None
                elif isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor, ast.Try, ast.With, ast.AsyncWith)):
                    chosen = copy.copy(node)
                    for field in ('body', 'orelse', 'finalbody'):
                        if hasattr(node, field):
                            setattr(chosen, field, closure(getattr(node, field), wanted, returns=returns, depth=depth + 1))
                    if hasattr(chosen, 'test') and not (names(chosen.test) & wanted):
                        # The value interpreter joins both branches. Keep an
                        # unknown predicate so the projection cannot imply reachability.
                        chosen.test = ast.Name(id='__getzilla_unknown_predicate__', ctx=ast.Load())
                    if isinstance(chosen, (ast.For, ast.AsyncFor)) and not (names(chosen.target) & wanted):
                        chosen.iter = ast.Tuple(elts=[ast.Constant(value=None)], ctx=ast.Load())
                    if isinstance(chosen, ast.Try):
                        chosen.handlers = []
                        for handler in node.handlers:
                            selected_handler = copy.copy(handler)
                            selected_handler.type = None
                            selected_handler.body = closure(handler.body, wanted, returns=returns, depth=depth + 1)
                            chosen.handlers.append(selected_handler)
                selected[index] = chosen
                wanted.update(names(chosen))
            if previous == (len(wanted), len(selected)):
                result = [selected[index] for index in sorted(selected)]
                memo[key] = result
                return result
        raise ArchitectureError('queue export dependency limit exceeded', code='limit')

    return ast.Module(body=closure(tree.body, set(requested)), type_ignores=[])


@lru_cache(maxsize=128)
def _queue_return_exports(tree: ast.Module, adapters: frozenset[str],
                          requested: frozenset[str] | None = None, depth: int = 0) -> set[str]:
    return _queue_return_exports_scoped(tree, adapters, requested, depth, [MAX_QUEUE_DEPENDENCY_WORK])


def _queue_return_exports_scoped(tree: ast.Module, adapters: frozenset[str],
                                 requested: frozenset[str] | None, depth: int, budget: list[int] | _QueueBudget) -> set[str]:
    """Evaluate helper dependencies first; nested scopes share one work budget."""
    if depth > MAX_QUEUE_ADAPTER_DEPTH:
        raise ArchitectureError('queue factory return depth limit exceeded', code='limit')
    marker = '__getzilla_return_projection__'
    if any(isinstance(node, ast.Name) and (node.id == marker or
           (node.id.startswith(('__getzilla_return_factory_', '__getzilla_nested_factory_')) and node.id not in adapters))
           for node in ast.walk(tree)):
        raise ArchitectureError('return projection name collision', code='fitness')
    projections = {}
    preparation_cost = max(1, (sum(1 for _ in ast.walk(tree)) + QUEUE_PROJECTION_WORK_NODES - 1)
                           // QUEUE_PROJECTION_WORK_NODES) if isinstance(budget, _QueueBudget) else 0
    for node in tree.body:
        if (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                and (requested is None or node.name in requested) and node.name not in projections):
            if isinstance(budget, _QueueBudget):
                budget.step(cost=preparation_cost)
            projection = _queue_export_slice(tree, frozenset({node.name}))
            selected = next(item for item in projection.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == node.name)
            projections[node.name] = (selected, [item for item in projection.body if item is not selected])
    dependencies = {}
    for name, (selected, prefix) in projections.items():
        names = {item.id for item in ast.walk(selected) if isinstance(item, ast.Name)}
        # Module aliases can carry a helper into a return without naming it in
        # the function. Function bodies in the prefix belong to their own scope.
        for statement in prefix:
            if not isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                names.update(item.id for item in ast.walk(statement) if isinstance(item, ast.Name))
        dependencies[name] = (names & projections.keys()) - {name}
    dependents = {name: set() for name in projections}
    for name, needed in dependencies.items():
        for dependency in needed:
            dependents[dependency].add(name)
    remaining = {name: set(needed) for name, needed in dependencies.items()}
    ready = deque(sorted(name for name, needed in remaining.items() if not needed))
    order = []
    while ready:
        name = ready.popleft()
        order.append(name)
        for dependent in sorted(dependents[name]):
            remaining[dependent].discard(name)
            if not remaining[dependent]:
                ready.append(dependent)
    order.extend(name for name in projections if name not in order)  # cycles retain bounded rechecks
    pending, queued, found = deque(order), set(order), set()
    while pending:
        name = pending.popleft()
        queued.remove(name)
        if name in found:
            continue
        if isinstance(budget, _QueueBudget):
            budget.step()
        else:
            if budget[0] <= 0:
                raise ArchitectureError('queue factory return dependency limit exceeded', code='limit')
            budget[0] -= 1
        selected, prefix = projections[name]
        if _queue_projected_return(selected, prefix, adapters, found, marker, depth, budget):
            found.add(name)
            for dependent in sorted(dependents[name] - found - queued):
                pending.append(dependent)
                queued.add(dependent)
    return found


def _queue_projected_return(selected: ast.FunctionDef | ast.AsyncFunctionDef, prefix: list[ast.stmt],
                             adapters: frozenset[str], known: set[str], marker: str,
                             depth: int, budget: list[int] | _QueueBudget) -> bool:
    import copy

    class Returns(ast.NodeTransformer):
        def visit_FunctionDef(self, node):
            return node
        visit_AsyncFunctionDef = visit_FunctionDef

        def visit_Return(self, node):
            return ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Name(id=marker, ctx=ast.Load()), attr='append', ctx=ast.Load()),
                                          args=[node.value or ast.Constant(value=None)], keywords=[]))

    inherited = set()
    projected_prefix = []
    for statement in prefix:
        projected_prefix.append(statement)
        if isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)) and statement.name in known:
            alias = '__getzilla_return_factory_' + statement.name
            inherited.add(alias)
            projected_prefix.append(ast.Assign(targets=[ast.Name(id=statement.name, ctx=ast.Store())], value=ast.Name(id=alias, ctx=ast.Load())))
    adapters = adapters | inherited
    initialize = ast.Assign(targets=[ast.Name(id=marker, ctx=ast.Store())], value=ast.List(elts=[], ctx=ast.Load()))
    arguments = [*selected.args.posonlyargs, *selected.args.args]
    parameters = [*arguments, *selected.args.kwonlyargs,
                  *([selected.args.vararg] if selected.args.vararg else []),
                  *([selected.args.kwarg] if selected.args.kwarg else [])]
    defaults = [ast.Assign(targets=[ast.Name(id=argument.arg, ctx=ast.Store())], value=ast.Constant(value=None))
                for argument in parameters]
    defaults.extend(ast.Assign(targets=[ast.Name(id=argument.arg, ctx=ast.Store())], value=copy.deepcopy(default))
                    for argument, default in zip(arguments[-len(selected.args.defaults):], selected.args.defaults))
    defaults.extend(ast.Assign(targets=[ast.Name(id=argument.arg, ctx=ast.Store())], value=copy.deepcopy(default))
                    for argument, default in zip(selected.args.kwonlyargs, selected.args.kw_defaults) if default is not None)
    nested = [item for item in selected.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef))]
    nested_factories = set()
    if nested:
        nested_tree = ast.Module(body=[*projected_prefix, *defaults, *selected.body], type_ignores=[])
        nested_factories = _queue_return_exports_scoped(nested_tree, frozenset(adapters),
            frozenset(item.name for item in nested), depth + 1, budget)
    nested_names = {'__getzilla_nested_factory_' + name for name in nested_factories}
    body = list(defaults)
    for item in selected.body:
        body.append(Returns().visit(copy.deepcopy(item)))
        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name in nested_factories:
            body.append(ast.Assign(targets=[ast.Name(id=item.name, ctx=ast.Store())],
                value=ast.Name(id='__getzilla_nested_factory_' + item.name, ctx=ast.Load())))
    for decorator in selected.decorator_list:
        body.append(ast.Expr(value=ast.Call(func=ast.Attribute(value=ast.Name(id=marker, ctx=ast.Load()), attr='append', ctx=ast.Load()), args=[decorator], keywords=[])))
    result = analyze_queue_tree(ast.Module(body=[*projected_prefix, initialize, *body], type_ignores=[]), frozenset(adapters) | nested_names)
    return marker in result.derived_names


def _resolve_import_module(current_package: str, module: str | None, level: int) -> str:
    if not level:
        return module or ""
    package = current_package.split(".") if current_package else []
    remove = level - 1
    if remove > len(package):
        raise ArchitectureError("relative queue adapter import escapes its package", code="fitness")
    prefix = package[: len(package) - remove] if remove else package
    suffix = module.split(".") if module else []
    return ".".join((*prefix, *suffix))


def _imported_module(package: str, name: str) -> str:
    """`from <package> import <name>` as a dotted module; a top-level package adds no leading dot (#60)."""
    return f"{package}.{name}" if package else name


def _module_package(path: str, source_roots: tuple[str, ...] = (), paths: tuple[str, ...] = ()) -> str:
    directories = PurePosixPath(path).parent.parts
    src = [index + 1 for index, part in enumerate(directories) if part == 'src' and index + 1 < len(directories)]
    if len(src) == 1:
        return '.'.join(directories[src[0]:])
    for index in range(len(directories)):
        if '/'.join((*directories[:index + 1], '__init__.py')) in paths:
            return '.'.join(directories[index:])
    relative = path
    matching_roots = [
        root for root in source_roots if root and _matches(path, (root,))
    ]
    if matching_roots:
        relative = path[len(max(matching_roots, key=len)) + 1:]
    module = relative.rsplit(".", 1)[0].replace("/", ".")
    if module.endswith(".__init__"):
        return module.removesuffix(".__init__")
    return module.rsplit(".", 1)[0] if "." in module else ""


def _queue_adjacent_module(module: str) -> bool:
    tokens = set(filter(None, re.split(r"[^A-Za-z0-9]+|_+", module.lower())))
    return bool(tokens & _QUEUE_ADAPTER_MODULE_TOKENS)


def _queue_source_roots(snapshot: ArchitectureSnapshot) -> tuple[str, ...]:
    roots = {""}
    file_suffixes = {
        ".json", ".md", ".py", ".pyi", ".sh", ".sql", ".toml", ".txt", ".yaml", ".yml"
    }
    for node in snapshot.system["nodes"]:
        for prefix in node["repository_paths"]:
            name = prefix.rsplit("/", 1)[-1]
            if PurePosixPath(prefix).suffix.lower() in file_suffixes:
                continue
            roots.add(prefix)
            if "/" in prefix and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
                roots.add(prefix.rsplit("/", 1)[0])
    return tuple(sorted(roots))


def _queue_module_inventory(root: Path, diff: ArchitectureDiff, side: str, source_roots: tuple[str, ...]) -> _QueueResolutionCache:
    paths = _repository_paths(root, diff, source_roots) if side == "head" else git_tree_paths(root, diff.base_sha, source_roots)
    modules = {relative.removesuffix("/__init__.py").removesuffix(".py").replace("/", ".") for path in paths for prefix in source_roots if not prefix or _matches(path, (prefix,)) for relative in (path[len(prefix) + 1:] if prefix else path,) if relative.endswith(".py")}
    return _QueueResolutionCache(tuple(sorted(modules)), tuple(sorted(path for path in paths if path.endswith(".py"))), {}, {})


def _prime_local_module_sources(
    root: Path, diff: ArchitectureDiff, modules: set[str], side: str,
    cache: _QueueResolutionCache, source_roots: tuple[str, ...],
    remaining: int,
    budget: _QueueBudget | None = None,
) -> None:
    pending = sorted(module for module in modules if module in cache.modules and module not in cache.values)
    if len(pending) > remaining:
        raise ArchitectureError("queue adapter module limit exceeded", code="limit")
    paths_by_module = {
        module: tuple(path for source_root in source_roots for path in (
            f"{source_root + '/' if source_root else ''}{module.replace('.', '/')}.py",
            f"{source_root + '/' if source_root else ''}{module.replace('.', '/')}/__init__.py",
        ) if path in cache.paths)
        for module in pending
    }
    for module, paths in paths_by_module.items():
        if len(paths) > 1:
            cache.values[module] = _QueueAdapterResolution("unsupported", "ambiguous_local_queue_adapter")
    values = read_diff_files(root, diff, tuple(paths[0] for module, paths in paths_by_module.items() if module not in cache.values and paths), side)
    for module, paths in paths_by_module.items():
        if module in cache.values:
            continue
        sources = tuple((path, values[path], module if path.endswith("/__init__.py") else module.rsplit(".", 1)[0] if "." in module else "") for path in paths if values[path] is not None)
        cache.values[module] = _QueueAdapterResolution("prefetched", "local_module_prefetched", sources=sources)
    if budget is not None:
        for module in sorted(modules):
            cached = cache.values.get(module)
            if cached is not None:
                for path, value, _package in cached.sources:
                    budget.source(path, value)  # Admit bytes before any AST parse or cache use.


def _is_local_package(cache: _QueueResolutionCache, module: str) -> bool:
    package_path = f"{module.replace('.', '/')}/__init__.py"
    return any(path.endswith(package_path) for path in cache.paths) or module not in cache.modules and any(name.startswith(module + ".") for name in cache.modules)


def _module_member_demands(tree: ast.AST, access_name: str, patches: dict | None = None) -> frozenset[str] | None:
    members: set[str] = set()
    covered: set[int] = set()
    patches = literal_patch_members(tree) if patches is None else patches
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and id(node) in patches and patches[id(node)][0] == access_name:
            members.add(patches[id(node)][1])
            covered.add(id(node.args[0]))
        if not isinstance(node, ast.Attribute):
            continue
        parts: list[str] = []
        value: ast.AST = node
        while isinstance(value, ast.Attribute):
            parts.append(value.attr)
            value = value.value
        if isinstance(value, ast.Name):
            chain = '.'.join((value.id, *reversed(parts)))
            if chain.startswith(access_name + '.'):
                members.add(chain[len(access_name) + 1:].split('.')[0])
                covered.add(id(value))
    # Escaping aliases or dynamic access retain the full export closure.
    if any(isinstance(node, ast.Name) and node.id == access_name.split('.')[0]
           and isinstance(node.ctx, ast.Load) and id(node) not in covered for node in ast.walk(tree)):
        return None
    return frozenset(members) or None


def _returned_call_demands(tree: ast.AST, dependencies: frozenset[str], *, returns: bool = False) -> frozenset[str]:
    """Distinguish a callable object from a value returned into an operation."""
    demanded: set[str] = set()
    local_dependencies: dict[int, frozenset[str]] = {}
    if not returns and isinstance(tree, ast.Module):
        for function in ast.walk(tree):
            if not isinstance(function, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            body = ast.Module(body=function.body, type_ignores=[])
            # Sibling functions do not share local bindings. Keep nested scopes
            # together for closures, and retain the conservative module demand
            # for global/nonlocal writes and selected-export return projections.
            if any(isinstance(node, (ast.Global, ast.Nonlocal)) for node in ast.walk(body)):
                continue
            scoped = _operation_dependencies(body)
            if scoped.exhausted:
                continue
            local_dependencies.update((id(node), scoped.names) for node in ast.walk(body)
                                      if isinstance(node, (ast.Assign, ast.AnnAssign, ast.Call)))
    for node in ast.walk(tree):
        values = []
        if isinstance(node, ast.Call):
            values.extend(child for child in ast.walk(node.func) if isinstance(child, ast.Call))
            if (isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name)
                    and node.func.attr in {'append', 'extend'} | _CONTAINER_MUTATORS
                    and node.func.value.id in local_dependencies.get(id(node), dependencies)):
                values.extend(node.args)
                values.extend(item.value for item in node.keywords)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            names = local_dependencies.get(id(node), dependencies)
            if any(isinstance(child, ast.Name) and child.id in names for target in targets for child in ast.walk(target)):
                values.append(node.value)
        elif returns and isinstance(node, (ast.Return, ast.Yield, ast.YieldFrom)):
            values.append(node.value)
        for value in values:
            if value is not None:
                for call in ast.walk(value):
                    if isinstance(call, ast.Call):
                        parts = []
                        function = call.func
                        while isinstance(function, ast.Attribute):
                            parts.append(function.attr)
                            function = function.value
                        if isinstance(function, ast.Name):
                            demanded.add('.'.join((function.id, *reversed(parts))))
                        else:
                            pending = [call.func]
                            while pending:
                                child = pending.pop()
                                if isinstance(child, ast.Call):
                                    continue  # its own return demand is collected separately
                                if isinstance(child, ast.Name):
                                    demanded.add(child.id)
                                pending.extend(ast.iter_child_nodes(child))
    return frozenset(demanded)


def _plain_callable_declaration(tree: ast.Module, requested: frozenset[str] | None) -> bool:
    """A stable undecorated function object is ordinary; this says nothing about its return."""
    if not requested:
        return False
    definitions = {node.name: node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    if not requested <= definitions.keys() or any(definitions[name].decorator_list for name in requested):
        return False
    # Python binds names through more nodes than Name(Store). Inspect these
    # across conditional and nested bodies; uncertainty falls back to analysis.
    if any((isinstance(node, (ast.Global, ast.Nonlocal)) and requested.intersection(node.names))
           or (isinstance(node, ast.alias) and (node.name == '*' or (node.asname or node.name.split('.')[0]) in requested))
           or (isinstance(node, ast.ExceptHandler) and node.name in requested)
           or (isinstance(node, (ast.MatchAs, ast.MatchStar)) and node.name in requested)
           or (isinstance(node, ast.MatchMapping) and node.rest in requested)
           or (isinstance(node, ast.Name) and node.id in requested and isinstance(node.ctx, (ast.Store, ast.Del)))
           or (isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
               and node.func.id in {'exec', 'eval', 'globals', 'locals', 'setattr', 'delattr'})
           or (isinstance(node, ast.Attribute) and isinstance(node.ctx, (ast.Store, ast.Del))
               and any(isinstance(part, ast.Name) and part.id in requested for part in ast.walk(node.value)))
           for node in ast.walk(tree)):
        return False
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node is definitions.get(node.name):
            continue
        if any((isinstance(child, ast.Name) and child.id in requested and isinstance(child.ctx, (ast.Store, ast.Del)))
               or (isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and child.name in requested)
               or (isinstance(child, ast.Call) and isinstance(child.func, ast.Name)
                   and child.func.id in {'exec', 'eval', 'globals', 'locals', 'setattr', 'delattr'})
               for child in ast.walk(node)):
            return False
    return True


def _aliased_callable_mutation(tree: ast.Module, requested: frozenset[str] | None) -> bool:
    functions = {node.name for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}
    original = functions & set(requested or ())
    aliases = set(original)
    for _ in range(MAX_QUEUE_DEPENDENCY_WORK):
        previous = set(aliases)
        for node in tree.body:
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Name) and node.value.id in aliases:
                aliases.update(target.id for target in node.targets if isinstance(target, ast.Name))
        if aliases == previous:
            break
    else:
        raise ArchitectureError('callable alias dependency limit exceeded', code='limit')
    return bool(aliases - original) and any(
        isinstance(node, ast.Attribute) and isinstance(node.ctx, (ast.Store, ast.Del))
        and isinstance(node.value, ast.Name) and node.value.id in aliases
        for node in ast.walk(tree))


@lru_cache(maxsize=128)
def _queue_source_tree(path: str, source: bytes) -> ast.Module:
    try:
        tree = ast.parse(source.decode('utf-8'), filename=path)
    except (SyntaxError, UnicodeDecodeError) as exc:
        raise ArchitectureError(f'local queue source is not analyzable: {path}', code='fitness') from exc
    if sum(1 for _ in ast.walk(tree)) > MAX_ANALYZED_AST_NODES:
        raise ArchitectureError(f'Python AST node limit exceeded: {path}', code='limit')
    return tree


@lru_cache(maxsize=128)
def _queue_source_node_count(path: str, source: bytes) -> int:
    return sum(1 for _ in ast.walk(_queue_source_tree(path, source)))


def _budgeted_queue_tree(path: str, source: bytes, budget: _QueueBudget) -> ast.Module:
    budget.source(path, source)
    tree = _queue_source_tree(path, source)
    budget.source(path, source, _queue_source_node_count(path, source))
    return tree


def _local_queue_resolution(
    root: Path,
    diff: ArchitectureDiff,
    module: str,
    side: str,
    cache: _QueueResolutionCache,
    resolving: set[str],
    visited: set[str],
    source_roots: tuple[str, ...],
    requested: frozenset[str] | None = None,
    callable_only: bool = False,
    budget: _QueueBudget | None = None,
) -> _QueueAdapterResolution:
    budget = budget if budget is not None else _QueueBudget(side)
    original_key = (module, requested, callable_only)
    prefetched = cache.values.get(module)
    source_identity = tuple((path, hashlib.sha256(value).hexdigest())
                            for path, value, _package in prefetched.sources) if prefetched else ()
    work_key = repr((side, module, tuple(sorted(requested)) if requested is not None else None,
                     callable_only, source_identity))
    frame = budget.enter(work_key)
    try:
        budget.step(request=True)
        cached = cache.demands.get(original_key)
        if cached is not None and cached.footprint is None:
            raise ArchitectureError('queue cached resource footprint is unavailable', code='limit')
        result = _local_queue_resolution_impl(root, diff, module, side, cache, resolving, visited,
            source_roots, requested, callable_only, budget)
        budget.merge(result.footprint)
    except BaseException:
        budget.leave(frame)
        raise
    footprint = budget.leave(frame)
    bounded = result._replace(footprint=footprint)
    if cache.demands.get(original_key) is result:
        cache.demands[original_key] = bounded
    return bounded


def _local_queue_resolution_impl(
    root: Path,
    diff: ArchitectureDiff,
    module: str,
    side: str,
    cache: _QueueResolutionCache,
    resolving: set[str],
    visited: set[str],
    source_roots: tuple[str, ...],
    requested: frozenset[str] | None,
    callable_only: bool,
    budget: _QueueBudget,
) -> _QueueAdapterResolution:
    if (
        not module
        or any(re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", part) is None for part in module.split("."))
    ):
        return _QueueAdapterResolution("not_queue", "invalid_local_module")
    if module not in cache.modules:
        return _QueueAdapterResolution("not_queue", "local_module_missing")
    prefetched = cache.values.get(module)
    demand_key = (module, requested, callable_only)
    cached_declaration = cache.demands.get(demand_key)
    if callable_only and cached_declaration is not None and not cached_declaration.modules:
        return cached_declaration
    if callable_only and prefetched is not None and prefetched.sources:
        # Declaration inspection does not expand a dependency. It is bounded by
        # the prefetched module batch and AST node cap, unlike recursive returns.
        source_path, value, _package = prefetched.sources[0]
        declaration = _budgeted_queue_tree(source_path, value, budget)
        if _aliased_callable_mutation(declaration, requested):
            raise ArchitectureError('aliased callable attribute mutation is unsupported', code='fitness')
        if _plain_callable_declaration(declaration, requested):
            result = _QueueAdapterResolution('not_queue', 'local_module_not_queue', declared_exports=_declared_module_exports(declaration))
            cache.demands[demand_key] = result
            return result
    if module not in visited:
        if len(visited) >= MAX_QUEUE_ADAPTER_MODULES:
            raise ArchitectureError("queue adapter module limit exceeded", code="limit")
        visited.add(module)
    if prefetched is not None and prefetched.state != "prefetched":
        return prefetched
    if module in resolving:
        return _QueueAdapterResolution("unsupported", "cyclic_local_queue_adapter")
    if len(resolving) >= MAX_QUEUE_ADAPTER_DEPTH:
        raise ArchitectureError("queue adapter depth limit exceeded", code="limit")
    cached = cache.demands.get(demand_key)
    if cached is not None and not (cached.modules & resolving):
        if len(visited | cached.modules) > MAX_QUEUE_ADAPTER_MODULES:
            raise ArchitectureError('queue adapter module limit exceeded', code='limit')
        if len(resolving) + cached.height > MAX_QUEUE_ADAPTER_DEPTH:
            raise ArchitectureError('queue adapter depth limit exceeded', code='limit')
        visited.update(cached.modules)
        return cached
    resolving.add(module)
    try:
        sources = prefetched.sources if prefetched is not None else ()
        if not sources:
            result = _QueueAdapterResolution("not_queue", "local_module_missing")
            cache.values[module] = result
            return result
        source_path, value, current_package = sources[0]
        tree = _budgeted_queue_tree(source_path, value, budget)
        declared = _declared_module_exports(tree)
        requested = requested if requested is not None else frozenset(declared)
        if _aliased_callable_mutation(tree, requested):
            raise ArchitectureError('aliased callable attribute mutation is unsupported', code='fitness')
        tree = _queue_export_slice(tree, requested)
        imported = _queue_adapter_names(
            root,
            diff,
            tree,
            side,
            cache,
            resolving,
            visited,
            current_package=current_package,
            source_roots=source_roots,
            requested=requested or frozenset(),
            budget=budget,
        )
        try:
            analysis = analyze_queue_tree(tree, imported.names)
        except QueueAnalysisLimit as exc:
            raise ArchitectureError(str(exc), code="limit") from exc
        # A projection with no queue imports, values or effects cannot create a
        # queue return. Avoid reslicing every ordinary helper in that case.
        try:
            factories = _queue_return_exports_scoped(tree, imported.names, None, 0, budget) if analysis.signals or imported.names else set()
        except QueueAnalysisLimit as exc:
            raise ArchitectureError(str(exc), code='limit') from exc
        if factories:
            # The adapter value models a callable's returned queue. Preserve the
            # selected function body for operation checks, then expose its return
            # summary before subsequent assignments such as app = make_queue().
            body = []
            aliases = {'__getzilla_factory_' + name for name in factories}
            if any(isinstance(node, ast.Name) and node.id in aliases for node in ast.walk(tree)):
                raise ArchitectureError('factory projection name collision', code='fitness')
            for node in tree.body:
                body.append(node)
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name in factories:
                    alias = '__getzilla_factory_' + node.name
                    body.append(ast.Assign(targets=[ast.Name(id=node.name, ctx=ast.Store())], value=ast.Name(id=alias, ctx=ast.Load())))
            try:
                analysis = analyze_queue_tree(ast.Module(body=body, type_ignores=[]), imported.names | aliases)
            except QueueAnalysisLimit as exc:
                raise ArchitectureError(str(exc), code='limit') from exc
        exports = set(analysis.export_paths) - {'__getzilla_factory_' + name for name in factories}
        exports = tuple(sorted(exports))
        has_queue_provenance = bool(analysis.signals or exports)
        state = (
            "unsupported"
            if (imported.unsupported or analysis.uncertain) and has_queue_provenance
            else ("resolved" if has_queue_provenance else "not_queue")
        )
        reason = "local_queue_provenance_resolved" if has_queue_provenance else "local_module_not_queue"
        result = _QueueAdapterResolution(
            state, reason, exports, analysis.signals, declared,
            modules=imported.modules | {module}, height=imported.height + 1,
        )
        # Side/source bytes belong to this snapshot cache; a completed summary
        # additionally binds the export demand, transitive module cost and depth.
        if state != 'unsupported':
            cache.demands[demand_key] = result
        return result
    finally:
        resolving.remove(module)


def _queue_adapter_names(
    root: Path,
    diff: ArchitectureDiff,
    tree: ast.AST,
    side: str,
    cache: _QueueResolutionCache,
    resolving: set[str] | None = None,
    visited: set[str] | None = None,
    *, current_package: str = "",
    source_roots: tuple[str, ...],
    requested: frozenset[str] = frozenset(),
    budget: _QueueBudget | None = None,
) -> _QueueAdapterNamesResult:
    budget = budget if budget is not None else _QueueBudget(side)
    proven: set[str] = set()
    unsupported = False
    modules: set[str] = set()
    height = 0
    active = resolving if resolving is not None else set()
    seen = visited if visited is not None else set()
    dependency_result = _operation_dependencies(tree, requested=requested)
    dependencies = set(dependency_result.names)
    return_demands = _returned_call_demands(tree, dependency_result.names, returns=bool(requested))
    patches = literal_patch_members(tree)
    member_demands: dict[str, frozenset[str] | None] = {}

    def demanded_members(access_name: str) -> frozenset[str] | None:
        if access_name not in member_demands:
            member_demands[access_name] = _module_member_demands(tree, access_name, patches)
        return member_demands[access_name]

    def resolve_import(module: str, members: frozenset[str] | None, *, split: bool) -> _QueueAdapterResolution:
        if not split or not members:
            return _local_queue_resolution(root, diff, module, side, cache, active, seen,
                source_roots[:MAX_QUEUE_SOURCE_ROOTS], requested=members,
                callable_only=local_name not in requested and local_name not in return_demands, budget=budget)
        results = []
        for member in sorted(members):
            prefix = access_name + '.' + member
            returned = local_name in requested or local_name in return_demands or any(
                value == prefix or value.startswith(prefix + '.') for value in return_demands)
            results.append(_local_queue_resolution(root, diff, module, side, cache, active, seen,
                source_roots[:MAX_QUEUE_SOURCE_ROOTS], requested=frozenset({member}), callable_only=not returned, budget=budget))
        if len(results) == 1:
            return results[0]
        state = ('unsupported' if any(item.state == 'unsupported' for item in results)
                 else 'resolved' if any(item.state == 'resolved' for item in results) else 'not_queue')
        missing = all(item.reason == 'local_module_missing' for item in results)
        return _QueueAdapterResolution(state, 'local_module_missing' if missing else
            'local_queue_provenance_resolved' if state != 'not_queue' else 'local_module_not_queue',
            tuple(sorted({name for item in results for name in item.exports})),
            tuple(sorted({signal for item in results for signal in item.signals})),
            tuple(sorted({name for item in results for name in item.declared_exports})),
            modules=frozenset(name for item in results for name in item.modules),
            height=max(item.height for item in results))

    for _target, _member, replacement, factory in patches.values():
        names = frozenset(node.id for node in ast.walk(replacement) if isinstance(node, ast.Name)) if replacement is not None else frozenset()
        dependencies.update(names)
        if factory:
            return_demands |= names
    reachable = dependencies | set(dependency_result.frontier)
    normalized: list[tuple[str, str, str, str, int, bool, bool]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imports = tuple((alias.name, "", alias.asname or alias.name.split(".", 1)[0], alias.asname or alias.name, 0, True, False) for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            module = _resolve_import_module(current_package, node.module, node.level)
            imports = tuple((
                module,
                alias.name,
                alias.asname or alias.name,
                alias.asname or alias.name,
                node.level, False, alias.name == "*",
            ) for alias in node.names)
        else:
            continue
        normalized.extend(imports)
    relevant = [item for item in normalized if item[0].split(".")[0] not in _QUEUE_IMPORTS and (item[6] and reachable or item[2] in dependencies or item[2] in dependency_result.frontier_imports)]
    _prime_local_module_sources(root, diff, {item[0] for item in relevant}, side, cache, source_roots[:MAX_QUEUE_SOURCE_ROOTS], MAX_QUEUE_ADAPTER_MODULES - len(seen), budget)
    for target_module, target_name, local_name, access_name, level, whole_module, wildcard in normalized:
            if target_module.split(".")[0] in _QUEUE_IMPORTS or not (wildcard and reachable or local_name in dependencies or local_name in dependency_result.frontier_imports):
                continue
            queue_adjacent = _queue_adjacent_module(target_module)
            frontier_reachable = local_name in dependency_result.frontier_imports
            if len(source_roots) > MAX_QUEUE_SOURCE_ROOTS and (queue_adjacent or frontier_reachable):
                proven.add(local_name)
                unsupported = True
                continue
            bounded_source_roots = source_roots[:MAX_QUEUE_SOURCE_ROOTS]
            resolution = resolve_import(target_module,
                (frozenset({target_name}) if target_name and not wildcard else
                 frozenset(reachable) if wildcard else demanded_members(access_name)),
                split=whole_module and not wildcard)
            modules.update(resolution.modules)
            height = max(height, resolution.height if resolution.modules else 0)
            if target_name and not wildcard and target_name not in resolution.declared_exports and _is_local_package(cache, target_module):
                target_module, target_name, whole_module = f"{target_module}.{target_name}", "", True
                _prime_local_module_sources(root, diff, {target_module}, side, cache, bounded_source_roots, MAX_QUEUE_ADAPTER_MODULES - len(seen), budget)
                resolution = resolve_import(target_module, demanded_members(access_name), split=True)
                modules.update(resolution.modules)
                height = max(height, resolution.height if resolution.modules else 0)
                queue_adjacent = _queue_adjacent_module(target_module)
            export_resolved = (
                (target_name and any(value == target_name or value.startswith(target_name + '.') for value in resolution.exports))
                or (not target_name and bool(resolution.exports))
            )
            if target_name and not wildcard:
                members = [value[len(target_name):] for value in resolution.exports if value.startswith(target_name + '.')]
                if members:
                    proven.update(local_name + member for member in members)
                    if target_name not in resolution.exports:
                        continue
            local_values = tuple(sorted(name for name in reachable & set(resolution.exports) if not name.startswith('_'))) if wildcard else (local_name,)
            if whole_module and resolution.reason in {"local_queue_provenance_resolved", "local_module_not_queue"}:
                proven.update(f"{access_name}.{export}" for export in resolution.exports)
                unsupported = unsupported or bool(resolution.exports)
                continue
            if (frontier_reachable or whole_module or wildcard) and (
                level > 0
                or resolution.reason != "local_module_missing"
                or any(name == target_module.split(".", 1)[0] or name.startswith(target_module.split(".", 1)[0] + ".") for name in cache.modules)
            ):
                declared = resolution.reason == "local_module_not_queue" and (
                    whole_module or wildcard or target_name in resolution.declared_exports)
                if declared or wildcard and not local_values and (
                    resolution.reason == "local_queue_provenance_resolved"
                ):
                    continue
                proven.update(local_values or reachable)
                unsupported = True
                continue
            if (
                len(source_roots) > MAX_QUEUE_SOURCE_ROOTS
                and resolution.state == "resolved"
                and export_resolved
            ):
                proven.add(local_name)
                unsupported = True
                continue
            if resolution.state == "unsupported" and export_resolved:
                proven.add(local_name)
                unsupported = True
                continue
            if (
                resolution.state == "unsupported"
                and queue_adjacent
            ):
                raise ArchitectureError(
                    f"relevant local queue adapter is unsupported: {target_module}"
                    f" ({resolution.reason})",
                    code="fitness",
                )
            if (
                not resolution.exports
                and queue_adjacent
                and (
                    level > 0
                    or any(name == target_module.split(".", 1)[0] or name.startswith(target_module.split(".", 1)[0] + ".") for name in cache.modules)
                )
                and resolution.reason == "local_module_missing"
            ):
                raise ArchitectureError(
                    f"relevant local queue adapter is unresolved: {target_module}",
                    code="fitness",
                )
            if (
                target_name
                and target_name not in resolution.exports
                and resolution.state == "resolved"
                and queue_adjacent
            ):
                raise ArchitectureError(
                    f"relevant local queue adapter export is unresolved: "
                    f"{target_module}.{target_name}",
                    code="fitness",
                )
            if (
                target_name and target_name in resolution.exports
            ) or (not target_name and resolution.exports):
                proven.add(local_name)
    return _QueueAdapterNamesResult(frozenset(proven), unsupported, frozenset(modules), height)


def _queue_signals(
    root: Path,
    diff: ArchitectureDiff,
    tree: ast.AST,
    side: str,
    cache: _QueueResolutionCache,
    current_package: str,
    source_roots: tuple[str, ...],
    *, source_path: str = '<importer>', source: bytes | None = None,
    budget: _QueueBudget | None = None,
) -> _QueueProvenanceResult:
    budget = budget if budget is not None else _QueueBudget(side)
    source = source if source is not None else ast.unparse(tree).encode('utf-8')
    budget.source(source_path, source)
    budget.source(source_path, source, sum(1 for _ in ast.walk(tree)))
    budget.step(request=True)
    adapters = _queue_adapter_names(
        root,
        diff,
        tree,
        side,
        cache,
        current_package=current_package,
        source_roots=source_roots,
        budget=budget,
    )
    try:
        analysis = analyze_queue_tree(tree, adapters.names)
    except QueueAnalysisLimit as exc:
        raise ArchitectureError(str(exc), code="limit") from exc
    unresolved = bool((adapters.unsupported or analysis.uncertain) and analysis.signals)
    return _QueueProvenanceResult(
        "unsupported" if unresolved else ("resolved" if analysis.signals else "not_queue"),
        "queue_provenance_unresolved" if unresolved else ("queue_signals_resolved" if analysis.signals else "no_queue_signal"),
        analysis.signals)


def _new_queue_sources(
    root: Path,
    diff: ArchitectureDiff,
    python: _PythonInventory,
    source_roots: tuple[str, ...],
) -> _QueueProvenanceResult:
    applicable: list[str] = []
    unsupported: list[str] = []
    changed_signals: set[str] = set()
    limits: list[tuple[str, str, str]] = []
    head_cache = _queue_module_inventory(root, diff, "head", source_roots)
    base_cache = _queue_module_inventory(root, diff, "base", source_roots)
    for path in _python_paths(diff):
        side = "head"
        try:
            current_package = _module_package(path, source_roots, head_cache.paths)
            head_value = read_diff_file(root, diff, path, 'head') or b''
            head_budget = _QueueBudget('head')
            head_budget.source(path, head_value)
            head = _queue_signals(
                root,
                diff,
                python.tree(path),
                "head",
                head_cache,
                current_package,
                source_roots,
                source_path=path, source=head_value, budget=head_budget,
            )
            side = "base"
            base_value = read_diff_file(root, diff, path, "base")
            base = _QueueProvenanceResult("not_queue", "no_base_source", ())
            if base_value is not None:
                base_budget = _QueueBudget('base')
                base_budget.source(path, base_value)
                base_tree = ast.parse(base_value.decode("utf-8"), filename=path)
                if sum(1 for _ in ast.walk(base_tree)) > MAX_ANALYZED_AST_NODES:
                    raise ArchitectureError(f"Python AST node limit exceeded: {path}", code="limit")
                base = _queue_signals(
                    root,
                    diff,
                    base_tree,
                    "base",
                    base_cache,
                    current_package,
                    source_roots,
                    source_path=path, source=base_value, budget=base_budget,
                )
            delta = set(head.signals) - set(base.signals)
            if delta:
                changed_signals.update(f"{path}:{signal}" for signal in delta)
                if head.state == "unsupported":
                    unsupported.append(path)
                else:
                    applicable.append(path)
        except ArchitectureError as exc:
            if exc.code == "limit":
                limits.append((path, side, str(exc)))
            else:
                unsupported.append(path)
                changed_signals.add(f"{path}:unsupported:{exc.code}")
        except (SyntaxError, UnicodeDecodeError):
            value = read_diff_file(root, diff, path, "head") or b""
            if re.search(
                rb"\b(celery|rq|redis|kombu|pika|kafka|confluent_kafka|enqueue|apply_async|send_task)\b",
                value,
            ):
                unsupported.append(path)
                changed_signals.add(f"{path}:unsupported:syntax")
    if unsupported or limits:
        return _QueueProvenanceResult(
            "unsupported",
            "analysis_limit_exceeded" if limits else "queue_provenance_unresolved",
            tuple(sorted(changed_signals)),
            tuple(sorted(set((*applicable, *unsupported)))),
            tuple(sorted(limits)),
        )
    if applicable:
        return _QueueProvenanceResult(
            "resolved",
            "new_queue_signal",
            tuple(sorted(changed_signals)),
            tuple(sorted(set(applicable))),
        )
    return _QueueProvenanceResult("not_queue", "no_queue_signal", ())


def _background_jobs(
    root: Path,
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
    queue_provenance: _QueueProvenanceResult,
) -> FitnessResult:
    rules = snapshot.rules["background_job_policies"]
    predicate = "declared background edges and exact changed-source queue signals are governed"
    source_scope = queue_provenance.paths
    if queue_provenance.limits:
        return _result(
            "background_job", status="unsupported",
            rules=(rule["id"] for rule in rules),
            findings=(f"analysis limit exceeded ({side}): {path}: {message}"
                      for path, side, message in queue_provenance.limits),
            predicate=predicate,
            scope=(*source_scope, *(item[0] for item in queue_provenance.limits)),
            reason="analysis_limit_exceeded",
        )
    if not rules:
        if source_scope:
            return _result(
                "background_job",
                status="unsupported",
                findings=(
                    f"unsupported changed-source background job semantics: {path}"
                    for path in source_scope
                ),
                predicate=predicate,
                scope=source_scope,
                reason="source_signal_without_policy",
            )
        return _not_applicable("background_job", predicate, (), "no_declared_rules")
    if not _model_changed(diff) and not source_scope:
        return _not_applicable(
            "background_job", predicate, _python_paths(diff), "no_background_signal", (rule["id"] for rule in rules)
        )
    nodes = {node["id"]: node for node in snapshot.system["nodes"]}
    findings: list[str] = []
    scope: list[str] = []
    if source_scope:
        scope.extend(source_scope)
        findings.extend(
            f"unsupported changed-source background job semantics: {path}"
            for path in source_scope
        )
    for rule in rules:
        for edge in snapshot.system["edges"]:
            node = nodes[edge["from"]]
            if node["type"] not in rule["node_types"] or edge["sync_or_async"] == "synchronous":
                continue
            scope.append(edge["id"])
            behavior = edge["failure_behavior"]
            if behavior["max_retries"] > rule["max_retries"]:
                findings.append(f"{rule['id']}: {edge['id']} exceeds bounded retries")
            if (
                rule["require_idempotency"]
                and behavior["max_retries"] > 0
                and behavior["idempotency"] != "required"
            ):
                findings.append(f"{rule['id']}: {edge['id']} lacks retry idempotency")
            if rule["require_correlation_id"] and behavior["correlation_id"] != "required":
                findings.append(f"{rule['id']}: {edge['id']} lacks correlation id")
            if behavior["terminal_action"] not in rule["terminal_actions"]:
                findings.append(f"{rule['id']}: {edge['id']} has unsupported terminal action")
            if not behavior["observable_signal"]:
                findings.append(f"{rule['id']}: {edge['id']} lacks observable failure")
    if not scope:
        return _not_applicable(
            "background_job", predicate, (), "no_background_edge", (rule["id"] for rule in rules)
        )
    return _result(
        "background_job",
        status="unsupported" if source_scope else ("fail" if findings else "pass"),
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=scope,
        reason=queue_provenance.reason if source_scope else "applicable",
    )


def _secret_flows(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["secret_flow_policies"]
    predicate = "declared secret classes are held or flow across architecture trust domains"
    if not rules:
        return _not_applicable("secret_flow", predicate, (), "no_declared_rules")
    if not _model_changed(diff):
        return _not_applicable(
            "secret_flow", predicate, (), "architecture_unchanged", (rule["id"] for rule in rules)
        )
    nodes = {node["id"]: node for node in snapshot.system["nodes"]}
    findings: list[str] = []
    scope: list[str] = []
    for rule in rules:
        secrets = set(rule["secret_classes"])
        allowed = set(rule["allowed_trust_domains"])
        for node in nodes.values():
            if secrets & set(node["secrets"]):
                scope.append(node["id"])
                if node["trust_domain"] not in allowed:
                    findings.append(f"{rule['id']}: secret held by untrusted node {node['id']}")
        for edge in snapshot.system["edges"]:
            if edge["type"] == "secret_flow":
                scope.append(edge["id"])
                if nodes[edge["from"]]["trust_domain"] not in allowed or nodes[edge["to"]]["trust_domain"] not in allowed:
                    findings.append(f"{rule['id']}: secret flow crosses untrusted edge {edge['id']}")
    if not scope:
        return _not_applicable(
            "secret_flow", predicate, (), "no_governed_secret_subject", (rule["id"] for rule in rules)
        )
    return _result(
        "secret_flow",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=scope,
    )


def _workspace_trust(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> FitnessResult:
    rules = snapshot.rules["workspace_trust_policies"]
    predicate = "repository/runner nodes are checked for forbidden trust material"
    if not rules:
        return _not_applicable("workspace_trust", predicate, (), "no_declared_rules")
    if not _model_changed(diff):
        return _not_applicable(
            "workspace_trust", predicate, (), "architecture_unchanged", (rule["id"] for rule in rules)
        )
    findings: list[str] = []
    scope: list[str] = []
    for rule in rules:
        for node in snapshot.system["nodes"]:
            if node["type"] not in rule["node_types"]:
                continue
            scope.append(node["id"])
            forbidden = set(node["secrets"]) & set(rule["forbidden_secret_classes"])
            if forbidden:
                findings.append(
                    f"{rule['id']}: {node['id']} exposes forbidden secrets {','.join(sorted(forbidden))}"
                )
    return _result(
        "workspace_trust",
        status="fail" if findings else "pass",
        rules=(rule["id"] for rule in rules),
        findings=findings,
        predicate=predicate,
        scope=scope,
    )


def _risk_triggers(snapshot: ArchitectureSnapshot, diff: ArchitectureDiff) -> tuple[str, ...]:
    triggers: set[str] = set()
    before_nodes = {
        node["id"]: node for node in (diff._base_state.snapshot.system["nodes"] if diff._base_state else [])
    }
    after_nodes = {node["id"]: node for node in snapshot.system["nodes"]}
    for change in diff.changes:
        if change.change != "added" and change.kind not in {"node", "runtime"}:
            continue
        if change.kind == "edge" and change.change == "added":
            triggers.add("new_edge")
        elif change.kind == "contract" and change.change == "added":
            triggers.add("new_contract")
        elif change.kind == "secret" and change.change == "added":
            triggers.add("new_secret")
    for identity, node in after_nodes.items():
        old = before_nodes.get(identity)
        if old is None or old["type"] != node["type"]:
            mapping = {
                "datastore": "new_datastore",
                "external_system": "new_external_integration",
                "runner": "new_job",
                "service": "new_service",
                "worker": "new_job",
            }
            if node["type"] in mapping:
                triggers.add(mapping[node["type"]])
        if old is None or set(node["secrets"]) - set(old["secrets"]):
            if node["secrets"]:
                triggers.add("new_secret")
    nodes = after_nodes
    for change in diff.changes:
        if change.kind == "edge" and change.change == "added":
            edge = next(item for item in snapshot.system["edges"] if item["id"] == change.id)
            if nodes[edge["from"]]["trust_domain"] != nodes[edge["to"]]["trust_domain"]:
                triggers.add("new_trust_crossing")
    for artifact in diff.artifacts:
        name = PurePosixPath(artifact.path).name.lower()
        if artifact.status == "added" and name in {
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "go.mod",
            "cargo.toml",
        }:
            triggers.add("new_framework")
    return tuple(sorted(triggers))


def _new_import_family(
    root: Path,
    diff: ArchitectureDiff,
    python: _PythonInventory,
    families: set[str],
) -> bool:
    for path in _python_paths(diff):
        try:
            head_imports = {name.split(".")[0] for name in _imports(python.tree(path))}
            base_value = read_diff_file(root, diff, path, "base")
            base_imports = set()
            if base_value is not None:
                base_tree = ast.parse(base_value.decode("utf-8"), filename=path)
                base_imports = {name.split(".")[0] for name in _imports(base_tree)}
            if (head_imports - base_imports) & families:
                return True
        except (SyntaxError, UnicodeDecodeError):
            continue
    return False


def _network_families(tree: ast.AST, project_roots: set[str]) -> set[str]:
    values = {
        imported for imported in _import_targets(tree) if _network_protocol(imported) is not None
    }
    for imported, call in _called_imports(tree):
        if _network_protocol(imported) is not None:
            values.add(imported)
        elif _network_call_is_applicable(imported, call, project_roots):
            values.add(f"unsupported:{call}")
    return values


def _new_network_client(
    root: Path,
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
) -> bool:
    project_roots = _project_import_roots(snapshot, diff, root)
    for path in _python_paths(diff):
        try:
            head = _network_families(python.tree(path), project_roots)
            base_value = read_diff_file(root, diff, path, "base")
            base = set() if base_value is None else _network_families(
                ast.parse(base_value.decode("utf-8"), filename=path), project_roots
            )
            if head - base:
                return True
        except (SyntaxError, UnicodeDecodeError):
            continue
    return False


def _risk(
    root: Path,
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    python: _PythonInventory,
    pre_risk: str,
    queue_provenance: _QueueProvenanceResult,
) -> tuple[str, str, tuple[str, ...]]:
    if pre_risk not in RISK_ORDER:
        raise ArchitectureError("pre_risk must be green, yellow, or red", code="risk")
    triggers = set(_risk_triggers(snapshot, diff))
    if queue_provenance.signals:
        triggers.add("new_queue")
    if _new_network_client(root, snapshot, diff, python):
        triggers.add("new_network_client")
    if _new_import_family(root, diff, python, _FRAMEWORK_IMPORTS):
        triggers.add("new_framework")
    escalation = "green"
    for rule in snapshot.rules["risk_escalations"]:
        if triggers & set(rule["triggers"]) and RISK_ORDER[rule["risk"]] > RISK_ORDER[escalation]:
            escalation = rule["risk"]
    post = max((pre_risk, escalation), key=RISK_ORDER.__getitem__)
    return escalation, post, tuple(sorted(triggers))


def _result_payload(result: FitnessResult) -> dict[str, Any]:
    return {
        "category": result.category,
        "status": result.status,
        "rule_ids": result.rule_ids,
        "findings": result.findings,
        "applicability": {
            "predicate": result.applicability.predicate,
            "scanned_scope": result.applicability.scanned_scope,
            "reason_code": result.applicability.reason_code,
            "inventory_digest": result.applicability.inventory_digest,
        },
    }


_CATEGORY_RULES = {
    "background_job": "background_job_policies",
    "change_separation": "change_separation_policies",
    "code_budget": "code_budgets",
    "contract_compatibility": "contract_policies",
    "forbidden_edge": "forbidden_edges",
    "migration_safety": "migration_policies",
    "module_boundary": "path_boundaries",
    "network_client": "network_policies",
    "tenant_authorization": "tenant_authorization_policies",
    "workspace_trust": "workspace_trust_policies",
}


def _bind_applicability_inventory(
    root: Path,
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    result: FitnessResult,
) -> FitnessResult:
    collection = (
        "secret_flow_policies"
        if result.category == "secret_flow"
        else _CATEGORY_RULES.get(result.category)
    )
    rules = [] if collection is None else snapshot.rules[collection]
    scope = set(result.applicability.scanned_scope)
    scope.update(rule["id"] for rule in rules)
    for rule in rules:
        for key, value in rule.items():
            if key.endswith("prefixes") and isinstance(value, list):
                scope.update(item for item in value if isinstance(item, str))
    if result.category == "contract_compatibility":
        scope.update(record.id for record in diff._head_state.contracts)
    model_ids = {
        item["id"]
        for collection_name in (
            "trust_domains", "data_classifications", "secret_classes", "nodes", "edges", "signals"
        )
        for item in snapshot.system[collection_name]
    }
    payload = {
        "category": result.category,
        "predicate": result.applicability.predicate,
        "reason_code": result.applicability.reason_code,
        "scanned_scope": tuple(sorted(scope)),
        "repository_inventory_digest": diff.repository_inventory_digest,
        "architecture_digest": diff.head_architecture_digest,
        "model_ids": tuple(sorted(model_ids)),
        "rules": rules,
        "contracts": [
            {
                "id": record.id,
                "kind": record.kind,
                "path": record.path,
                "version": record.version,
                "role": record.role,
                "compatibility": record.compatibility,
                "document_digest": record.digest,
            }
            for record in diff._head_state.contracts
        ] if result.category == "contract_compatibility" else [],
    }
    return replace(
        result,
        applicability=replace(
            result.applicability,
            scanned_scope=tuple(sorted(scope)),
            inventory_digest=_digest(payload),
        ),
    )


def evaluate_fitness(
    root: Path | str,
    snapshot: ArchitectureSnapshot,
    diff: ArchitectureDiff,
    changed_paths: Iterable[str],
    *,
    pre_risk: str,
) -> FitnessReport:
    repository = Path(root).resolve(strict=True)
    supplied_paths = tuple(sorted(set(changed_paths)))
    if supplied_paths != diff.changed_paths:
        raise ArchitectureError("changed_paths must exactly match the architecture diff", code="fitness")
    if architecture_digests(snapshot)["architecture_digest"] != diff.head_architecture_digest:
        raise ArchitectureError("fitness snapshot does not match the diff head", code="fitness")
    python = _PythonInventory(repository, diff)
    queue_provenance = _new_queue_sources(
        repository, diff, python, _queue_source_roots(snapshot)
    )
    raw_results = tuple(
        sorted(
            (
                _background_jobs(
                    repository, snapshot, diff, python, queue_provenance
                ),
                _change_separation(snapshot, diff),
                _code_budget(snapshot, diff, python),
                _contract_compatibility(snapshot, diff),
                _forbidden_edges(snapshot, diff),
                _governance_promotion(repository, diff),
                _migration_safety(repository, snapshot, diff),
                _module_boundaries(snapshot, diff, python),
                _network_clients(snapshot, diff, python),
                _production_imports(diff, python),
                _secret_flows(snapshot, diff),
                _tenant_authorization(snapshot, diff),
                _workspace_trust(snapshot, diff),
            ),
            key=lambda item: item.category,
        )
    )
    results = tuple(
        _bind_applicability_inventory(repository, snapshot, diff, result)
        for result in raw_results
    )
    if tuple(item.category for item in results) != FITNESS_CATEGORIES:
        raise ArchitectureError("mandatory fitness category coverage is incomplete", code="fitness")
    escalation, post_risk, triggers = _risk(
        repository, snapshot, diff, python, pre_risk, queue_provenance
    )
    architecture_significant = diff.baseline_introduced or bool(diff.changes or triggers)
    docs_only = bool(diff.changed_paths) and all(
        _matches(path, ("docs",)) or path.endswith(".md") for path in diff.changed_paths
    )
    exemption_state = "eligible" if docs_only and not architecture_significant else "revoked"
    scopes = set()
    trigger_set = set(triggers)
    if architecture_significant:
        scopes.add("architecture")
    if trigger_set & {"new_network_client", "new_secret", "new_trust_crossing"}:
        scopes.add("security")
    if trigger_set & {"new_datastore"} or any(
        item.category == "migration_safety" and item.status != "not_applicable" for item in results
    ):
        scopes.add("data")
    if trigger_set & {"new_contract"}:
        scopes.add("contract")
    overall = "fail" if any(item.status in {"fail", "unsupported"} for item in results) else "pass"
    payload = {
        "results": [_result_payload(item) for item in results],
        "status": overall,
        "pre_risk": pre_risk,
        "escalation": escalation,
        "post_risk": post_risk,
        "triggers": triggers,
        "exemption_state": exemption_state,
        "required_scopes": tuple(sorted(scopes)),
    }
    return FitnessReport(
        results=results,
        status=overall,
        pre_risk=pre_risk,
        escalation=escalation,
        post_risk=post_risk,
        triggers=triggers,
        exemption_state=exemption_state,
        required_scopes=tuple(sorted(scopes)),
        evidence_digest=_digest(payload),
    )


def architecture_evidence(
    root: Path | str,
    *,
    base_sha: str,
    head_sha: str,
    pre_risk: str,
) -> dict[str, Any]:
    repository = Path(root).resolve(strict=True)
    diff = diff_architecture(repository, base_sha=base_sha, head_sha=head_sha)
    snapshot = diff._head_state.snapshot
    report = evaluate_fitness(
        repository, snapshot, diff, diff.changed_paths, pre_risk=pre_risk
    )
    digests = architecture_digests(snapshot)
    core: dict[str, Any] = {
        "architecture_contract_version": 1,
        "architecture_digest": digests["architecture_digest"],
        "schema_digest": digests["schema_digest"],
        "system_digest": digests["system_digest"],
        "rules_digest": digests["rules_digest"],
        "contract_inventory_digest": contract_inventory_digest(diff._head_state.contracts),
        "repository_inventory_digest": diff.repository_inventory_digest,
        "diff_digest": diff.digest,
        "exact_base_sha": diff.base_sha,
        "exact_head_sha": diff.head_sha,
        "head_kind": diff.head_kind,
        "baseline_introduced": diff.baseline_introduced,
        "base_adoption_state": diff.base_adoption_state,
        "head_adoption_state": diff.head_adoption_state,
        "base_adoption_digest": diff.base_adoption_digest,
        "head_adoption_digest": diff.head_adoption_digest,
        "fitness_results": [_result_payload(item) for item in report.results],
        "fitness_status": report.status,
        "risk_pre": report.pre_risk,
        "risk_escalation": report.escalation,
        "risk_post": report.post_risk,
        "risk_triggers": report.triggers,
        "exemption_state": report.exemption_state,
        "required_scopes": report.required_scopes,
        "overall_status": report.status,
    }
    core["architecture_evidence_digest"] = _digest(core)
    return core


__all__ = [
    "ADOPTION_BASE_SHA",
    "ApplicabilityEvidence",
    "ArchitectureChange",
    "ArchitectureDiff",
    "ArchitectureError",
    "ChangedArtifact",
    "FitnessReport",
    "FitnessResult",
    "architecture_evidence",
    "diff_architecture",
    "evaluate_fitness",
    "load_architecture",
]
