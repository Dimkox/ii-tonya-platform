from pathlib import Path
import gzip,json,hashlib,subprocess
src=Path('.superpowers/sdd/residency-semantic-tags-20261027');out=Path('docs/test-evidence/residency-semantic-tags-fourth-review-2026-10-27');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest();files=[]
prior=[('residency-semantic-tags-2026-10-27','4d6bd9964db22932b24d1c8787eb614963913f7527326f40bc8715aa737b9d22'),('residency-semantic-tags-ordinary-input-2026-10-27','5c5f3ba3053934b124ac80596a5bab2e28cf099323aa600a9673706d5a6e8358'),('residency-semantic-tags-reply-compatibility-2026-10-27','2fa9a1ca364414eb955caa817a6ac7ba095934bd4c4818e984c5e26f8edfcc9e')]
prior.append(('residency-semantic-tags-review-corrections-2026-10-27','ec453f84524bca0c2365995b36278e047b0cb49302f96139392b60eb16b730f2'))
prior.append(('residency-semantic-tags-second-review-2026-10-27','24c796bdc995a92011e4ab2be38dcf779bbb2b7328a40e07ea40cb5d4f571071'))
prior.append(('residency-semantic-tags-third-review-2026-10-27','75fb5fefa55482382d0b1cbe423d96ee6d99e1dbafd0cefebc2ceda6d617d564'))
for name,digest in prior:assert sha(Path('docs/test-evidence',name,'manifest.json').read_bytes())==digest
for p in sorted(src.glob('fourth-r7-*')):
 if not p.is_file():continue
 raw=p.read_bytes();packed=gzip.compress(raw,compresslevel=9,mtime=0);name=p.name+'.gz';(out/name).write_bytes(packed)
 f={'file':name,'sha256':sha(packed),'bytes':len(packed),'rawSha256':sha(raw),'rawBytes':len(raw),'originalPath':str(p)}
 if p.suffix=='.log' and p.with_suffix('.result.json').exists():f.update(json.loads(p.with_suffix('.result.json').read_text()));f['recordedResult']=p.with_suffix('.result.json').name+'.gz'
 files.append(f)
paths=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
paths=sorted(p for p in paths if p!='AGENT-STATUS.md' and not p.startswith(('docs/superpowers/','docs/test-evidence/')))
m={'kind':'local-synthetic-semantic-fourth-review-correction-R7','controlCommit':'4d2bb601c91f8d399b888e07b334f46141c69d9f','productionEvidence':False,'compression':'gzip level9 mtime0; one original artifact per file','preservedManifests':[{'path':'docs/test-evidence/'+name+'/manifest.json','sha256':digest} for name,digest in prior],'files':files,'finalSources':[{'path':p,'sha256':sha(Path(p).read_bytes())} for p in paths]}
m['unchangedState']=[{'path':f,'sha256':sha(Path(f).read_bytes())} for f in ['packages/db/migrations/0069_resident_semantic_tags.sql','packages/db/migrations/meta/_journal.json','packages/db/migrations/meta/0069_snapshot.json','packages/db/migrations/state/0069_sql_objects.json','packages/db/migrations/state/0069_manifest.json']]
(out/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n');(out/'ARTIFACTS.sha256').write_text('\n'.join(sha(p.read_bytes())+'  '+p.name for p in sorted(out.iterdir()) if p.name!='ARTIFACTS.sha256')+'\n')
secret=json.load(open('/tmp/verification-form-20261026.compose.json'))['services']['postgres']['environment']['POSTGRES_PASSWORD'].encode()
for f in files:
 b=(out/f['file']).read_bytes();raw=gzip.decompress(b);assert sha(b)==f['sha256'] and sha(raw)==f['rawSha256'];assert secret not in raw
print(json.dumps({'verifiedArtifacts':len(files),'verifiedSources':len(paths),'preservedManifests':len(prior),'manifestSha256':sha((out/'manifest.json').read_bytes())}))
