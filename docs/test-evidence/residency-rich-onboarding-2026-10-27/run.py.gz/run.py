import json,os,subprocess,sys,urllib.parse
j=json.load(open('/tmp/verification-form-20261026.compose.json'))['services']['postgres']['environment']
e=os.environ.copy()
e['II_TONYA_TEST_POSTGRES_ADMIN_URL']='postgresql://'+urllib.parse.quote(j['POSTGRES_USER'],safe='')+':'+urllib.parse.quote(j['POSTGRES_PASSWORD'],safe='')+'@127.0.0.1:55483/'+urllib.parse.quote(j['POSTGRES_DB'],safe='')
with open('.superpowers/sdd/rich-onboarding-20261027/'+sys.argv[1], 'w') as out:
 p=subprocess.run(sys.argv[2:],env=e,stdout=out,stderr=subprocess.STDOUT)
import hashlib
from pathlib import Path
log=Path('.superpowers/sdd/rich-onboarding-20261027')/sys.argv[1]
log.with_suffix('.result.json').write_text(json.dumps({'command':sys.argv[2:],'exitCode':p.returncode,'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()})+'\n')
print('exit',p.returncode)
sys.exit(p.returncode)
