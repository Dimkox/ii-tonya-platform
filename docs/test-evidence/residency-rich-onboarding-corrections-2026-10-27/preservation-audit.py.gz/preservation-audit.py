from pathlib import Path
import subprocess,hashlib,json
root=Path.cwd();control='a41652c684f79263350cd2cc2d5573c8f98ec71f'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',control,'packages/db/migrations','docs/test-evidence/residency-rich-onboarding-2026-10-27'],text=True).splitlines()
frozen=[p for p in paths if p.startswith('docs/test-evidence/residency-rich-onboarding-2026-10-27/') or (p.endswith('.sql') and int(Path(p).name[:4])<=66)]
for p in frozen:
 if Path(p).read_bytes()!=subprocess.check_output(['git','show',control+':'+p]):raise RuntimeError('historical evidence changed: '+p)
print(json.dumps({'frozenArtifactsVerified':len(frozen),'migration0066Sha256':hashlib.sha256(Path('packages/db/migrations/0066_resident_rich_onboarding.sql').read_bytes()).hexdigest(),'historical85ArchivePackage':'unchanged','rootOwnedDocuments':'excluded from owned file list'}))
