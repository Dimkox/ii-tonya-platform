import {execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync,readFileSync,symlinkSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
const root=process.cwd(),base=resolve('.superpowers/sdd/rich-onboarding-corrections-20261027/baseline');
const sha='219f8e0c9d0938fccb4188cf0081f71b3f8b2db9';
mkdirSync(base,{recursive:true});
execFileSync('tar',['-x','-C',base],{input:execFileSync('git',['archive',sha,'packages','apps','tests/support','tsconfig.base.json','package.json'],{maxBuffer:128*1024*1024})});
for(const dir of ['','packages/db','packages/application','packages/integrations','packages/config','packages/domain','apps/api','apps/worker']){const dest=resolve(base,dir,'node_modules');if(!existsSync(dest))symlinkSync(resolve(root,dir,'node_modules'),dest,'dir');}
const baselineRepo=resolve(base,'packages/db/src/repositories/expert-card-repository.ts');writeFileSync(baselineRepo,readFileSync(baselineRepo,'utf8').replace('throw new ExpertCardError("card_storage_unavailable");','console.error("baseline_repository_failure",(error as {cause?:{message?:string}})?.cause?.message ?? (error as Error)?.message); throw new ExpertCardError("card_storage_unavailable");'));
let source=execFileSync('git',['show',sha+':tests/integration/phase1-residency-lifecycle.test.ts'],{encoding:'utf8'});
source=source.slice(0,source.indexOf('  describe("seven-day provisional cycle"'));
source=source.replace('    await database.reset();','');
source='import {readFileSync} from "node:fs";\n'+source;
source=source.replace('database = await startExpertReferralTestDatabase();',`database = await startExpertReferralTestDatabase(async(db)=>{await db.transaction(async(tx)=>{const journal=JSON.parse(readFileSync("packages/db/migrations/meta/_journal.json","utf8"));for(const e of journal.entries.filter((e:{idx:number})=>e.idx<=65)){for(const statement of readFileSync("packages/db/migrations/"+e.tag+".sql","utf8").split("--> statement-breakpoint").filter(s=>s.trim()))await tx.execute(sql.raw(statement));}});});`);
source+=`
 it("R13 populated0065 collecting reviewed published survive0066 and0067",async()=>{
  const published=await publishedActor();
  const reviewed=await approvedCard();
  const collecting=await interview();
  await cards.addEntry({...event(collecting.workScope),expectedRevision:0,entry:{kind:"text",text:"Сохраняемый ответ старого черновика"}});
  const tables=["expert_card_drafts","expert_card_entries","expert_card_reviews","experts_published","expert_onboarding_invoices","expert_onboarding_payment_facts","expert_residency_orders","expert_main_activation_admissions"];
  const snapshot=async()=>Object.fromEntries(await Promise.all(tables.map(async(name)=>[name,(await database.db.execute(sql.raw("select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb) value from "+name+" t"))).rows[0]!.value])));
  const before=await snapshot();
  expect((await database.db.execute(sql\`select status,count(*)::int n from expert_card_drafts group by status\`)).rows).toEqual(expect.arrayContaining([{status:"collecting",n:1},{status:"approved",n:2}]));
  for(const tag of ["0066_resident_rich_onboarding","0067_resident_rich_review_corrections"]){for(const statement of readFileSync("packages/db/migrations/"+tag+".sql","utf8").split("--> statement-breakpoint").filter(s=>s.trim()))await database.db.execute(sql.raw(statement));}
  const after=await snapshot();
  for(const name of tables){const old=before[name] as Record<string,unknown>[];expect((after[name] as Record<string,unknown>[]).map(r=>Object.fromEntries(Object.keys(old[0]??{}).map(k=>[k,r[k]])))).toEqual(old);}
  const {PostgresExpertCardRepository:Corrected}=await import(${JSON.stringify(resolve(root,'packages/db/src/repositories/expert-card-repository.ts'))});
  const current=new Corrected(database.db,{workBotId:work.botId,workBotKey:work.botKey,messagingConsentPolicyVersion:"client-messaging-v1",richOnboarding:true});
  expect((await current.readDraft(manager.sessionHash,reviewed.applicationId))!.rich!.enabled).toBe(false);
  const e=event(collecting.workScope);const photo=await current.addEntry({...e,expectedRevision:1,entry:{kind:"photo",reference:"telegram:file:legacy_after_upgrade"}});
  expect(await current.ingestRichPhoto({...e,expectedRevision:photo.revision,reference:"telegram:file:legacy_after_upgrade",size:1,mimeType:"image/jpeg"})).toMatchObject({state:"legacy"});
  await current.submitDraft({...event(collecting.workScope),expectedRevision:photo.revision});
  expect((await current.getWorkflow(collecting.workScope))!.status).toBe("manager_review");
  expect((await database.db.execute(sql\`select active,paid_order_id from experts_published where user_id=\${published.userId}::uuid\`)).rows[0]).toEqual({active:true,paid_order_id:published.order.orderId});
  console.log("R13: three populated legacy states preserved, real paid publication retained, collecting legacy photo/submit operational; migrations0065->0066->0067, all triggers enabled");
 });
});
`;
const target=resolve(base,'tests/integration/populated-rich-upgrade.test.ts');mkdirSync(dirname(target),{recursive:true});writeFileSync(target,source);
const config=resolve('.superpowers/sdd/rich-onboarding-corrections-20261027/populated-upgrade.config.ts');writeFileSync(config,`import config from ${JSON.stringify(resolve(root,'vitest.config.ts'))};export default {...config,test:{...config.test,include:[${JSON.stringify(target)}],exclude:[]}};\n`);
console.log(JSON.stringify({baselineSha:sha,generatedTest:target,config}));
