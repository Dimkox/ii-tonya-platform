from pathlib import Path
import subprocess,json,hashlib,gzip,re,datetime
root=Path.cwd();local=Path('.superpowers/sdd/native-scheduling-20261027');out=Path('docs/test-evidence/residency-native-scheduling-2026-10-27');out.mkdir(parents=True,exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();baseline=subprocess.check_output(['git','rev-parse',source+'^'],text=True).strip()
paths=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',source],text=True).splitlines()
sources=[{'path':p,'sha256':sha(Path(p).read_bytes()),'bytes':Path(p).stat().st_size} for p in paths]
files=[]
secret=json.loads(Path('/tmp/verification-form-20261026.compose.json').read_text())['services']['postgres']['environment']['POSTGRES_PASSWORD'].encode()
known={
'pg-presentation-final.log':(['node',str(local/'run-focused.mjs'),'pg-presentation-final'],0),
'pg-http-import-final.log':(['node',str(local/'run-files.mjs'),'pg-http-import-final','tests/integration/resident-native-scheduling.test.ts','-t','actual authenticated work ingress'],0),
'pg-external-compatibility.log':(['node',str(local/'run-files.mjs'),'pg-external-compatibility','tests/integration/booking-notification-wire-admission.test.ts'],0),
'freshness-guard-final.log':(['pnpm','exec','vitest','run','tests/repo/booking-repository-guards.test.ts'],0),
'history-guard-final.log':(['pnpm','exec','vitest','run','tests/repo/migration-history-integrity.test.ts'],0),
'scope-companion-final.log':(['pnpm','exec','vitest','run','tests/repo/expert-referral-scope-guards.test.ts'],0),
'build-initial.log':(['pnpm','build'],0),
'web-build-final.log':(['pnpm','--filter','@ii-tonya/web','build'],0),
'dependency-frozen-minimal.log':(['pnpm','install','--frozen-lockfile'],0),
'reconstruct-source-freeze.log':(['pnpm','exec','tsx',str(local/'reconstruct.ts')],0),
'browser-screenshots-final.log':(['node',str(local/'browser-witness.mjs')],0),
'types-final.log':(['pnpm','typecheck'],0),
}
staticfiles=['packages/contracts/src/resident-schedule.test.ts','apps/worker/src/resident-native-discovery.test.ts','apps/worker/src/client-catalog-outbox.test.ts','apps/worker/src/booking-notification-runtime.test.ts','apps/worker/src/booking-notifications.test.ts','packages/worker/src/booking-notification-renderer.test.ts','packages/worker/src/booking-notification-runner.test.ts','packages/application/src/expert-card-service.test.ts','apps/api/src/routes/public-client-catalog.test.ts','apps/api/src/routes/client-catalog.test.ts','apps/api/src/public-client-catalog-composition.test.ts','apps/web/src/catalog-client.test.ts','apps/web/src/catalog-view.test.ts','apps/web/src/booking-client.test.ts','apps/web/src/booking-view.test.ts','apps/web/src/expert-card-client.test.ts','apps/web/src/expert-card-view.test.ts','tests/repo/scope-boundary.test.ts','tests/repo/expert-referral-scope-guards.test.ts','tests/repo/migration-history-integrity.test.ts','tests/repo/hybrid-message-gateway-schema-parity.test.ts','tests/repo/resident-native-scheduling-state.test.ts','tests/repo/booking-repository-guards.test.ts']
known['focused-compatibility-and-guards.log']=(['pnpm','exec','vitest','run',*staticfiles],1)
known['lint-final.log']=(['pnpm','exec','eslint',*[p for p in paths if p.endswith(('.ts','.tsx','.js','.mjs'))]],0)
for p in sorted(local.iterdir()):
 if not p.is_file() or p.name=='restore-helper.txt':continue
 if p.suffix not in ('.log','.json','.mjs','.ts','.diff','.png','.py'):continue
 raw=p.read_bytes()
 if secret in raw:raise RuntimeError('Secret detected in artifact; refusing to archive: '+p.name)
 if p.suffix=='.png':
  packed=raw;name=p.name
 else:
  packed=gzip.compress(raw,compresslevel=9,mtime=0);name=p.name+'.gz'
 (out/name).write_bytes(packed)
 record={'file':name,'sha256':sha(packed),'bytes':len(packed),'rawSha256':sha(raw),'rawBytes':len(raw),'originalPath':str(p)}
 if p.name in known:
  command,exitcode=known[p.name];record.update(command=command,exitCode=exitcode)
 if p.suffix=='.log':
  text=raw.decode('utf8');matches=re.findall(r'^\s*(?:Test Files\s+.*|Tests\s+.*|Start at\s+.*|Duration\s+.*|exit=.*)',text,re.M)
  record['recordedSummary']=[m.strip() for m in matches]
  result=p.with_suffix('.result.json')
  if result.exists():record.update(json.loads(result.read_text()));record['resultArtifact']=result.name+'.gz'
  elif 'exitCode' not in record:
   code=re.search(r'\nexit=(\d+)\s*$',text)
   if code:record['exitCode']=int(code[1])
  if 'command' not in record:record['commandProvenance']='Historical diagnostic log; exact argv was not separately captured. Contents retained without inventing missing metadata.'
 files.append(record)
manifest={'kind':'local-synthetic-native-resident-scheduling-S4a','sourceCommit':source,'baselineCommit':baseline,'productionEvidence':False,'hostedCiEvidence':False,'capturedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compression':'gzip level9 mtime0; one original artifact per file; PNG stored directly','environment':{'node':'24.22.1','pnpm':'11.9.0','powershell':'7.6.9','postgres':'17.5','docker':'29.9.2','compose':'5.6.1','databaseContainer':'ii-tonya-verification-form-20261026-postgres-1','databaseCpuLimit':1,'databaseMemoryBytes':1073741824,'databasePort':'127.0.0.1:55483','credentials':'Read only from protected configuration in child memory/environment; not archived or passed in process arguments.'},'finalResults':{'nativePg':{'passed':13,'failed':0,'artifact':'pg-presentation-final.log.gz'},'strengthenedHttpImport':{'passed':1,'skipped':12,'failed':0,'artifact':'pg-http-import-final.log.gz'},'legacyExternalPg':{'passed':37,'failed':0,'artifact':'pg-external-compatibility.log.gz'},'staticCompatibility':{'uniqueTestsCovered':495,'initialPassed':491,'initialFailed':4,'correctiveRuns':{'history':9,'scopeCompanion':13,'freshness':6},'note':'The original 23-file command is retained as failed. Only its three failed files were rerun after exact registrations/freshness-callsite assertions were corrected; all four failures then passed.'},'state':{'tables':222,'functions':175,'triggers':210,'constraints':1509,'indexes':549,'extensions':2},'browser':'Actual headless Chrome; real manager API and protected booking choice responses replayed into production client/view code; no live deployment or production browser session.','sourceChecks':'Workspace+tests typecheck, final changed-file lint, final test lint/typecheck, formatting, whitespace and web build passed. Full workspace build passed earlier; its timing precedes final source corrections.'},'sourceFiles':sources,'files':files,'limitations':['Historical diagnostic logs retain original intermediate failures; not every intermediate uncommitted source version or exact argv was captured. They are diagnostic evidence, not claimed final-source verification.','Final 13-case native run preceded the last HTTP test-only CSV strengthening; that changed case was rerun individually and passed against unchanged runtime source.','The initial combined compatibility run preceded exact guard registration corrections. Corrective individual results must be read with it, not represented as a new all-green aggregate command.','Online-window fixtures explicitly use a direct synthetic short-lead reservation for due-delivery proof; actual protected discovery retains and proves the existing 24-hour lead.','Pre-native populated upgrade seeds the historical canonical rows before migration0070. Historical rich approval is populated after only the first two additive nullable schedule columns, before any native authority/table/backfill statement; the existing approved bytes are asserted unchanged after the remainder.','Independent review, root exact-head branch gate, gated push and Draft PR are separate delivery work. S4b and production activation are outside this increment.']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
(out/'ARTIFACTS.sha256').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='ARTIFACTS.sha256'))
print(json.dumps({'sourceCommit':source,'artifacts':len(files),'sourceFiles':len(sources),'compressedBytes':sum(f['bytes'] for f in files)}))
