import { pgTable, check, uuid, timestamp, boolean, text, foreignKey, integer, unique, uniqueIndex, index, bigint, jsonb, bigserial, char, varchar, date, type AnyPgColumn, primaryKey, pgView, pgEnum } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"

export const expertFirstSettlementEligibility = pgEnum("expert_first_settlement_eligibility", ['eligible', 'permanently_ineligible', 'pending_feature_hold', 'cancelled_by_refund'])
export const expertReferralAbuseHoldStatus = pgEnum("expert_referral_abuse_hold_status", ['open', 'closed'])
export const expertReferralBatchStatus = pgEnum("expert_referral_batch_status", ['issued', 'partially_redeemed', 'fully_redeemed', 'revoked'])
export const expertReferralCodeStatus = pgEnum("expert_referral_code_status", ['issued', 'redeemed', 'revoked'])
export const expertReferralLedgerEntryKind = pgEnum("expert_referral_ledger_entry_kind", ['reward_grant', 'reservation', 'release', 'spend', 'expiry', 'reversal', 'debt_repayment', 'administrative_correction'])
export const expertReferralMaturityStatus = pgEnum("expert_referral_maturity_status", ['pending', 'granted', 'cancelled'])
export const expertResidencyOrderStatus = pgEnum("expert_residency_order_status", ['quoted', 'payment_pending', 'settled', 'failed', 'expired', 'refunded', 'charged_back'])
export const expertResidencyPaymentAttemptStatus = pgEnum("expert_residency_payment_attempt_status", ['created', 'pending', 'unknown_outcome', 'settled', 'failed', 'refunded', 'charged_back'])
export const expertResidencyProviderEventStatus = pgEnum("expert_residency_provider_event_status", ['received', 'processing', 'processed', 'rejected', 'reconciliation_required'])
export const ledgerEntryKind = pgEnum("ledger_entry_kind", ['grant', 'debit', 'free', 'compensation', 'revocation'])
export const outboxStatus = pgEnum("outbox_status", ['pending', 'processing', 'unknown_outcome', 'reconciling', 'succeeded', 'retry_wait', 'dead_letter'])
export const reservationStatus = pgEnum("reservation_status", ['reserved', 'booked', 'cancelled_by_client', 'cancelled_by_expert', 'expired', 'completed', 'no_show'])


export const users = pgTable("users", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	active: boolean().default(true).notNull(),
	currentVerificationStage: text("current_verification_stage").default('NONE').notNull(),
}, (table) => [
	check("users_current_verification_stage_check", sql`current_verification_stage = ANY (ARRAY['NONE'::text, 'FORM_FILLING'::text, 'AUTO_CHECK'::text, 'MANAGER_REVIEW'::text, 'DONE'::text])`),
]);

export const expertServices = pgTable("expert_services", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	name: text().notNull(),
	active: boolean().default(true).notNull(),
	durationMinutes: integer("duration_minutes").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	code: text(),
	language: text(),
}, (table) => [
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_services_expert_id_fkey"
		}),
]);

export const experts = pgTable("experts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	active: boolean().default(false).notNull(),
	verified: boolean().default(false).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	publicDisplayName: text("public_display_name"),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "experts_user_id_fkey"
		}),
	unique("experts_id_user_unique").on(table.id, table.userId),
	unique("experts_user_id_unique").on(table.userId),
]);

export const clientProfiles = pgTable("client_profiles", {
	userId: uuid("user_id").primaryKey().notNull(),
	displayName: text("display_name"),
	timezone: text(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	expertNote: text("expert_note"),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_profiles_user_id_fkey"
		}),
	check("client_profiles_expert_note_bounded", sql`(expert_note IS NULL) OR ((char_length(expert_note) >= 1) AND (char_length(expert_note) <= 2000))`),
]);

export const channelIdentities = pgTable("channel_identities", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	provider: text().notNull(),
	externalId: text("external_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	botKey: text("bot_key"),
	externalChatId: text("external_chat_id"),
	status: text().default('active').notNull(),
}, (table) => [
	uniqueIndex("channel_identities_provider_external_legacy_unique").using("btree", table.provider.asc().nullsLast().op("text_ops"), table.externalId.asc().nullsLast().op("text_ops")).where(sql`(bot_key IS NULL)`),
	uniqueIndex("channel_identities_telegram_bot_user_chat_unique").using("btree", table.provider.asc().nullsLast().op("text_ops"), table.botKey.asc().nullsLast().op("text_ops"), table.externalId.asc().nullsLast().op("text_ops"), table.externalChatId.asc().nullsLast().op("text_ops")).where(sql`((provider = 'telegram'::text) AND (bot_key IS NOT NULL) AND (external_chat_id IS NOT NULL) AND (status = 'active'::text))`),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "channel_identities_user_id_fkey"
		}),
	unique("channel_identity_resident_owner").on(table.id, table.userId),
	check("channel_identities_status_check", sql`status = ANY (ARRAY['active'::text, 'unresolved'::text, 'blocked'::text])`),
]);

export const consents = pgTable("consents", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	consentType: text("consent_type").notNull(),
	decision: text().notNull(),
	policyVersion: text("policy_version").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	sequence: bigint({ mode: "number" }).generatedAlwaysAsIdentity({ name: "consents_sequence_seq", startWith: 1, increment: 1, minValue: 1, maxValue: 9223372036854775807, cache: 1 }),
	channel: text(),
	scopeFields: jsonb("scope_fields"),
	documentVersionId: uuid("document_version_id"),
	presentationId: uuid("presentation_id"),
	priorDecisionId: uuid("prior_decision_id"),
	recipientId: uuid("recipient_id"),
	reservationId: uuid("reservation_id"),
	textSha256: text("text_sha256"),
	basis: text(),
}, (table) => [
	index("consents_subject_purpose_order_idx").using("btree", table.userId.asc().nullsLast().op("int8_ops"), table.consentType.asc().nullsLast().op("int8_ops"), table.createdAt.desc().nullsFirst().op("int8_ops"), table.sequence.desc().nullsFirst().op("int8_ops")),
	foreignKey({
			columns: [table.documentVersionId],
			foreignColumns: [consentDocumentVersions.id],
			name: "consents_evidence_document_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.presentationId],
			foreignColumns: [consentPresentations.id],
			name: "consents_evidence_presentation_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "consents_user_id_fkey"
		}),
	check("consents_channel_known", sql`(channel IS NULL) OR (channel = ANY (ARRAY['web'::text, 'telegram'::text])))) NOT VALID`),
	check("consents_decision_known", sql`decision = ANY (ARRAY['granted'::text, 'denied'::text, 'revoked'::text]))) NOT VALID`),
	check("consents_no_self_reference", sql`(prior_decision_id IS NULL) OR (prior_decision_id <> id))) NOT VALID`),
	check("consents_text_sha256_shape", sql`(text_sha256 IS NULL) OR (text_sha256 ~ '^[0-9a-f]{64}$'::text))) NOT VALID`),
]);

export const messageEvents = pgTable("message_events", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	provider: text().notNull(),
	externalMessageId: text("external_message_id").notNull(),
	direction: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "message_events_user_id_fkey"
		}),
	unique("message_events_provider_external_unique").on(table.provider, table.externalMessageId),
]);

export const notifications = pgTable("notifications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reservationId: uuid("reservation_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	callbackTokenHash: text("callback_token_hash"),
	callbackClaims: text("callback_claims"),
	callbackExpiresAt: timestamp("callback_expires_at", { withTimezone: true, mode: 'string' }),
	callbackExpertId: uuid("callback_expert_id"),
	callbackAction: text("callback_action"),
	callbackVersion: integer("callback_version"),
	callbackConsumedAt: timestamp("callback_consumed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("notifications_callback_token_hash_unique").using("btree", table.callbackTokenHash.asc().nullsLast().op("text_ops")).where(sql`(callback_token_hash IS NOT NULL)`),
	foreignKey({
			columns: [table.callbackExpertId],
			foreignColumns: [experts.id],
			name: "notifications_callback_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "notifications_reservation_id_fkey"
		}),
	unique("notifications_idempotency_unique").on(table.idempotencyKey),
]);

export const conversations = pgTable("conversations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "conversations_user_id_fkey"
		}),
]);

export const conversationMessages = pgTable("conversation_messages", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	conversationId: uuid("conversation_id").notNull(),
	authorType: text("author_type").notNull(),
	contentRef: text("content_ref"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.conversationId],
			foreignColumns: [conversations.id],
			name: "conversation_messages_conversation_id_fkey"
		}),
]);

export const feedback = pgTable("feedback", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reservationId: uuid("reservation_id"),
	userId: uuid("user_id").notNull(),
	rating: integer().notNull(),
	commentRef: text("comment_ref"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	sourceEventId: text("source_event_id").notNull(),
	contentHash: text("content_hash").default('legacy-unavailable').notNull(),
	negativePolicyVersion: text("negative_policy_version").default('legacy').notNull(),
	escalationStatus: text("escalation_status").default('none').notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "feedback_reservation_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "feedback_user_id_fkey"
		}),
	unique("feedback_source_event_unique").on(table.sourceEventId),
]);

export const safetyIncidents = pgTable("safety_incidents", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	conversationId: uuid("conversation_id"),
	reasonCode: text("reason_code").notNull(),
	metadataHash: text("metadata_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.conversationId],
			foreignColumns: [conversations.id],
			name: "safety_incidents_conversation_id_fkey"
		}),
]);

export const humanEscalations = pgTable("human_escalations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	incidentId: uuid("incident_id").notNull(),
	status: text().notNull(),
	ownerId: uuid("owner_id"),
	openedAt: timestamp("opened_at", { withTimezone: true, mode: 'string' }).notNull(),
	acknowledgementDeadline: timestamp("acknowledgement_deadline", { withTimezone: true, mode: 'string' }).notNull(),
	acknowledgedAt: timestamp("acknowledged_at", { withTimezone: true, mode: 'string' }),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	version: integer().default(1).notNull(),
	escalationReason: text("escalation_reason").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.incidentId],
			foreignColumns: [safetyIncidents.id],
			name: "human_escalations_incident_id_fkey"
		}),
	foreignKey({
			columns: [table.ownerId],
			foreignColumns: [users.id],
			name: "human_escalations_owner_id_fkey"
		}),
]);

export const adminApprovals = pgTable("admin_approvals", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	action: text().notNull(),
	objectType: text("object_type").notNull(),
	objectId: uuid("object_id").notNull(),
	requesterId: uuid("requester_id").notNull(),
	approverId: uuid("approver_id"),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	nonce: text().notNull(),
	consumedAt: timestamp("consumed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	requesterSessionIdHash: text("requester_session_id_hash").default('legacy-unbound').notNull(),
	approverSessionIdHash: text("approver_session_id_hash"),
	payloadHash: text("payload_hash").default('legacy-unbound').notNull(),
	requiredRole: text("required_role").default('support').notNull(),
	requesterMfaVerifiedAt: timestamp("requester_mfa_verified_at", { withTimezone: true, mode: 'string' }),
	approverMfaVerifiedAt: timestamp("approver_mfa_verified_at", { withTimezone: true, mode: 'string' }),
	approvedAt: timestamp("approved_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	uniqueIndex("admin_approvals_bound_scope_nonce_unique").using("btree", table.action.asc().nullsLast().op("text_ops"), table.objectType.asc().nullsLast().op("text_ops"), table.objectId.asc().nullsLast().op("uuid_ops"), table.requesterId.asc().nullsLast().op("text_ops"), table.nonce.asc().nullsLast().op("uuid_ops")).where(sql`(requester_session_id_hash <> 'legacy-unbound'::text)`),
	foreignKey({
			columns: [table.approverId],
			foreignColumns: [users.id],
			name: "admin_approvals_approver_id_fkey"
		}),
	foreignKey({
			columns: [table.requesterId],
			foreignColumns: [users.id],
			name: "admin_approvals_requester_id_fkey"
		}),
	check("admin_approvals_binding_complete", sql`(requester_session_id_hash = 'legacy-unbound'::text) OR ((requester_mfa_verified_at IS NOT NULL) AND (((approver_id IS NULL) AND (approver_session_id_hash IS NULL) AND (approver_mfa_verified_at IS NULL) AND (approved_at IS NULL)) OR ((approver_id IS NOT NULL) AND (approver_session_id_hash IS NOT NULL) AND (approver_mfa_verified_at IS NOT NULL) AND (approved_at IS NOT NULL))))`),
	check("admin_approvals_lifecycle_order", sql`(requester_session_id_hash = 'legacy-unbound'::text) OR ((expires_at > created_at) AND (requester_mfa_verified_at <= created_at) AND ((approved_at IS NULL) OR ((approved_at >= created_at) AND (approver_mfa_verified_at <= approved_at))) AND ((consumed_at IS NULL) OR ((approved_at IS NOT NULL) AND (consumed_at >= approved_at))))`),
	check("admin_approvals_required_role_allowed", sql`required_role = ANY (ARRAY['support'::text, 'catalog_admin'::text, 'entitlement_admin'::text, 'security_admin'::text])`),
]);

export const integrationInbox = pgTable("integration_inbox", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	externalEventId: text("external_event_id").notNull(),
	payloadHash: text("payload_hash").notNull(),
	normalizedIdentifier: text("normalized_identifier").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	messageEventId: uuid("message_event_id"),
}, (table) => [
	foreignKey({
			columns: [table.messageEventId],
			foreignColumns: [messageEvents.id],
			name: "integration_inbox_message_event_id_message_events_id_fk"
		}),
	unique("integration_inbox_provider_event_unique").on(table.provider, table.externalEventId),
]);

export const privacyProcessorAttempts = pgTable("privacy_processor_attempts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	deletionJobId: uuid("deletion_job_id").notNull(),
	processor: text().notNull(),
	status: text().notNull(),
	receiptRef: text("receipt_ref"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.deletionJobId],
			foreignColumns: [privacyDeletionJobs.id],
			name: "privacy_processor_attempts_deletion_job_id_fkey"
		}),
	unique("privacy_processor_attempts_job_processor_unique").on(table.deletionJobId, table.processor),
	unique("privacy_processor_attempts_idempotency_unique").on(table.idempotencyKey),
]);

export const privacyDeletionJobs = pgTable("privacy_deletion_jobs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	status: text().notNull(),
	backupExpiresAt: timestamp("backup_expires_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	evidencePseudonym: text("evidence_pseudonym"),
	backupPolicyVersion: text("backup_policy_version"),
	backupVerificationState: text("backup_verification_state"),
	backupVerifiedAt: timestamp("backup_verified_at", { withTimezone: true, mode: 'string' }),
	legacyProviderIdentifierEvidence: text("legacy_provider_identifier_evidence"),
	erasureReceipt: jsonb("erasure_receipt"),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "privacy_deletion_jobs_user_id_fkey"
		}),
	unique("privacy_deletion_jobs_id_subject_unique").on(table.id, table.userId),
	unique("privacy_deletion_jobs_subject_idempotency_unique").on(table.userId, table.idempotencyKey),
]);

export const deliveryAttempts = pgTable("delivery_attempts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	outboxId: uuid("outbox_id").notNull(),
	attempt: integer().notNull(),
	provider: text().notNull(),
	outcome: text().notNull(),
	normalizedReason: text("normalized_reason"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	attemptId: text("attempt_id").default('legacy').notNull(),
	reconciliationKey: text("reconciliation_key").default('legacy').notNull(),
}, (table) => [
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "delivery_attempts_outbox_id_fkey"
		}),
]);

export const deadLetters = pgTable("dead_letters", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	outboxId: uuid("outbox_id").notNull(),
	reason: text().notNull(),
	payloadHash: text("payload_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "dead_letters_outbox_id_fkey"
		}),
	unique("dead_letters_outbox_unique").on(table.outboxId),
]);

export const providerCursors = pgTable("provider_cursors", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	cursor: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("provider_cursors_provider_unique").on(table.provider),
]);

export const reconciliationRuns = pgTable("reconciliation_runs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	startedAt: timestamp("started_at", { withTimezone: true, mode: 'string' }).notNull(),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
});

export const reconciliationMismatches = pgTable("reconciliation_mismatches", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reconciliationRunId: uuid("reconciliation_run_id").notNull(),
	outboxId: uuid("outbox_id"),
	reason: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "reconciliation_mismatches_outbox_id_fkey"
		}),
	foreignKey({
			columns: [table.reconciliationRunId],
			foreignColumns: [reconciliationRuns.id],
			name: "reconciliation_mismatches_reconciliation_run_id_fkey"
		}),
]);

export const projectionCheckpoints = pgTable("projection_checkpoints", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	projection: text().notNull(),
	position: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("projection_checkpoints_projection_unique").on(table.projection),
]);

export const slots = pgTable("slots", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertServiceId: uuid("expert_service_id").notNull(),
	provider: text().notNull(),
	externalSlotId: text("external_slot_id").notNull(),
	startsAt: timestamp("starts_at", { withTimezone: true, mode: 'string' }).notNull(),
	endsAt: timestamp("ends_at", { withTimezone: true, mode: 'string' }).notNull(),
	capacity: integer().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	observedAt: timestamp("observed_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	foreignKey({
			columns: [table.expertServiceId],
			foreignColumns: [expertServices.id],
			name: "slots_expert_service_id_fkey"
		}),
	unique("slots_provider_external_unique").on(table.provider, table.externalSlotId),
	check("slots_capacity_positive", sql`capacity > 0`),
]);

export const integrationOutbox = pgTable("integration_outbox", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	status: outboxStatus().default('pending').notNull(),
	reconciliationKey: text("reconciliation_key").notNull(),
	attempt: integer().default(0).notNull(),
	reconciliationAttempt: integer("reconciliation_attempt").default(0).notNull(),
	dispatchOwnerId: text("dispatch_owner_id"),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	reconciliationOwnerId: text("reconciliation_owner_id"),
	reconciliationLeaseUntil: timestamp("reconciliation_lease_until", { withTimezone: true, mode: 'string' }),
	lastNormalizedReason: text("last_normalized_reason"),
	payloadHash: text("payload_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	topic: text().default('legacy.unknown').notNull(),
	payload: jsonb().default({}).notNull(),
	correlationId: text("correlation_id").default('legacy').notNull(),
	nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true, mode: 'string' }),
	nextReconciliationAt: timestamp("next_reconciliation_at", { withTimezone: true, mode: 'string' }),
	dispatchClaimToken: text("dispatch_claim_token"),
	reconciliationClaimToken: text("reconciliation_claim_token"),
	dialogueId: uuid("dialogue_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	dialogueSequence: bigint("dialogue_sequence", { mode: "number" }),
	sensitiveRedactedAt: timestamp("sensitive_redacted_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("integration_outbox_dialogue_order_claim_idx").using("btree", table.dialogueId.asc().nullsLast().op("int8_ops"), table.dialogueSequence.asc().nullsLast().op("enum_ops"), table.status.asc().nullsLast().op("int8_ops")).where(sql`((topic = 'telegram.send_text.v1'::text) AND (dialogue_id IS NOT NULL))`),
	uniqueIndex("integration_outbox_dialogue_sequence_unique").using("btree", table.dialogueId.asc().nullsLast().op("uuid_ops"), table.dialogueSequence.asc().nullsLast().op("int8_ops")).where(sql`(dialogue_id IS NOT NULL)`),
	index("integration_outbox_dispatch_lease").using("btree", table.status.asc().nullsLast().op("timestamptz_ops"), table.leaseUntil.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = 'processing'::outbox_status)`),
	index("integration_outbox_reconciliation_lease").using("btree", table.status.asc().nullsLast().op("timestamptz_ops"), table.reconciliationLeaseUntil.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = 'reconciling'::outbox_status)`),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "integration_outbox_dialogue_id_fkey"
		}),
	unique("integration_outbox_idempotency_unique").on(table.idempotencyKey),
	check("integration_outbox_attempts_nonnegative", sql`(attempt >= 0) AND (reconciliation_attempt >= 0)`),
	check("integration_outbox_dialogue_order_pair", sql`(dialogue_id IS NULL) = (dialogue_sequence IS NULL)`),
	check("integration_outbox_dialogue_sequence_positive", sql`(dialogue_sequence IS NULL) OR (dialogue_sequence > 0)`),
	check("integration_outbox_reconciliation_key_present", sql`length(reconciliation_key) > 0`),
]);

export const reservations = pgTable("reservations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	expertServiceId: uuid("expert_service_id").notNull(),
	status: reservationStatus().default('reserved').notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	reservedUntil: timestamp("reserved_until", { withTimezone: true, mode: 'string' }).notNull(),
	version: integer().default(1).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	slotId: uuid("slot_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	meetingUrl: text("meeting_url"),
}, (table) => [
	index("reservations_client_active_overlap").using("btree", table.userId.asc().nullsLast().op("uuid_ops"), table.status.asc().nullsLast().op("uuid_ops")),
	index("reservations_expert_active_overlap").using("btree", table.expertId.asc().nullsLast().op("uuid_ops"), table.status.asc().nullsLast().op("enum_ops")),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "reservations_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.expertServiceId],
			foreignColumns: [expertServices.id],
			name: "reservations_expert_service_id_fkey"
		}),
	foreignKey({
			columns: [table.slotId],
			foreignColumns: [slots.id],
			name: "reservations_slot_id_slots_id_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "reservations_user_id_fkey"
		}),
	unique("reservations_idempotency_unique").on(table.idempotencyKey),
	check("reservations_deadline_after_creation", sql`reserved_until > created_at`),
	check("reservations_meeting_url_https", sql`(meeting_url IS NULL) OR ((meeting_url ~ '^https://[^[:space:]]+$'::text) AND (char_length(meeting_url) <= 2048))`),
	check("reservations_version_positive", sql`version > 0`),
]);

export const messageLedgerEntries = pgTable("message_ledger_entries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	packageId: uuid("package_id"),
	entryKind: ledgerEntryKind("entry_kind").notNull(),
	delta: integer().notNull(),
	direction: text().default('outbound').notNull(),
	messageEventId: uuid("message_event_id"),
	originalEntryId: uuid("original_entry_id"),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	adminApprovalId: uuid("admin_approval_id"),
	adminRequesterSessionIdHash: text("admin_requester_session_id_hash"),
	legacyAdminFact: boolean("legacy_admin_fact").default(false).notNull(),
}, (table) => [
	uniqueIndex("message_ledger_compensation_once_per_original").using("btree", table.originalEntryId.asc().nullsLast().op("uuid_ops")).where(sql`(entry_kind = 'compensation'::ledger_entry_kind)`),
	uniqueIndex("message_ledger_grant_once_per_package").using("btree", table.packageId.asc().nullsLast().op("uuid_ops")).where(sql`(entry_kind = 'grant'::ledger_entry_kind)`),
	uniqueIndex("message_ledger_message_fact_once").using("btree", table.messageEventId.asc().nullsLast().op("text_ops"), table.direction.asc().nullsLast().op("uuid_ops")).where(sql`((message_event_id IS NOT NULL) AND (entry_kind = ANY (ARRAY['debit'::ledger_entry_kind, 'free'::ledger_entry_kind])))`),
	uniqueIndex("message_ledger_revocation_once_per_package_grant").using("btree", table.packageId.asc().nullsLast().op("uuid_ops"), table.originalEntryId.asc().nullsLast().op("uuid_ops")).where(sql`(entry_kind = 'revocation'::ledger_entry_kind)`),
	foreignKey({
			columns: [table.adminApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "message_ledger_entries_admin_approval_id_admin_approvals_id_fk"
		}),
	foreignKey({
			columns: [table.adminRequesterSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "message_ledger_entries_admin_requester_session_id_hash_admin_se"
		}),
	foreignKey({
			columns: [table.messageEventId],
			foreignColumns: [messageEvents.id],
			name: "message_ledger_entries_message_event_id_fkey"
		}),
	foreignKey({
			columns: [table.packageId],
			foreignColumns: [messagePackages.id],
			name: "message_ledger_entries_package_id_fkey"
		}),
	foreignKey({
			columns: [table.originalEntryId],
			foreignColumns: [table.id],
			name: "message_ledger_original_entry_fk"
		}),
	unique("message_ledger_idempotency_unique").on(table.idempotencyKey),
	check("message_ledger_admin_binding_complete", sql`((admin_approval_id IS NULL) AND (admin_requester_session_id_hash IS NULL)) OR ((admin_approval_id IS NOT NULL) AND (admin_requester_session_id_hash IS NOT NULL))`),
	check("message_ledger_delta_matches_kind", sql`((entry_kind = 'grant'::ledger_entry_kind) AND (package_id IS NOT NULL) AND (delta > 0) AND (message_event_id IS NULL) AND (original_entry_id IS NULL)) OR ((entry_kind = 'debit'::ledger_entry_kind) AND (package_id IS NOT NULL) AND (delta = '-1'::integer) AND (message_event_id IS NOT NULL) AND (original_entry_id IS NULL)) OR ((entry_kind = 'free'::ledger_entry_kind) AND (delta = 0) AND (message_event_id IS NOT NULL) AND (original_entry_id IS NULL)) OR ((entry_kind = 'compensation'::ledger_entry_kind) AND (package_id IS NOT NULL) AND (delta = 1) AND (message_event_id IS NULL) AND (original_entry_id IS NOT NULL)) OR ((entry_kind = 'revocation'::ledger_entry_kind) AND (package_id IS NOT NULL) AND (delta <= 0) AND (message_event_id IS NULL) AND (original_entry_id IS NOT NULL))`),
]);

export const promptVersions = pgTable("prompt_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	name: text().notNull(),
	version: integer().notNull(),
	contentRef: text("content_ref").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("prompt_versions_name_version_unique").on(table.name, table.version),
]);

export const auditEvents = pgTable("audit_events", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	actorType: text("actor_type").notNull(),
	actorId: uuid("actor_id").notNull(),
	authenticatedSessionIdHash: text("authenticated_session_id_hash").notNull(),
	action: text().notNull(),
	objectType: text("object_type").notNull(),
	objectId: uuid("object_id").notNull(),
	decision: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	correlationId: text("correlation_id").notNull(),
	occurredAt: timestamp("occurred_at", { withTimezone: true, mode: 'string' }).notNull(),
	metadataHash: text("metadata_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("expert_workspace_activation_audit_once").using("btree", table.objectId.asc().nullsLast().op("text_ops"), table.action.asc().nullsLast().op("text_ops")).where(sql`(action = 'ACCESS_ACTIVATED'::text)`),
]);

export const privacyRetentionItems = pgTable("privacy_retention_items", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	contentClass: text("content_class").notNull(),
	contentRef: text("content_ref"),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	status: text().default('pending').notNull(),
	idempotencyKey: text("idempotency_key"),
	receiptHash: text("receipt_hash"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
});

export const providerSubjectMappings = pgTable("provider_subject_mappings", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	provider: text().notNull(),
	subjectToken: text("subject_token").notNull(),
	subjectCiphertext: text("subject_ciphertext").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "provider_subject_mappings_user_id_users_id_fk"
		}),
	unique("provider_subject_mappings_provider_token_unique").on(table.provider, table.subjectToken),
]);

export const privacyDeletionManifests = pgTable("privacy_deletion_manifests", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	deletionJobId: uuid("deletion_job_id").notNull(),
	processor: text().notNull(),
	manifestCiphertext: text("manifest_ciphertext").notNull(),
	subjectDeletionKeyHash: text("subject_deletion_key_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	keyReference: text("key_reference").notNull(),
	algorithm: text().notNull(),
	version: text().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.deletionJobId],
			foreignColumns: [privacyDeletionJobs.id],
			name: "privacy_deletion_manifests_deletion_job_id_privacy_deletion_job"
		}),
	unique("privacy_deletion_manifests_job_processor_unique").on(table.deletionJobId, table.processor),
]);

export const adminRoleAssignments = pgTable("admin_role_assignments", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	adminId: uuid("admin_id").notNull(),
	role: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.adminId],
			foreignColumns: [users.id],
			name: "admin_role_assignments_admin_id_users_id_fk"
		}),
	unique("admin_role_assignments_admin_role_unique").on(table.adminId, table.role),
	check("admin_role_assignments_role_allowed", sql`role = ANY (ARRAY['support'::text, 'catalog_admin'::text, 'entitlement_admin'::text, 'security_admin'::text])`),
]);

export const adminSessions = pgTable("admin_sessions", {
	sessionIdHash: text("session_id_hash").primaryKey().notNull(),
	adminId: uuid("admin_id").notNull(),
	mfaVerifiedAt: timestamp("mfa_verified_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.adminId],
			foreignColumns: [users.id],
			name: "admin_sessions_admin_id_users_id_fk"
		}),
	check("admin_sessions_lifecycle_order", sql`(mfa_verified_at <= expires_at) AND ((revoked_at IS NULL) OR (revoked_at >= created_at))`),
]);

export const integrationErrors = pgTable("integration_errors", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	metadataHash: text("metadata_hash").notNull(),
	status: text().default('open').notNull(),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	check("integration_errors_status_allowed", sql`status = ANY (ARRAY['open'::text, 'resolved'::text])`),
]);

export const adminCaseActions = pgTable("admin_case_actions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	objectType: text("object_type").notNull(),
	objectId: uuid("object_id").notNull(),
	action: text().notNull(),
	actorId: uuid("actor_id").notNull(),
	approvalId: uuid("approval_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.actorId],
			foreignColumns: [users.id],
			name: "admin_case_actions_actor_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "admin_case_actions_approval_id_admin_approvals_id_fk"
		}),
	unique("admin_case_actions_object_action_unique").on(table.objectType, table.objectId, table.action),
	unique("admin_case_actions_approval_unique").on(table.approvalId),
	check("admin_case_actions_action_allowed", sql`action = ANY (ARRAY['acknowledge'::text, 'resolve'::text])`),
	check("admin_case_actions_object_type_allowed", sql`object_type = ANY (ARRAY['safety_alert'::text, 'negative_feedback'::text])`),
]);

export const messagePackages = pgTable("message_packages", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	grantedMessages: integer("granted_messages").notNull(),
	grantIdempotencyKey: text("grant_idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	kind: text().default('paid').notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }),
	grantedAt: timestamp("granted_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	adminApprovalId: uuid("admin_approval_id"),
	adminRequesterSessionIdHash: text("admin_requester_session_id_hash"),
	legacyAdminGrant: boolean("legacy_admin_grant").default(false).notNull(),
}, (table) => [
	index("message_packages_eligible_order").using("btree", table.userId.asc().nullsLast().op("text_ops"), table.kind.asc().nullsLast().op("timestamptz_ops"), table.expiresAt.asc().nullsLast().op("text_ops"), table.grantedAt.asc().nullsLast().op("text_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.adminApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "message_packages_admin_approval_id_admin_approvals_id_fk"
		}),
	foreignKey({
			columns: [table.adminRequesterSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "message_packages_admin_requester_session_id_hash_admin_sessions"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "message_packages_user_id_fkey"
		}),
	unique("message_packages_grant_idempotency_unique").on(table.grantIdempotencyKey),
	check("message_packages_admin_binding_complete", sql`((admin_approval_id IS NULL) AND (admin_requester_session_id_hash IS NULL)) OR ((admin_approval_id IS NOT NULL) AND (admin_requester_session_id_hash IS NOT NULL))`),
	check("message_packages_admin_contract", sql`((kind = 'paid'::text) AND (legacy_admin_grant = false) AND (admin_approval_id IS NULL) AND (admin_requester_session_id_hash IS NULL)) OR ((kind = ANY (ARRAY['admin'::text, 'intro'::text])) AND (legacy_admin_grant = true) AND (admin_approval_id IS NULL) AND (admin_requester_session_id_hash IS NULL)) OR ((kind = 'admin'::text) AND (legacy_admin_grant = false) AND (admin_approval_id IS NOT NULL) AND (admin_requester_session_id_hash IS NOT NULL) AND (granted_messages = ANY (ARRAY[500, 1000, 1500, 2000])) AND (expires_at IS NOT NULL)) OR ((kind = 'intro'::text) AND (legacy_admin_grant = false) AND (admin_approval_id IS NOT NULL) AND (admin_requester_session_id_hash IS NOT NULL) AND (granted_messages = 100) AND (expires_at IS NULL))`),
	check("message_packages_grant_positive", sql`granted_messages > 0`),
	check("message_packages_kind_allowed", sql`kind = ANY (ARRAY['admin'::text, 'paid'::text, 'intro'::text])`),
]);

export const webhookInbox = pgTable("webhook_inbox", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	externalEventId: text("external_event_id").notNull(),
	status: text().notNull(),
	claimId: uuid("claim_id").notNull(),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("webhook_inbox_lease").using("btree", table.status.asc().nullsLast().op("text_ops"), table.leaseUntil.asc().nullsLast().op("timestamptz_ops")),
	unique("webhook_inbox_provider_event_unique").on(table.provider, table.externalEventId),
	check("webhook_inbox_status_allowed", sql`status = ANY (ARRAY['processing'::text, 'complete'::text, 'failed'::text])`),
]);

export const adminObjectAssignments = pgTable("admin_object_assignments", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	adminId: uuid("admin_id").notNull(),
	objectType: text("object_type").notNull(),
	objectId: uuid("object_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.adminId],
			foreignColumns: [users.id],
			name: "admin_object_assignments_admin_id_users_id_fk"
		}),
	unique("admin_object_assignments_scope_unique").on(table.adminId, table.objectType, table.objectId),
	check("admin_object_assignments_type_allowed", sql`object_type = ANY (ARRAY['safety_case'::text, 'feedback_queue'::text, 'selarti_budget_policy'::text])`),
]);

export const expertResidencyPaymentAttempts = pgTable("expert_residency_payment_attempts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	orderId: uuid("order_id").notNull(),
	provider: text().notNull(),
	providerRequestId: text("provider_request_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	expectedAmountMinor: bigint("expected_amount_minor", { mode: "number" }).notNull(),
	currency: text().default('RUB').notNull(),
	status: expertResidencyPaymentAttemptStatus().default('created').notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_payment_attempt_order_status_idx").using("btree", table.orderId.asc().nullsLast().op("enum_ops"), table.status.asc().nullsLast().op("enum_ops")),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_residency_payment_attempts_order_id_expert_residency_ord"
		}),
	unique("expert_payment_attempt_id_order_unique").on(table.id, table.orderId),
	unique("expert_payment_attempt_provider_request_unique").on(table.provider, table.providerRequestId),
	unique("expert_payment_attempt_idempotency_unique").on(table.idempotencyKey),
	check("expert_payment_attempt_amount_bounds", sql`(expected_amount_minor >= 0) AND (expected_amount_minor <= '999999999999'::bigint)`),
	check("expert_payment_attempt_currency_rub", sql`currency = 'RUB'::text`),
	check("expert_payment_attempt_resolution", sql`((status = ANY (ARRAY['created'::expert_residency_payment_attempt_status, 'pending'::expert_residency_payment_attempt_status, 'unknown_outcome'::expert_residency_payment_attempt_status])) AND (resolved_at IS NULL)) OR ((status = ANY (ARRAY['settled'::expert_residency_payment_attempt_status, 'failed'::expert_residency_payment_attempt_status, 'refunded'::expert_residency_payment_attempt_status, 'charged_back'::expert_residency_payment_attempt_status])) AND (resolved_at IS NOT NULL))`),
]);

export const expertReferralAbuseHolds = pgTable("expert_referral_abuse_holds", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	status: expertReferralAbuseHoldStatus().default('open').notNull(),
	reasonCode: text("reason_code").notNull(),
	openedApprovalId: uuid("opened_approval_id").notNull(),
	openedAdminSessionIdHash: text("opened_admin_session_id_hash").notNull(),
	openedAt: timestamp("opened_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	closedApprovalId: uuid("closed_approval_id"),
	closedAdminSessionIdHash: text("closed_admin_session_id_hash"),
	closedReasonCode: text("closed_reason_code"),
	closedAt: timestamp("closed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("expert_abuse_holds_closed_approval_unique").using("btree", table.closedApprovalId.asc().nullsLast().op("uuid_ops")).where(sql`(closed_approval_id IS NOT NULL)`),
	uniqueIndex("expert_abuse_holds_one_open_per_expert").using("btree", table.expertId.asc().nullsLast().op("uuid_ops")).where(sql`(status = 'open'::expert_referral_abuse_hold_status)`),
	foreignKey({
			columns: [table.closedAdminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_abuse_holds_closed_admin_session_id_hash_admin_"
		}),
	foreignKey({
			columns: [table.closedApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_abuse_holds_closed_approval_id_admin_approvals_"
		}),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_referral_abuse_holds_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.openedAdminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_abuse_holds_opened_admin_session_id_hash_admin_"
		}),
	foreignKey({
			columns: [table.openedApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_abuse_holds_opened_approval_id_admin_approvals_"
		}),
	unique("expert_abuse_holds_opened_approval_unique").on(table.openedApprovalId),
	check("expert_abuse_holds_lifecycle", sql`((status = 'open'::expert_referral_abuse_hold_status) AND (closed_approval_id IS NULL) AND (closed_admin_session_id_hash IS NULL) AND (closed_reason_code IS NULL) AND (closed_at IS NULL)) OR ((status = 'closed'::expert_referral_abuse_hold_status) AND (closed_approval_id IS NOT NULL) AND (closed_admin_session_id_hash IS NOT NULL) AND (closed_reason_code IS NOT NULL) AND (closed_at >= opened_at))`),
	check("expert_abuse_holds_reason_bounded", sql`((char_length(reason_code) >= 1) AND (char_length(reason_code) <= 128)) AND ((closed_reason_code IS NULL) OR ((char_length(closed_reason_code) >= 1) AND (char_length(closed_reason_code) <= 128)))`),
]);

export const expertReferralCodeBatches = pgTable("expert_referral_code_batches", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	requestedCount: integer("requested_count").notNull(),
	issuedByAdminId: uuid("issued_by_admin_id").notNull(),
	approvalId: uuid("approval_id").notNull(),
	adminSessionIdHash: text("admin_session_id_hash").notNull(),
	status: expertReferralBatchStatus().default('issued').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_referral_batches_inviter_created_idx").using("btree", table.inviterExpertId.asc().nullsLast().op("uuid_ops"), table.createdAt.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.adminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_code_batches_admin_session_id_hash_admin_sessio"
		}),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_code_batches_approval_id_admin_approvals_id_fk"
		}),
	foreignKey({
			columns: [table.inviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_referral_code_batches_inviter_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.issuedByAdminId],
			foreignColumns: [users.id],
			name: "expert_referral_code_batches_issued_by_admin_id_users_id_fk"
		}),
	unique("expert_referral_batches_id_inviter_unique").on(table.id, table.inviterExpertId),
	unique("expert_referral_batches_approval_unique").on(table.approvalId),
	check("expert_referral_batches_requested_count_bounded", sql`(requested_count >= 1) AND (requested_count <= 1000)`),
]);

export const expertReferralCodes = pgTable("expert_referral_codes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	batchId: uuid("batch_id").notNull(),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	codeHash: text("code_hash").notNull(),
	keyVersion: integer("key_version").notNull(),
	maskedSuffix: text("masked_suffix").notNull(),
	status: expertReferralCodeStatus().default('issued').notNull(),
	issuedAt: timestamp("issued_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	redeemedAt: timestamp("redeemed_at", { withTimezone: true, mode: 'string' }),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
	revokedApprovalId: uuid("revoked_approval_id"),
	revokedAdminSessionIdHash: text("revoked_admin_session_id_hash"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_referral_codes_inviter_status_idx").using("btree", table.inviterExpertId.asc().nullsLast().op("enum_ops"), table.status.asc().nullsLast().op("uuid_ops"), table.issuedAt.asc().nullsLast().op("enum_ops")),
	foreignKey({
			columns: [table.batchId, table.inviterExpertId],
			foreignColumns: [expertReferralCodeBatches.id, expertReferralCodeBatches.inviterExpertId],
			name: "expert_referral_codes_batch_owner_fk"
		}),
	foreignKey({
			columns: [table.inviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_referral_codes_inviter_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.revokedAdminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_codes_revoked_admin_session_id_hash_admin_sessi"
		}),
	foreignKey({
			columns: [table.revokedApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_codes_revoked_approval_id_admin_approvals_id_fk"
		}),
	unique("expert_referral_codes_id_inviter_unique").on(table.id, table.inviterExpertId),
	unique("expert_referral_codes_hash_unique").on(table.codeHash),
	check("expert_referral_codes_hash_format", sql`code_hash ~ '^[0-9a-f]{64}$'::text`),
	check("expert_referral_codes_key_version_positive", sql`key_version > 0`),
	check("expert_referral_codes_lifecycle", sql`((status = 'issued'::expert_referral_code_status) AND (redeemed_at IS NULL) AND (revoked_at IS NULL) AND (revoked_approval_id IS NULL) AND (revoked_admin_session_id_hash IS NULL)) OR ((status = 'redeemed'::expert_referral_code_status) AND (redeemed_at IS NOT NULL) AND (revoked_at IS NULL) AND (revoked_approval_id IS NULL) AND (revoked_admin_session_id_hash IS NULL)) OR ((status = 'revoked'::expert_referral_code_status) AND (redeemed_at IS NULL) AND (revoked_at IS NOT NULL) AND (revoked_approval_id IS NOT NULL) AND (revoked_admin_session_id_hash IS NOT NULL))`),
	check("expert_referral_codes_masked_suffix_bounded", sql`(char_length(masked_suffix) >= 4) AND (char_length(masked_suffix) <= 12)`),
]);

export const expertReferralFeatureControls = pgTable("expert_referral_feature_controls", {
	controlKey: text("control_key").default('expert_referrals').primaryKey().notNull(),
	version: integer().notNull(),
	newCommandsEnabled: boolean("new_commands_enabled").default(false).notNull(),
	rewardGrantsEnabled: boolean("reward_grants_enabled").default(false).notNull(),
	updatedApprovalId: uuid("updated_approval_id").notNull(),
	updatedAdminSessionIdHash: text("updated_admin_session_id_hash").notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.updatedAdminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_feature_controls_updated_admin_session_id_hash_"
		}),
	foreignKey({
			columns: [table.updatedApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_feature_controls_updated_approval_id_admin_appr"
		}),
	unique("expert_referral_controls_approval_unique").on(table.updatedApprovalId),
	check("expert_referral_controls_singleton", sql`control_key = 'expert_referrals'::text`),
	check("expert_referral_controls_version_positive", sql`version > 0`),
]);

export const expertReferralIssuanceOverrides = pgTable("expert_referral_issuance_overrides", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	additionalQuota: integer("additional_quota").notNull(),
	consumedCount: integer("consumed_count").default(0).notNull(),
	reasonCode: text("reason_code").notNull(),
	validFrom: timestamp("valid_from", { withTimezone: true, mode: 'string' }).notNull(),
	validUntil: timestamp("valid_until", { withTimezone: true, mode: 'string' }).notNull(),
	requesterId: uuid("requester_id").notNull(),
	approverOneId: uuid("approver_one_id").notNull(),
	approverTwoId: uuid("approver_two_id").notNull(),
	approvalOneId: uuid("approval_one_id").notNull(),
	approvalTwoId: uuid("approval_two_id").notNull(),
	requesterSessionIdHash: text("requester_session_id_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_issuance_overrides_inviter_validity_idx").using("btree", table.inviterExpertId.asc().nullsLast().op("timestamptz_ops"), table.validUntil.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.approvalOneId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_issuance_overrides_approval_one_id_admin_approv"
		}),
	foreignKey({
			columns: [table.approvalTwoId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_issuance_overrides_approval_two_id_admin_approv"
		}),
	foreignKey({
			columns: [table.approverOneId],
			foreignColumns: [users.id],
			name: "expert_referral_issuance_overrides_approver_one_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.approverTwoId],
			foreignColumns: [users.id],
			name: "expert_referral_issuance_overrides_approver_two_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.inviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_referral_issuance_overrides_inviter_expert_id_experts_id"
		}),
	foreignKey({
			columns: [table.requesterId],
			foreignColumns: [users.id],
			name: "expert_referral_issuance_overrides_requester_id_users_id_fk"
		}),
	foreignKey({
			columns: [table.requesterSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_issuance_overrides_requester_session_id_hash_ad"
		}),
	unique("expert_issuance_overrides_approval_one_unique").on(table.approvalOneId),
	unique("expert_issuance_overrides_approval_two_unique").on(table.approvalTwoId),
	check("expert_issuance_override_distinct_approvers", sql`(approver_one_id <> approver_two_id) AND (requester_id <> approver_one_id) AND (requester_id <> approver_two_id) AND (approval_one_id <> approval_two_id)`),
	check("expert_issuance_override_quota_bounded", sql`((additional_quota >= 1) AND (additional_quota <= 1000)) AND ((consumed_count >= 0) AND (consumed_count <= additional_quota))`),
	check("expert_issuance_override_reason_bounded", sql`(char_length(reason_code) >= 1) AND (char_length(reason_code) <= 128)`),
	check("expert_issuance_override_validity", sql`valid_until > valid_from`),
]);

export const expertReferralLedgerEntries = pgTable("expert_referral_ledger_entries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	entryKind: expertReferralLedgerEntryKind("entry_kind").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
	orderId: uuid("order_id"),
	originalEntryId: uuid("original_entry_id"),
	sourceType: text("source_type").notNull(),
	sourceId: uuid("source_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	adminApprovalId: uuid("admin_approval_id"),
	adminSessionIdHash: text("admin_session_id_hash"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_ledger_expert_created_idx").using("btree", table.expertId.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.originalEntryId],
			foreignColumns: [table.id],
			name: "expert_ledger_original_entry_fk"
		}),
	foreignKey({
			columns: [table.adminApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_ledger_entries_admin_approval_id_admin_approval"
		}),
	foreignKey({
			columns: [table.adminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_ledger_entries_admin_session_id_hash_admin_sess"
		}),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_referral_ledger_entries_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_referral_ledger_entries_order_id_expert_residency_orders"
		}),
	unique("expert_ledger_entries_id_expert_unique").on(table.id, table.expertId),
	unique("expert_ledger_idempotency_unique").on(table.idempotencyKey),
	check("expert_ledger_admin_binding_complete", sql`((admin_approval_id IS NULL) AND (admin_session_id_hash IS NULL)) OR ((admin_approval_id IS NOT NULL) AND (admin_session_id_hash IS NOT NULL))`),
	check("expert_ledger_amount_bounds", sql`(amount_minor <> 0) AND (abs(amount_minor) <= '999999999999'::bigint)`),
	check("expert_ledger_kind_contract", sql`((entry_kind = 'reward_grant'::expert_referral_ledger_entry_kind) AND (amount_minor > 0) AND (order_id IS NULL) AND (original_entry_id IS NULL)) OR ((entry_kind = 'reservation'::expert_referral_ledger_entry_kind) AND (amount_minor < 0) AND (order_id IS NOT NULL) AND (original_entry_id IS NULL)) OR ((entry_kind = ANY (ARRAY['release'::expert_referral_ledger_entry_kind, 'debt_repayment'::expert_referral_ledger_entry_kind])) AND (amount_minor > 0) AND (original_entry_id IS NOT NULL)) OR ((entry_kind = ANY (ARRAY['spend'::expert_referral_ledger_entry_kind, 'expiry'::expert_referral_ledger_entry_kind, 'reversal'::expert_referral_ledger_entry_kind])) AND (amount_minor < 0) AND (original_entry_id IS NOT NULL)) OR ((entry_kind = 'administrative_correction'::expert_referral_ledger_entry_kind) AND (admin_approval_id IS NOT NULL) AND (admin_session_id_hash IS NOT NULL))`),
]);

export const expertReferralRewardGrants = pgTable("expert_referral_reward_grants", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	referralId: uuid("referral_id").notNull(),
	firstSettlementId: uuid("first_settlement_id").notNull(),
	qualifyingOrderId: uuid("qualifying_order_id").notNull(),
	qualifyingPaymentAttemptId: uuid("qualifying_payment_attempt_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).default(100000).notNull(),
	grantedAt: timestamp("granted_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	maturityId: uuid("maturity_id"),
}, (table) => [
	index("expert_reward_grants_expert_expiry_idx").using("btree", table.expertId.asc().nullsLast().op("timestamptz_ops"), table.expiresAt.asc().nullsLast().op("timestamptz_ops")),
	uniqueIndex("expert_reward_grants_maturity_unique").using("btree", table.maturityId.asc().nullsLast().op("uuid_ops")).where(sql`(maturity_id IS NOT NULL)`),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_referral_reward_grants_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.referralId, table.firstSettlementId, table.qualifyingOrderId, table.qualifyingPaymentAttemptId],
			foreignColumns: [expertFirstResidencySettlements.id, expertFirstResidencySettlements.qualifyingOrderId, expertFirstResidencySettlements.qualifyingPaymentAttemptId, expertFirstResidencySettlements.referralId],
			name: "expert_reward_grants_first_marker_fk"
		}),
	foreignKey({
			columns: [table.maturityId],
			foreignColumns: [expertReferralRewardMaturities.id],
			name: "expert_reward_grants_maturity_fk"
		}),
	foreignKey({
			columns: [table.expertId, table.referralId],
			foreignColumns: [expertReferrals.id, expertReferrals.inviterExpertId],
			name: "expert_reward_grants_referral_inviter_fk"
		}),
	unique("expert_reward_grants_id_expert_unique").on(table.id, table.expertId),
	unique("expert_reward_grants_referral_unique").on(table.referralId),
	unique("expert_reward_grants_first_settlement_unique").on(table.firstSettlementId),
	unique("expert_reward_grants_qualifying_order_unique").on(table.qualifyingOrderId),
	unique("expert_reward_grants_qualifying_payment_unique").on(table.qualifyingPaymentAttemptId),
	unique("expert_reward_grants_idempotency_unique").on(table.idempotencyKey),
	check("expert_reward_grant_exact_amount", sql`amount_minor = 100000`),
	check("expert_reward_grant_expiry_exact", sql`expires_at = (granted_at + '365 days'::interval)`),
]);

export const expertFirstResidencySettlements = pgTable("expert_first_residency_settlements", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	settlementSequence: bigserial("settlement_sequence", { mode: "bigint" }).notNull(),
	qualifyingOrderId: uuid("qualifying_order_id").notNull(),
	qualifyingPaymentAttemptId: uuid("qualifying_payment_attempt_id").notNull(),
	referralId: uuid("referral_id"),
	eligibility: expertFirstSettlementEligibility().notNull(),
	reasonCode: text("reason_code").notNull(),
	settlementExpertActive: boolean("settlement_expert_active").notNull(),
	settlementExpertVerified: boolean("settlement_expert_verified").notNull(),
	settlementAbuseCleared: boolean("settlement_abuse_cleared").notNull(),
	settledAt: timestamp("settled_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	settlementControlVersion: integer("settlement_control_version").default(0).notNull(),
	settlementInviteeUserId: uuid("settlement_invitee_user_id"),
	settlementInviteeChannelIdentityId: uuid("settlement_invitee_channel_identity_id"),
	settlementInviterExpertId: uuid("settlement_inviter_expert_id"),
	settlementInviterUserId: uuid("settlement_inviter_user_id"),
	settlementInviterChannelIdentityId: uuid("settlement_inviter_channel_identity_id"),
}, (table) => [
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_first_residency_settlements_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.settlementInviteeChannelIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "expert_first_residency_settlements_settlement_invitee_channel_i"
		}),
	foreignKey({
			columns: [table.settlementInviteeUserId],
			foreignColumns: [users.id],
			name: "expert_first_residency_settlements_settlement_invitee_user_id_u"
		}),
	foreignKey({
			columns: [table.settlementInviterChannelIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "expert_first_residency_settlements_settlement_inviter_channel_i"
		}),
	foreignKey({
			columns: [table.settlementInviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_first_residency_settlements_settlement_inviter_expert_id"
		}),
	foreignKey({
			columns: [table.settlementInviterUserId],
			foreignColumns: [users.id],
			name: "expert_first_residency_settlements_settlement_inviter_user_id_u"
		}),
	foreignKey({
			columns: [table.expertId, table.qualifyingOrderId],
			foreignColumns: [expertResidencyOrders.id, expertResidencyOrders.expertId],
			name: "expert_first_settlement_order_owner_fk"
		}),
	foreignKey({
			columns: [table.qualifyingOrderId, table.qualifyingPaymentAttemptId],
			foreignColumns: [expertResidencyPaymentAttempts.id, expertResidencyPaymentAttempts.orderId],
			name: "expert_first_settlement_payment_order_fk"
		}),
	foreignKey({
			columns: [table.expertId, table.referralId],
			foreignColumns: [expertReferrals.id, expertReferrals.inviteeExpertId],
			name: "expert_first_settlement_referral_invitee_fk"
		}),
	unique("expert_first_settlement_identity_unique").on(table.id, table.qualifyingOrderId, table.qualifyingPaymentAttemptId, table.referralId),
	unique("expert_first_settlement_expert_unique").on(table.expertId),
	unique("expert_first_settlement_sequence_unique").on(table.settlementSequence),
	unique("expert_first_settlement_order_unique").on(table.qualifyingOrderId),
	check("expert_first_settlement_eligibility_evidence", sql`((eligibility = ANY (ARRAY['eligible'::expert_first_settlement_eligibility, 'pending_feature_hold'::expert_first_settlement_eligibility])) AND (referral_id IS NOT NULL) AND settlement_expert_active AND settlement_expert_verified AND settlement_abuse_cleared) OR (eligibility = ANY (ARRAY['permanently_ineligible'::expert_first_settlement_eligibility, 'cancelled_by_refund'::expert_first_settlement_eligibility]))`),
	check("expert_first_settlement_pending_snapshot_complete", sql`(eligibility <> 'pending_feature_hold'::expert_first_settlement_eligibility) OR ((settlement_invitee_user_id IS NOT NULL) AND (settlement_invitee_channel_identity_id IS NOT NULL) AND (settlement_inviter_expert_id IS NOT NULL) AND (settlement_inviter_user_id IS NOT NULL) AND (settlement_inviter_channel_identity_id IS NOT NULL))`),
]);

export const expertResidencyProviderEventInbox = pgTable("expert_residency_provider_event_inbox", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	provider: text().notNull(),
	externalEventId: text("external_event_id").notNull(),
	payloadDigest: text("payload_digest").notNull(),
	eventKind: text("event_kind").notNull(),
	authenticated: boolean().notNull(),
	status: expertResidencyProviderEventStatus().default('received').notNull(),
	resultCode: text("result_code"),
	receivedAt: timestamp("received_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	processedAt: timestamp("processed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	verificationId: text("verification_id"),
	verifierKeyVersion: text("verifier_key_version"),
	verifiedAt: timestamp("verified_at", { withTimezone: true, mode: 'string' }),
	paymentId: text("payment_id"),
	orderId: uuid("order_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }),
	currency: text(),
	occurredAt: timestamp("occurred_at", { withTimezone: true, mode: 'string' }),
	identityVersion: integer("identity_version").default(0).notNull(),
	resultPayload: jsonb("result_payload"),
	resultSchemaVersion: integer("result_schema_version"),
	resultLegacyExempt: boolean("result_legacy_exempt").default(false).notNull(),
}, (table) => [
	index("expert_provider_event_status_received_idx").using("btree", table.status.asc().nullsLast().op("timestamptz_ops"), table.receivedAt.asc().nullsLast().op("enum_ops")),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_provider_event_order_fk"
		}),
	unique("expert_provider_event_unique").on(table.provider, table.externalEventId),
	check("expert_provider_event_amount_bounded", sql`(amount_minor >= 0) AND (amount_minor <= '999999999999'::bigint)`),
	check("expert_provider_event_currency_rub", sql`currency = 'RUB'::text`),
	check("expert_provider_event_digest_format", sql`payload_digest ~ '^[0-9a-f]{64}$'::text`),
	check("expert_provider_event_identity_complete", sql`((identity_version = 0) AND (payment_id IS NULL) AND (order_id IS NULL) AND (amount_minor IS NULL) AND (currency IS NULL) AND (occurred_at IS NULL) AND (verification_id IS NULL) AND (verifier_key_version IS NULL) AND (verified_at IS NULL)) OR ((identity_version = 1) AND (payment_id IS NOT NULL) AND (order_id IS NOT NULL) AND (amount_minor IS NOT NULL) AND (currency IS NOT NULL) AND (occurred_at IS NOT NULL) AND (verification_id IS NOT NULL) AND (verifier_key_version IS NOT NULL) AND (verified_at IS NOT NULL))`),
	check("expert_provider_event_processing_state", sql`((status = ANY (ARRAY['received'::expert_residency_provider_event_status, 'processing'::expert_residency_provider_event_status, 'reconciliation_required'::expert_residency_provider_event_status])) AND (processed_at IS NULL)) OR ((status = ANY (ARRAY['processed'::expert_residency_provider_event_status, 'rejected'::expert_residency_provider_event_status])) AND (processed_at IS NOT NULL))`),
	check("expert_provider_reversal_result_shape", sql`(event_kind <> ALL (ARRAY['refunded'::text, 'charged_back'::text])) OR (status <> 'processed'::expert_residency_provider_event_status) OR (result_legacy_exempt AND (result_schema_version IS NULL) AND (result_payload IS NULL)) OR COALESCE(((NOT (result_schema_version IS DISTINCT FROM 1)) AND (result_payload IS NOT NULL) AND (jsonb_typeof(result_payload) = 'object'::text) AND expert_jsonb_has_exact_keys(result_payload, ARRAY['kind'::text, 'eventId'::text, 'paymentId'::text, 'orderId'::text, 'cashRefundedMinor'::text, 'restoredCreditMinor'::text, 'rewardReversed'::text, 'debtMinor'::text, 'terminated'::text]) AND ((result_payload ->> 'kind'::text) = event_kind) AND ((result_payload ->> 'eventId'::text) = external_event_id) AND ((result_payload ->> 'paymentId'::text) = payment_id) AND ((result_payload ->> 'orderId'::text) = (order_id)::text) AND ((result_payload ->> 'cashRefundedMinor'::text) ~ '^(0|[1-9][0-9]{0,11})$'::text) AND ((result_payload ->> 'restoredCreditMinor'::text) = '0'::text) AND (jsonb_typeof((result_payload -> 'rewardReversed'::text)) = 'boolean'::text) AND ((result_payload ->> 'debtMinor'::text) ~ '^(0|[1-9][0-9]{0,11})$'::text) AND (jsonb_typeof((result_payload -> 'terminated'::text)) = 'boolean'::text)), false)`),
	check("expert_provider_verification_id_bounded", sql`(char_length(verification_id) >= 1) AND (char_length(verification_id) <= 200)`),
	check("expert_provider_verifier_key_bounded", sql`(char_length(verifier_key_version) >= 1) AND (char_length(verifier_key_version) <= 100)`),
]);

export const expertReferrals = pgTable("expert_referrals", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	codeId: uuid("code_id"),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	inviteeExpertId: uuid("invitee_expert_id").notNull(),
	boundAt: timestamp("bound_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	acquisitionSource: text("acquisition_source").default('qualified_code').notNull(),
	promoQualificationId: uuid("promo_qualification_id"),
}, (table) => [
	index("expert_referrals_inviter_idx").using("btree", table.inviterExpertId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.codeId, table.inviterExpertId],
			foreignColumns: [expertReferralCodes.id, expertReferralCodes.inviterExpertId],
			name: "expert_referrals_code_owner_fk"
		}),
	foreignKey({
			columns: [table.inviteeExpertId],
			foreignColumns: [experts.id],
			name: "expert_referrals_invitee_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.inviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_referrals_inviter_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.inviterExpertId, table.inviteeExpertId, table.promoQualificationId],
			foreignColumns: [expertPromoQualificationAudits.id, expertPromoQualificationAudits.inviteeExpertId, expertPromoQualificationAudits.inviterExpertId],
			name: "expert_referrals_promo_qualification_fk"
		}),
	unique("expert_referrals_id_inviter_unique").on(table.id, table.inviterExpertId),
	unique("expert_referrals_id_invitee_unique").on(table.id, table.inviteeExpertId),
	unique("expert_referrals_code_unique").on(table.codeId),
	unique("expert_referrals_invitee_unique").on(table.inviteeExpertId),
	unique("expert_referrals_promo_qualification_unique").on(table.promoQualificationId),
	check("expert_referrals_distinct_experts", sql`inviter_expert_id <> invitee_expert_id`),
	check("expert_referrals_source", sql`((acquisition_source = 'qualified_code'::text) AND (code_id IS NOT NULL) AND (promo_qualification_id IS NULL)) OR ((acquisition_source = 'promo_registration'::text) AND (code_id IS NULL) AND (promo_qualification_id IS NOT NULL))`),
]);

export const expertResidencyReceiptContacts = pgTable("expert_residency_receipt_contacts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	contactKind: text("contact_kind").notNull(),
	ciphertext: text().notNull(),
	keyReference: text("key_reference").notNull(),
	consentId: uuid("consent_id").notNull(),
	consentDecision: text("consent_decision").notNull(),
	consentPurpose: text("consent_purpose").notNull(),
	policyVersion: text("policy_version").notNull(),
	verifiedAt: timestamp("verified_at", { withTimezone: true, mode: 'string' }),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`transaction_timestamp()`).notNull(),
}, (table) => [
	index("expert_receipt_contacts_authority_idx").using("btree", table.userId.asc().nullsLast().op("text_ops"), table.consentPurpose.asc().nullsLast().op("uuid_ops"), table.policyVersion.asc().nullsLast().op("timestamptz_ops"), table.createdAt.desc().nullsFirst().op("timestamptz_ops"), table.id.desc().nullsFirst().op("uuid_ops")),
	foreignKey({
			columns: [table.consentId],
			foreignColumns: [consents.id],
			name: "expert_receipt_contacts_consent_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_receipt_contacts_user_fk"
		}).onDelete("restrict"),
	check("expert_receipt_contacts_ciphertext", sql`(length(ciphertext) >= 1) AND (length(ciphertext) <= 8192)`),
	check("expert_receipt_contacts_consent", sql`consent_decision = ANY (ARRAY['granted'::text, 'denied'::text])`),
	check("expert_receipt_contacts_key_reference", sql`key_reference ~ '^[a-z][a-z0-9_-]{1,31}:[A-Za-z0-9._/-]{1,192}$'::text`),
	check("expert_receipt_contacts_kind", sql`contact_kind = ANY (ARRAY['email'::text, 'phone'::text])`),
	check("expert_receipt_contacts_revocation", sql`(revoked_at IS NULL) OR ((verified_at IS NOT NULL) AND (revoked_at >= verified_at))`),
	check("expert_receipt_contacts_verification", sql`((consent_decision = 'granted'::text) AND (verified_at IS NOT NULL)) OR ((consent_decision = 'denied'::text) AND (verified_at IS NULL))`),
]);

export const expertAiRequestReceipts = pgTable("expert_ai_request_receipts", {
	requestKeyHash: char("request_key_hash", { length: 64 }).primaryKey().notNull(),
	requestDigest: char("request_digest", { length: 64 }).notNull(),
	status: text().notNull(),
	claimId: uuid("claim_id").notNull(),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	version: integer().default(1).notNull(),
	outcomeStatus: integer("outcome_status"),
	outcomeCode: text("outcome_code"),
	outcomeDetail: text("outcome_detail"),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(now() + '7 days'::interval)`).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_ai_request_receipts_cleanup_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = ANY (ARRAY['complete'::text, 'failed'::text]))`),
	index("expert_ai_request_receipts_lease_idx").using("btree", table.leaseUntil.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = 'processing'::text)`),
	check("expert_ai_request_receipts_hashes_check", sql`(request_key_hash ~ '^[0-9a-f]{64}$'::text) AND (request_digest ~ '^[0-9a-f]{64}$'::text)`),
	check("expert_ai_request_receipts_state_check", sql`((status = 'processing'::text) AND (lease_until IS NOT NULL) AND (outcome_status IS NULL) AND (outcome_code IS NULL) AND (outcome_detail IS NULL)) OR ((status = 'failed'::text) AND (lease_until IS NULL) AND (outcome_status IS NULL) AND (outcome_code IS NULL) AND (outcome_detail IS NULL)) OR ((status = 'complete'::text) AND (lease_until IS NULL) AND (((outcome_status = 200) AND (outcome_code = 'completed'::text) AND (outcome_detail = ANY (ARRAY['redeem_expert_referral'::text, 'view_referral_summary'::text, 'quote_residency'::text, 'start_residency_checkout'::text]))) OR ((outcome_status = 422) AND (outcome_code = 'proposal_rejected'::text) AND (outcome_detail = ANY (ARRAY['invalid_shape'::text, 'unsupported_intent'::text, 'unauthorized_scope'::text]))) OR ((outcome_status = 403) AND (outcome_code = 'forbidden'::text) AND (outcome_detail IS NULL)) OR ((outcome_status = 503) AND (outcome_code = 'feature_disabled'::text) AND (outcome_detail IS NULL))))`),
	check("expert_ai_request_receipts_status_check", sql`status = ANY (ARRAY['processing'::text, 'complete'::text, 'failed'::text])`),
	check("expert_ai_request_receipts_version_check", sql`version > 0`),
]);

export const expertResidencyProviderOperations = pgTable("expert_residency_provider_operations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	commandId: uuid("command_id").notNull(),
	orderId: uuid("order_id").notNull(),
	paymentAttemptId: uuid("payment_attempt_id").notNull(),
	operationKind: text("operation_kind").notNull(),
	provider: text().default('yookassa').notNull(),
	environmentMode: text("environment_mode").notNull(),
	providerObjectId: text("provider_object_id"),
	parentPaymentId: text("parent_payment_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
	currency: text().default('RUB').notNull(),
	requestDigest: text("request_digest").notNull(),
	claimDigest: text("claim_digest").notNull(),
	idempotencyKey: uuid("idempotency_key").defaultRandom().notNull(),
	status: text().default('claimed').notNull(),
	reconciliationClaimedAt: timestamp("reconciliation_claimed_at", { withTimezone: true, mode: 'string' }),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`transaction_timestamp()`).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`transaction_timestamp()`).notNull(),
	replayCiphertext: text("replay_ciphertext"),
	replayKeyReference: text("replay_key_reference"),
	replayBodyVersion: integer("replay_body_version"),
	recoveryAttempt: integer("recovery_attempt").default(0).notNull(),
	recoveryNextAt: timestamp("recovery_next_at", { withTimezone: true, mode: 'string' }),
	recoveryLeaseToken: uuid("recovery_lease_token"),
	recoveryLeaseUntil: timestamp("recovery_lease_until", { withTimezone: true, mode: 'string' }),
	recoveryExpiresAt: timestamp("recovery_expires_at", { withTimezone: true, mode: 'string' }),
	manualReviewAt: timestamp("manual_review_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	uniqueIndex("expert_provider_operations_command_unique").using("btree", table.provider.asc().nullsLast().op("uuid_ops"), table.commandId.asc().nullsLast().op("text_ops")),
	uniqueIndex("expert_provider_operations_idempotency_unique").using("btree", table.idempotencyKey.asc().nullsLast().op("uuid_ops")),
	uniqueIndex("expert_provider_operations_object_unique").using("btree", table.provider.asc().nullsLast().op("text_ops"), table.providerObjectId.asc().nullsLast().op("text_ops")).where(sql`(provider_object_id IS NOT NULL)`),
	index("expert_provider_operations_order_kind_idx").using("btree", table.orderId.asc().nullsLast().op("timestamptz_ops"), table.operationKind.asc().nullsLast().op("text_ops"), table.createdAt.asc().nullsLast().op("uuid_ops")),
	index("expert_provider_operations_reconcile_idx").using("btree", table.status.asc().nullsLast().op("text_ops"), table.reconciliationClaimedAt.asc().nullsLast().op("text_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("text_ops")),
	index("expert_provider_operations_unbound_recovery_idx").using("btree", table.recoveryNextAt.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`((provider_object_id IS NULL) AND (status = 'unknown_outcome'::text) AND (replay_ciphertext IS NOT NULL) AND (manual_review_at IS NULL))`),
	foreignKey({
			columns: [table.orderId, table.paymentAttemptId],
			foreignColumns: [expertResidencyPaymentAttempts.id, expertResidencyPaymentAttempts.orderId],
			name: "expert_provider_operations_attempt_order_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_provider_operations_order_fk"
		}).onDelete("restrict"),
	check("expert_provider_operations_amount", sql`(amount_minor > 0) AND (amount_minor <= '999999999999'::bigint)`),
	check("expert_provider_operations_claim_digest", sql`claim_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_provider_operations_currency", sql`currency = 'RUB'::text`),
	check("expert_provider_operations_kind", sql`operation_kind = ANY (ARRAY['create_payment'::text, 'create_refund'::text])`),
	check("expert_provider_operations_manual_review", sql`(manual_review_at IS NULL) OR ((provider_object_id IS NULL) AND (status = 'unknown_outcome'::text))`),
	check("expert_provider_operations_mode", sql`environment_mode = ANY (ARRAY['test'::text, 'live'::text])`),
	check("expert_provider_operations_parent", sql`((operation_kind = 'create_payment'::text) AND (parent_payment_id IS NULL)) OR ((operation_kind = 'create_refund'::text) AND (parent_payment_id ~ '^[A-Za-z0-9_-]{1,64}$'::text))`),
	check("expert_provider_operations_provider", sql`provider = 'yookassa'::text`),
	check("expert_provider_operations_provider_id", sql`(provider_object_id IS NULL) OR (provider_object_id ~ '^[A-Za-z0-9_-]{1,64}$'::text)`),
	check("expert_provider_operations_recovery_attempt", sql`(recovery_attempt >= 0) AND (recovery_attempt <= 100)`),
	check("expert_provider_operations_recovery_lease", sql`(recovery_lease_token IS NULL) = (recovery_lease_until IS NULL)`),
	check("expert_provider_operations_replay_bundle", sql`((replay_ciphertext IS NULL) AND (replay_key_reference IS NULL) AND (replay_body_version IS NULL) AND (recovery_expires_at IS NULL)) OR (((length(replay_ciphertext) >= 1) AND (length(replay_ciphertext) <= 32768)) AND (replay_key_reference ~ '^[a-z][a-z0-9_-]{1,31}:[A-Za-z0-9._/-]{1,192}$'::text) AND ((replay_body_version >= 1) AND (replay_body_version <= 2147483647)) AND (recovery_expires_at IS NOT NULL))`),
	check("expert_provider_operations_request_digest", sql`request_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_provider_operations_resolution", sql`((status = ANY (ARRAY['claimed'::text, 'pending'::text, 'unknown_outcome'::text])) AND (resolved_at IS NULL)) OR ((status = ANY (ARRAY['succeeded'::text, 'canceled'::text, 'failed'::text])) AND (resolved_at IS NOT NULL))`),
	check("expert_provider_operations_status", sql`status = ANY (ARRAY['claimed'::text, 'pending'::text, 'unknown_outcome'::text, 'succeeded'::text, 'canceled'::text, 'failed'::text])`),
]);

export const clientCatalogRequests = pgTable("client_catalog_requests", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	requestDigest: char("request_digest", { length: 64 }).notNull(),
	serviceCode: text("service_code"),
	language: text(),
	state: text().default('pending').notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(now() + '24:00:00'::interval)`).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_catalog_requests_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(state = ANY (ARRAY['pending'::text, 'ready'::text]))`),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_catalog_requests_user_fk"
		}).onDelete("cascade"),
	unique("client_catalog_requests_user_digest_unique").on(table.userId, table.requestDigest),
	check("client_catalog_requests_digest_check", sql`request_digest ~ '^[0-9a-f]{64}$'::text`),
	check("client_catalog_requests_filters_check", sql`((service_code IS NULL) OR (((char_length(service_code) >= 1) AND (char_length(service_code) <= 64)) AND (service_code !~ '[[:cntrl:]]'::text))) AND ((language IS NULL) OR (((char_length(language) >= 1) AND (char_length(language) <= 32)) AND (language !~ '[[:cntrl:]]'::text)))`),
	check("client_catalog_requests_state_check", sql`state = ANY (ARRAY['pending'::text, 'ready'::text])`),
	check("client_catalog_requests_time_check", sql`(expires_at >= created_at) AND (updated_at >= created_at)`),
]);

export const outboxOperatorAlerts = pgTable("outbox_operator_alerts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	outboxId: uuid("outbox_id").notNull(),
	reasonCode: text("reason_code").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	caseType: text("case_type").default('delivery_failure').notNull(),
	caseReasonCode: text("case_reason_code").default('delivery_failure').notNull(),
	status: text().default('open').notNull(),
	rating: integer(),
	contentHash: text("content_hash"),
	policyVersion: text("policy_version"),
	acknowledgedAt: timestamp("acknowledged_at", { withTimezone: true, mode: 'string' }),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("outbox_operator_alerts_unresolved_cursor_idx").using("btree", table.caseType.asc().nullsLast().op("text_ops"), table.status.asc().nullsLast().op("text_ops"), table.createdAt.desc().nullsFirst().op("text_ops"), table.id.desc().nullsFirst().op("text_ops")).where(sql`(status = ANY (ARRAY['open'::text, 'acknowledged'::text]))`),
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "outbox_operator_alerts_outbox_id_integration_outbox_id_fk"
		}),
	unique("outbox_operator_alerts_outbox_reason_unique").on(table.outboxId, table.reasonCode),
	check("outbox_operator_alerts_case_reason_check", sql`case_reason_code ~ '^[a-z0-9][a-z0-9._:-]{0,127}$'::text`),
	check("outbox_operator_alerts_case_type_check", sql`case_type = ANY (ARRAY['safety'::text, 'negative_feedback'::text, 'delivery_failure'::text])`),
	check("outbox_operator_alerts_lifecycle_check", sql`(((status = 'open'::text) AND (acknowledged_at IS NULL) AND (resolved_at IS NULL)) OR ((status = 'acknowledged'::text) AND (acknowledged_at IS NOT NULL) AND (resolved_at IS NULL)) OR ((status = 'resolved'::text) AND (resolved_at IS NOT NULL))) AND (updated_at >= created_at) AND ((acknowledged_at IS NULL) OR (acknowledged_at >= created_at)) AND ((resolved_at IS NULL) OR (resolved_at >= created_at))`),
	check("outbox_operator_alerts_payload_check", sql`((case_type = 'safety'::text) AND (case_reason_code = 'safety_operator_escalation'::text) AND (rating IS NULL) AND (content_hash IS NULL) AND (policy_version IS NULL)) OR ((case_type = 'negative_feedback'::text) AND (case_reason_code = 'negative_feedback_policy'::text) AND ((rating >= 1) AND (rating <= 5)) AND (content_hash ~ '^[0-9a-f]{64}$'::text) AND (policy_version ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$'::text)) OR ((case_type = 'delivery_failure'::text) AND (case_reason_code = ANY (ARRAY['delivery_failure'::text, 'negative_feedback_source_invalid'::text])) AND (rating IS NULL) AND (content_hash IS NULL) AND (policy_version IS NULL))`),
	check("outbox_operator_alerts_status_check", sql`status = ANY (ARRAY['open'::text, 'acknowledged'::text, 'resolved'::text])`),
]);

export const expertTelegramResidencyCallbacks = pgTable("expert_telegram_residency_callbacks", {
	tokenHash: char("token_hash", { length: 64 }).primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	telegramUserId: varchar("telegram_user_id", { length: 20 }).notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	action: text().default('start_residency_checkout').notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	consumedAt: timestamp("consumed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	checkoutStatus: text("checkout_status").default('issued').notNull(),
	checkoutUrl: varchar("checkout_url", { length: 2048 }),
	processingFence: uuid("processing_fence"),
	processingLeaseUntil: timestamp("processing_lease_until", { withTimezone: true, mode: 'string' }),
	outcomeRecordedAt: timestamp("outcome_recorded_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("expert_telegram_residency_callbacks_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(consumed_at IS NULL)`),
	index("expert_telegram_residency_callbacks_processing_lease_idx").using("btree", table.processingLeaseUntil.asc().nullsLast().op("timestamptz_ops")).where(sql`(checkout_status = 'processing'::text)`),
	index("expert_telegram_residency_callbacks_url_cleanup_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(checkout_url IS NOT NULL)`),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_telegram_residency_callbacks_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_telegram_residency_callbacks_tariff_version_id_expert_re"
		}),
	unique("expert_telegram_residency_callbacks_idempotency_unique").on(table.idempotencyKey),
	check("expert_telegram_residency_callbacks_action_check", sql`action = 'start_residency_checkout'::text`),
	check("expert_telegram_residency_callbacks_checkout_outcome_check", sql`((checkout_status = ANY (ARRAY['issued'::text, 'processing'::text])) AND (outcome_recorded_at IS NULL) AND (checkout_url IS NULL)) OR ((checkout_status = ANY (ARRAY['unavailable'::text, 'unknown'::text])) AND (outcome_recorded_at IS NOT NULL) AND (checkout_url IS NULL)) OR ((checkout_status = 'ready'::text) AND (outcome_recorded_at IS NOT NULL) AND (checkout_url IS NOT NULL) AND ((char_length((checkout_url)::text) >= 1) AND (char_length((checkout_url)::text) <= 2048)) AND ((checkout_url)::text ~* '^https://[^[:space:]]+$'::text))`),
	check("expert_telegram_residency_callbacks_checkout_state_check", sql`((checkout_status = 'issued'::text) AND (consumed_at IS NULL)) OR ((checkout_status <> 'issued'::text) AND (consumed_at IS NOT NULL))`),
	check("expert_telegram_residency_callbacks_expiry_check", sql`expires_at > created_at`),
	check("expert_telegram_residency_callbacks_processing_lease_check", sql`((checkout_status = 'processing'::text) AND (processing_fence IS NOT NULL) AND (processing_lease_until IS NOT NULL)) OR ((checkout_status <> 'processing'::text) AND (processing_fence IS NULL) AND (processing_lease_until IS NULL))`),
	check("expert_telegram_residency_callbacks_telegram_id_check", sql`(telegram_user_id)::text ~ '^[1-9][0-9]{0,19}$'::text`),
	check("expert_telegram_residency_callbacks_token_hash_check", sql`token_hash ~ '^[0-9a-f]{64}$'::text`),
]);

export const clientCatalogSnapshots = pgTable("client_catalog_snapshots", {
	requestId: uuid("request_id").primaryKey().notNull(),
	cards: jsonb().notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [clientCatalogRequests.id],
			name: "client_catalog_snapshots_request_fk"
		}).onDelete("cascade"),
	check("client_catalog_snapshots_cards_check", sql`(jsonb_typeof(cards) = 'array'::text) AND (jsonb_array_length(cards) <= 20)`),
	check("client_catalog_snapshots_expiry_check", sql`expires_at >= created_at`),
]);

export const clientCatalogTombstones = pgTable("client_catalog_tombstones", {
	requestId: uuid("request_id").primaryKey().notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	state: text().default('expired').notNull(),
}, (table) => [
	check("client_catalog_tombstones_state_check", sql`state = 'expired'::text`),
]);

export const clientCatalogErasureIndex = pgTable("client_catalog_erasure_index", {
	requestId: uuid("request_id").primaryKey().notNull(),
	subjectKey: char("subject_key", { length: 64 }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	index("client_catalog_erasure_index_subject_idx").using("btree", table.subjectKey.asc().nullsLast().op("bpchar_ops"), table.requestId.asc().nullsLast().op("bpchar_ops")),
	check("client_catalog_erasure_index_subject_check", sql`subject_key ~ '^[0-9a-f]{64}$'::text`),
]);

export const clientIdentityProofReceipts = pgTable("client_identity_proof_receipts", {
	replayDigest: text("replay_digest").primaryKey().notNull(),
	sessionTokenDigest: char("session_token_digest", { length: 71 }),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_identity_proof_receipts_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.sessionTokenDigest],
			foreignColumns: [clientSessions.tokenDigest],
			name: "client_identity_proof_receipts_session_token_digest_client_sess"
		}).onDelete("set null"),
	unique("client_identity_proof_receipts_session_digest_unique").on(table.sessionTokenDigest),
	check("client_identity_proof_receipts_expiry_check", sql`expires_at > created_at`),
	check("client_identity_proof_receipts_replay_digest_check", sql`replay_digest ~ '^hmac-sha256:v[1-9][0-9]*:[0-9a-f]{64}$'::text`),
	check("client_identity_proof_receipts_session_digest_check", sql`(session_token_digest IS NULL) OR (session_token_digest ~ '^sha256:[0-9a-f]{64}$'::text)`),
]);

export const clientSessions = pgTable("client_sessions", {
	tokenDigest: char("token_digest", { length: 71 }).primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	scope: text().notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_sessions_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_sessions_user_id_users_id_fk"
		}).onDelete("cascade"),
	check("client_sessions_lifecycle_check", sql`(expires_at > created_at) AND ((revoked_at IS NULL) OR (revoked_at >= created_at))`),
	check("client_sessions_scope_check", sql`scope = ANY (ARRAY['client_catalog:read'::text, 'client_booking:write'::text])`),
	check("client_sessions_token_digest_check", sql`token_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
]);

export const clientCatalogChoices = pgTable("client_catalog_choices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	requestId: uuid("request_id").notNull(),
	choiceDigest: char("choice_digest", { length: 71 }).notNull(),
	slotId: uuid("slot_id").notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_catalog_choices_request_expiry_idx").using("btree", table.requestId.asc().nullsLast().op("timestamptz_ops"), table.expiresAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [clientCatalogRequests.id],
			name: "client_catalog_choices_request_id_client_catalog_requests_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.slotId],
			foreignColumns: [slots.id],
			name: "client_catalog_choices_slot_id_slots_id_fk"
		}),
	unique("client_catalog_choices_choice_digest_unique").on(table.choiceDigest),
	check("client_catalog_choices_choice_digest_check", sql`choice_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("client_catalog_choices_expiry_check", sql`expires_at > created_at`),
]);

export const clientBookingReceipts = pgTable("client_booking_receipts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	choiceDigest: char("choice_digest", { length: 71 }).notNull(),
	bookingHandle: char("booking_handle", { length: 47 }).notNull(),
	reservationId: uuid("reservation_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_booking_receipts_owner_handle_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops"), table.bookingHandle.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "client_booking_receipts_reservation_id_reservations_id_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_booking_receipts_user_id_users_id_fk"
		}).onDelete("cascade"),
	unique("client_booking_receipts_user_choice_unique").on(table.userId, table.choiceDigest),
	unique("client_booking_receipts_booking_handle_unique").on(table.bookingHandle),
	unique("client_booking_receipts_reservation_unique").on(table.reservationId),
	check("client_booking_receipts_booking_handle_check", sql`booking_handle ~ '^bk1\.[A-Za-z0-9_-]{43}$'::text`),
	check("client_booking_receipts_choice_digest_check", sql`choice_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
]);

export const clientBookingErasureWork = pgTable("client_booking_erasure_work", {
	deletionJobId: uuid("deletion_job_id").primaryKey().notNull(),
	phase: text().default('cancel_active').notNull(),
	leaseToken: uuid("lease_token"),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	attemptCount: integer("attempt_count").default(0).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("client_booking_erasure_work_claim_idx").using("btree", table.phase.asc().nullsLast().op("timestamptz_ops"), table.leaseUntil.asc().nullsLast().op("text_ops"), table.updatedAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(phase = ANY (ARRAY['cancel_active'::text, 'cleanup_public'::text]))`),
	foreignKey({
			columns: [table.deletionJobId],
			foreignColumns: [privacyDeletionJobs.id],
			name: "client_booking_erasure_work_deletion_job_id_privacy_deletion_jo"
		}).onDelete("cascade"),
	check("client_booking_erasure_work_attempt_count_check", sql`(attempt_count >= 0) AND (attempt_count <= 5)`),
	check("client_booking_erasure_work_lease_check", sql`(lease_token IS NULL) = (lease_until IS NULL)`),
	check("client_booking_erasure_work_phase_check", sql`phase = ANY (ARRAY['cancel_active'::text, 'cleanup_public'::text, 'complete'::text, 'dead_letter'::text])`),
]);

export const clientCommercialPolicyControls = pgTable("client_commercial_policy_controls", {
	controlKey: text("control_key").primaryKey().notNull(),
	admissionPolicy: text("admission_policy").notNull(),
	version: integer().notNull(),
	approvalId: uuid("approval_id").notNull(),
	adminSessionIdHash: text("admin_session_id_hash").notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.adminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "client_commercial_policy_controls_admin_session_id_hash_fkey"
		}),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "client_commercial_policy_controls_approval_id_fkey"
		}),
	unique("client_commercial_policy_control_approval_unique").on(table.approvalId),
	check("client_commercial_policy_control_key", sql`control_key = 'client_access'::text`),
	check("client_commercial_policy_control_policy", sql`admission_policy = ANY (ARRAY['legacy_package_v1'::text, 'free_client_v2'::text])`),
	check("client_commercial_policy_control_version", sql`version > 0`),
]);

export const clientCommercialPolicyAssignments = pgTable("client_commercial_policy_assignments", {
	userId: uuid("user_id").primaryKey().notNull(),
	policyVersion: text("policy_version").notNull(),
	controlVersion: integer("control_version").notNull(),
	assignedAt: timestamp("assigned_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_commercial_policy_assignments_user_id_fkey"
		}).onDelete("cascade"),
	check("client_commercial_policy_assignment_policy", sql`policy_version = ANY (ARRAY['legacy_package_v1'::text, 'free_client_v2'::text])`),
	check("client_commercial_policy_assignment_version", sql`control_version > 0`),
]);

export const expertResidencyTariffVersions = pgTable("expert_residency_tariff_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	tariffKey: text("tariff_key").notNull(),
	displayName: text("display_name").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
	currency: text().default('RUB').notNull(),
	durationSeconds: integer("duration_seconds").notNull(),
	activeFrom: timestamp("active_from", { withTimezone: true, mode: 'string' }).notNull(),
	activeTo: timestamp("active_to", { withTimezone: true, mode: 'string' }).notNull(),
	approvalId: uuid("approval_id").notNull(),
	adminSessionIdHash: text("admin_session_id_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	commercialPolicyVersion: text("commercial_policy_version").default('legacy_residency_v1').notNull(),
	creditCapBps: integer("credit_cap_bps").default(5000).notNull(),
	individualServicesEnabled: boolean("individual_services_enabled").default(false).notNull(),
	groupEventLimit: integer("group_event_limit").default(0).notNull(),
	statisticsLevel: text("statistics_level").default('basic').notNull(),
	supportPriority: text("support_priority").default('standard').notNull(),
}, (table) => [
	index("expert_tariff_lookup_idx").using("btree", table.tariffKey.asc().nullsLast().op("timestamptz_ops"), table.activeFrom.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.adminSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_residency_tariff_versions_admin_session_id_hash_admin_se"
		}),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_residency_tariff_versions_approval_id_admin_approvals_id"
		}),
	unique("expert_tariff_versions_approval_unique").on(table.approvalId),
	check("expert_tariff_active_interval_valid", sql`active_to > active_from`),
	check("expert_tariff_credit_cap", sql`(credit_cap_bps >= 0) AND (credit_cap_bps <= 10000)`),
	check("expert_tariff_currency_rub", sql`currency = 'RUB'::text`),
	check("expert_tariff_duration_positive", sql`duration_seconds > 0`),
	check("expert_tariff_group_event_limit", sql`(group_event_limit >= 0) AND (group_event_limit <= 3)`),
	check("expert_tariff_policy_version", sql`commercial_policy_version = ANY (ARRAY['legacy_residency_v1'::text, 'expert_residency_v2'::text])`),
	check("expert_tariff_price_bounds", sql`(price_minor > 0) AND (price_minor <= '999999999999'::bigint)`),
	check("expert_tariff_statistics_level", sql`statistics_level = ANY (ARRAY['basic'::text, 'expanded'::text])`),
	check("expert_tariff_support_priority", sql`support_priority = ANY (ARRAY['standard'::text, 'priority'::text])`),
	check("expert_tariff_v2_combination", sql`(commercial_policy_version <> 'expert_residency_v2'::text) OR ((tariff_key = 'START'::text) AND (display_name = 'Старт'::text) AND (price_minor = 390000) AND (duration_seconds = 2592000) AND (credit_cap_bps = 3000) AND (individual_services_enabled = true) AND (group_event_limit = 0) AND (statistics_level = 'basic'::text) AND (support_priority = 'standard'::text)) OR ((tariff_key = 'BASE'::text) AND (display_name = 'База'::text) AND (price_minor = 590000) AND (duration_seconds = 2592000) AND (credit_cap_bps = 3000) AND (individual_services_enabled = true) AND (group_event_limit = 1) AND (statistics_level = 'expanded'::text) AND (support_priority = 'standard'::text)) OR ((tariff_key = 'PRO'::text) AND (display_name = 'Про'::text) AND (price_minor = 999000) AND (duration_seconds = 2592000) AND (credit_cap_bps = 3000) AND (individual_services_enabled = true) AND (group_event_limit = 3) AND (statistics_level = 'expanded'::text) AND (support_priority = 'priority'::text))`),
]);

export const dialogues = pgTable("dialogues", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	tenantKey: text("tenant_key").notNull(),
	userId: uuid("user_id").notNull(),
	provider: text().notNull(),
	botKey: text("bot_key").notNull(),
	externalChatId: text("external_chat_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	nextDeliverySequence: bigint("next_delivery_sequence", { mode: "number" }).default(0).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "dialogues_user_id_fkey"
		}),
	unique("dialogues_id_user_bot_chat_unique").on(table.id, table.userId, table.botKey, table.externalChatId),
	unique("dialogues_scope_unique").on(table.tenantKey, table.provider, table.botKey, table.externalChatId),
	check("dialogues_delivery_sequence_nonnegative", sql`next_delivery_sequence >= 0`),
]);

export const dialogueInbound = pgTable("dialogue_inbound", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	provider: text().notNull(),
	botKey: text("bot_key").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	providerUpdateId: bigint("provider_update_id", { mode: "number" }).notNull(),
	payloadHash: char("payload_hash", { length: 64 }).notNull(),
	text: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	index("dialogue_inbound_dialogue_idx").using("btree", table.dialogueId.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("uuid_ops")),
	index("dialogue_inbound_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "dialogue_inbound_dialogue_id_fkey"
		}),
	unique("dialogue_inbound_provider_bot_update_unique").on(table.provider, table.botKey, table.providerUpdateId),
	check("dialogue_inbound_expiry_check", sql`expires_at = (created_at + '30 days'::interval)`),
	check("dialogue_inbound_text_check", sql`((char_length(text) >= 1) AND (char_length(text) <= 4096)) AND (text !~ '[[:cntrl:]]'::text)`),
]);

export const expertReferralAdminExecutionResults = pgTable("expert_referral_admin_execution_results", {
	approvalId: uuid("approval_id").primaryKey().notNull(),
	secondApprovalId: uuid("second_approval_id"),
	action: text().notNull(),
	objectId: uuid("object_id").notNull(),
	payloadHash: text("payload_hash").notNull(),
	nonceHash: text("nonce_hash").notNull(),
	secondNonceHash: text("second_nonce_hash"),
	requesterSessionIdHash: text("requester_session_id_hash").notNull(),
	expectedVersion: integer("expected_version"),
	safeResult: jsonb("safe_result").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("expert_referral_admin_results_second_approval_unique").using("btree", table.secondApprovalId.asc().nullsLast().op("uuid_ops")).where(sql`(second_approval_id IS NOT NULL)`),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_admin_results_approval_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.secondApprovalId],
			foreignColumns: [adminApprovals.id],
			name: "expert_referral_admin_results_second_approval_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.requesterSessionIdHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_referral_admin_results_session_fk"
		}).onDelete("restrict"),
	check("expert_referral_admin_result_action_allowed", sql`action = ANY (ARRAY['expert_referral.batch_generate'::text, 'expert_referral.code_revoke'::text, 'expert_referral.issuance_override'::text, 'expert_referral.abuse_hold_open'::text, 'expert_referral.abuse_hold_close'::text, 'expert_residency.tariff_create'::text, 'expert_residency.tariff_retire'::text, 'expert_referral.hold_replay'::text, 'expert_referral.feature_switch'::text, 'client_commercial_policy.control_v2'::text, 'expert_residency.tariff_create_v2'::text])`),
	check("expert_referral_admin_result_exact_schema", sql`((action = 'expert_referral.code_revoke'::text) AND (safe_result ?& ARRAY['id'::text, 'status'::text]) AND ((safe_result - ARRAY['id'::text, 'status'::text]) = '{}'::jsonb) AND ((safe_result ->> 'id'::text) = (object_id)::text) AND ((safe_result ->> 'status'::text) = 'revoked'::text)) OR ((action = 'expert_referral.issuance_override'::text) AND (safe_result ? 'overrideId'::text) AND ((safe_result - 'overrideId'::text) = '{}'::jsonb) AND ((safe_result ->> 'overrideId'::text) = (object_id)::text)) OR ((action = 'expert_referral.feature_switch'::text) AND (safe_result ? 'version'::text) AND ((safe_result - 'version'::text) = '{}'::jsonb) AND (jsonb_typeof((safe_result -> 'version'::text)) = 'number'::text) AND (((safe_result ->> 'version'::text))::numeric = ((expected_version + 1))::numeric)) OR ((action = 'expert_referral.batch_generate'::text) AND (safe_result ?& ARRAY['batchId'::text, 'count'::text]) AND ((safe_result - ARRAY['batchId'::text, 'count'::text]) = '{}'::jsonb) AND (jsonb_typeof((safe_result -> 'batchId'::text)) = 'string'::text) AND (jsonb_typeof((safe_result -> 'count'::text)) = 'number'::text)) OR ((action = 'expert_residency.tariff_create_v2'::text) AND (safe_result ? 'tariffVersionId'::text) AND ((safe_result - 'tariffVersionId'::text) = '{}'::jsonb)) OR ((action = 'client_commercial_policy.control_v2'::text) AND (object_id = '00000000-0000-0000-0000-000000000041'::uuid) AND (safe_result ?& ARRAY['version'::text, 'admissionPolicy'::text]) AND ((safe_result - ARRAY['version'::text, 'admissionPolicy'::text]) = '{}'::jsonb) AND (jsonb_typeof((safe_result -> 'version'::text)) = 'number'::text) AND (((safe_result ->> 'version'::text))::numeric > (0)::numeric) AND ((((safe_result ->> 'version'::text))::numeric % (1)::numeric) = (0)::numeric) AND (jsonb_typeof((safe_result -> 'admissionPolicy'::text)) = 'string'::text) AND ((safe_result ->> 'admissionPolicy'::text) = ANY (ARRAY['legacy_package_v1'::text, 'free_client_v2'::text])))`),
	check("expert_referral_admin_result_expected_version", sql`CHECK (COALESCE((((action = ANY (ARRAY['expert_referral.feature_switch'::text, 'client_commercial_policy.control_v2'::text])) AND (expected_version IS NOT NULL) AND ((expected_version >= 0) AND (expected_version <= 2147483646))) OR ((action <> ALL (ARRAY['expert_referral.feature_switch'::text, 'client_commercial_policy.control_v2'::text])) AND (expected_version IS NULL))), false`),
	check("expert_referral_admin_result_no_secrets", sql`(NOT (safe_result ?| ARRAY['codes'::text, 'plaintext'::text, 'digest'::text, 'hash'::text, 'nonce'::text])) AND ((safe_result)::text !~ '"(codes|plaintext|digest|hash|nonce)"[[:space:]]*:'::text)`),
	check("expert_referral_admin_result_nonce_hash_format", sql`nonce_hash ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_referral_admin_result_object_only", sql`jsonb_typeof(safe_result) = 'object'::text`),
	check("expert_referral_admin_result_payload_hash_format", sql`payload_hash ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_referral_admin_result_second_binding", sql`CHECK (COALESCE((((action <> 'expert_referral.issuance_override'::text) AND (second_approval_id IS NULL) AND (second_nonce_hash IS NULL)) OR ((action = 'expert_referral.issuance_override'::text) AND (second_approval_id IS NOT NULL) AND (second_nonce_hash IS NOT NULL) AND (second_nonce_hash ~ '^sha256:[0-9a-f]{64}$'::text) AND (second_approval_id <> approval_id))), false`),
]);

export const expertReferralRewardMaturities = pgTable("expert_referral_reward_maturities", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	firstSettlementId: uuid("first_settlement_id").notNull(),
	referralId: uuid("referral_id").notNull(),
	qualifyingOrderId: uuid("qualifying_order_id").notNull(),
	qualifyingPaymentAttemptId: uuid("qualifying_payment_attempt_id").notNull(),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	inviteeExpertId: uuid("invitee_expert_id").notNull(),
	policyVersion: text("policy_version").default('expert_referral_v2_30d').notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).default(100000).notNull(),
	settledAt: timestamp("settled_at", { withTimezone: true, mode: 'string' }).notNull(),
	maturesAt: timestamp("matures_at", { withTimezone: true, mode: 'string' }).notNull(),
	status: expertReferralMaturityStatus().default('pending').notNull(),
	grantedAt: timestamp("granted_at", { withTimezone: true, mode: 'string' }),
	cancelledAt: timestamp("cancelled_at", { withTimezone: true, mode: 'string' }),
	terminalReason: text("terminal_reason"),
	idempotencyKey: text("idempotency_key").notNull(),
	leaseToken: uuid("lease_token"),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	attemptCount: integer("attempt_count").default(0).notNull(),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	reasonCode: text("reason_code"),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_referral_maturities_due_idx").using("btree", table.maturesAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(status = 'pending'::expert_referral_maturity_status)`),
	uniqueIndex("expert_referral_maturities_idempotency_unique").using("btree", table.idempotencyKey.asc().nullsLast().op("text_ops")),
	uniqueIndex("expert_referral_maturities_order_unique").using("btree", table.qualifyingOrderId.asc().nullsLast().op("uuid_ops")),
	uniqueIndex("expert_referral_maturities_payment_unique").using("btree", table.qualifyingPaymentAttemptId.asc().nullsLast().op("uuid_ops")),
	uniqueIndex("expert_referral_maturities_referral_unique").using("btree", table.referralId.asc().nullsLast().op("uuid_ops")),
	uniqueIndex("expert_referral_maturities_settlement_unique").using("btree", table.firstSettlementId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.firstSettlementId, table.referralId, table.qualifyingOrderId, table.qualifyingPaymentAttemptId],
			foreignColumns: [expertFirstResidencySettlements.id, expertFirstResidencySettlements.qualifyingOrderId, expertFirstResidencySettlements.qualifyingPaymentAttemptId, expertFirstResidencySettlements.referralId],
			name: "expert_referral_maturity_settlement_fk"
		}),
	foreignKey({
			columns: [table.inviteeExpertId],
			foreignColumns: [experts.id],
			name: "expert_referral_reward_maturities_invitee_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.inviterExpertId],
			foreignColumns: [experts.id],
			name: "expert_referral_reward_maturities_inviter_expert_id_fkey"
		}),
	check("expert_referral_maturity_attempt_bounded", sql`(attempt_count >= 0) AND (attempt_count <= 2147483647)`),
	check("expert_referral_maturity_idempotency_nonempty", sql`idempotency_key = ('expert-referral-maturity:v1:'::text || (first_settlement_id)::text)`),
	check("expert_referral_maturity_policy", sql`(policy_version = 'expert_referral_v2_30d'::text) AND (amount_minor = 100000)`),
	check("expert_referral_maturity_settled_clock", sql`matures_at = (settled_at + '30 days'::interval)`),
	check("expert_referral_maturity_terminal_state", sql`((status = 'pending'::expert_referral_maturity_status) AND (granted_at IS NULL) AND (cancelled_at IS NULL) AND (terminal_reason IS NULL)) OR ((status = 'granted'::expert_referral_maturity_status) AND (granted_at IS NOT NULL) AND (cancelled_at IS NULL) AND (terminal_reason IS NULL) AND (lease_token IS NULL) AND (lease_until IS NULL)) OR ((status = 'cancelled'::expert_referral_maturity_status) AND (granted_at IS NULL) AND (cancelled_at IS NOT NULL) AND (terminal_reason IS NOT NULL) AND (terminal_reason = ANY (ARRAY['terminating_provider_reversal'::text, 'eligibility_lost'::text, 'feature_disabled'::text])) AND (lease_token IS NULL) AND (lease_until IS NULL))`),
]);

export const dialogueRouteDecisions = pgTable("dialogue_route_decisions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	inboundId: uuid("inbound_id").notNull(),
	routeVersion: integer("route_version").default(1).notNull(),
	route: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.inboundId],
			foreignColumns: [dialogueInbound.id],
			name: "dialogue_route_decisions_inbound_id_fkey"
		}),
	unique("dialogue_route_inbound_unique").on(table.inboundId),
	check("dialogue_route_check", sql`route = ANY (ARRAY['deterministic'::text, 'complex_dialogue'::text])`),
	check("dialogue_route_version_check", sql`route_version > 0`),
]);

export const expertResidencyOrders = pgTable("expert_residency_orders", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	snapshotDisplayName: text("snapshot_display_name").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
	currency: text().default('RUB').notNull(),
	durationSeconds: integer("duration_seconds").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	creditMinor: bigint("credit_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	cashMinor: bigint("cash_minor", { mode: "number" }).notNull(),
	paymentDeadline: timestamp("payment_deadline", { withTimezone: true, mode: 'string' }).notNull(),
	providerPaymentId: text("provider_payment_id"),
	status: expertResidencyOrderStatus().default('quoted').notNull(),
	settledAt: timestamp("settled_at", { withTimezone: true, mode: 'string' }),
	residencyStartsAt: timestamp("residency_starts_at", { withTimezone: true, mode: 'string' }),
	residencyEndsAt: timestamp("residency_ends_at", { withTimezone: true, mode: 'string' }),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	providerDeadline: timestamp("provider_deadline", { withTimezone: true, mode: 'string' }).notNull(),
	commercialPolicyVersion: text("commercial_policy_version").default('legacy_residency_v1').notNull(),
	creditCapBps: integer("credit_cap_bps").default(5000).notNull(),
	individualServicesEnabled: boolean("individual_services_enabled").default(false).notNull(),
	groupEventLimit: integer("group_event_limit").default(0).notNull(),
	statisticsLevel: text("statistics_level").default('basic').notNull(),
	supportPriority: text("support_priority").default('standard').notNull(),
	campaignQuoteId: uuid("campaign_quote_id"),
	campaignTermMonths: integer("campaign_term_months"),
}, (table) => [
	uniqueIndex("expert_orders_provider_payment_unique").using("btree", table.providerPaymentId.asc().nullsLast().op("text_ops")).where(sql`(provider_payment_id IS NOT NULL)`),
	index("expert_orders_status_deadline_idx").using("btree", table.status.asc().nullsLast().op("timestamptz_ops"), table.paymentDeadline.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.campaignQuoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_campaign_order_quote_fk"
		}),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_residency_orders_expert_id_experts_id_fk"
		}),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_residency_orders_tariff_version_id_expert_residency_tari"
		}),
	unique("expert_orders_id_expert_unique").on(table.id, table.expertId),
	unique("payer_receipt_order_quote_unique").on(table.id, table.campaignQuoteId),
	unique("expert_orders_expert_idempotency_unique").on(table.expertId, table.idempotencyKey),
	unique("expert_campaign_order_quote_unique").on(table.campaignQuoteId),
	check("expert_campaign_order_binding", sql`((commercial_policy_version <> 'expert_campaign_v1'::text) AND (campaign_quote_id IS NULL) AND (campaign_term_months IS NULL)) OR ((commercial_policy_version = 'expert_campaign_v1'::text) AND (campaign_quote_id IS NOT NULL) AND (campaign_term_months IS NOT NULL) AND (campaign_term_months = ANY (ARRAY[1, 3])) AND (duration_seconds = (campaign_term_months * 2592000)) AND (credit_cap_bps = 3000))`),
	check("expert_order_cash_credit_conservation", sql`(cash_minor + credit_minor) = price_minor`),
	check("expert_order_cash_remainder", sql`cash_minor = (price_minor - credit_minor)`),
	check("expert_order_credit_cap", sql`((credit_cap_bps >= 0) AND (credit_cap_bps <= 10000)) AND ((credit_minor * 10000) <= (price_minor * credit_cap_bps))`),
	check("expert_order_currency_rub", sql`currency = 'RUB'::text`),
	check("expert_order_deadline_after_creation", sql`payment_deadline > created_at`),
	check("expert_order_deadline_not_after_provider", sql`payment_deadline <= provider_deadline`),
	check("expert_order_duration_positive", sql`duration_seconds > 0`),
	check("expert_order_group_event_limit", sql`(group_event_limit >= 0) AND (group_event_limit <= 3)`),
	check("expert_order_money_bounds", sql`(price_minor > 0) AND (price_minor <= '999999999999'::bigint) AND (credit_minor >= 0) AND (credit_minor <= '999999999999'::bigint) AND (cash_minor >= 0) AND (cash_minor <= '999999999999'::bigint)`),
	check("expert_order_policy_version", sql`commercial_policy_version = ANY (ARRAY['legacy_residency_v1'::text, 'expert_residency_v2'::text, 'expert_campaign_v1'::text])`),
	check("expert_order_settlement_interval", sql`((settled_at IS NULL) AND (residency_starts_at IS NULL) AND (residency_ends_at IS NULL)) OR ((settled_at IS NOT NULL) AND (residency_starts_at IS NOT NULL) AND (residency_ends_at IS NOT NULL) AND (residency_starts_at >= settled_at) AND (residency_ends_at = (residency_starts_at + make_interval(secs => (duration_seconds)::double precision))))`),
	check("expert_order_statistics_level", sql`statistics_level = ANY (ARRAY['basic'::text, 'expanded'::text])`),
	check("expert_order_support_priority", sql`support_priority = ANY (ARRAY['standard'::text, 'priority'::text])`),
	check("expert_order_v2_cap", sql`(commercial_policy_version <> 'expert_residency_v2'::text) OR (credit_cap_bps = 3000)`),
	check("expert_order_v2_duration", sql`(commercial_policy_version <> 'expert_residency_v2'::text) OR (duration_seconds = 2592000)`),
	check("expert_order_v2_price", sql`(commercial_policy_version <> 'expert_residency_v2'::text) OR (price_minor = ANY (ARRAY[(390000)::bigint, (590000)::bigint, (999000)::bigint]))`),
]);

export const selartiResponseProposals = pgTable("selarti_response_proposals", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	requestId: text("request_id").notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	tenantKey: text("tenant_key").notNull(),
	requestPayloadHash: char("request_payload_hash", { length: 64 }).notNull(),
	responsePayloadHash: char("response_payload_hash", { length: 64 }).notNull(),
	text: text(),
	acceptedAt: timestamp("accepted_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	redactedAt: timestamp("redacted_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("selarti_response_proposals_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("timestamptz_ops")).where(sql`(redacted_at IS NULL)`),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "selarti_response_proposals_dialogue_id_fkey"
		}),
	unique("selarti_response_proposals_request_id_key").on(table.requestId),
	check("selarti_response_proposals_expiry_check", sql`expires_at = (accepted_at + '30 days'::interval)`),
	check("selarti_response_proposals_hash_check", sql`(request_payload_hash ~ '^[0-9a-f]{64}$'::text) AND (response_payload_hash ~ '^[0-9a-f]{64}$'::text)`),
	check("selarti_response_proposals_redaction_check", sql`(text IS NULL) = (redacted_at IS NOT NULL)`),
	check("selarti_response_proposals_text_check", sql`(text IS NULL) OR (((char_length(text) >= 1) AND (char_length(text) <= 4096)) AND (text !~ '[[:cntrl:]]'::text))`),
]);

export const dialogueDeliveries = pgTable("dialogue_deliveries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	dialogueSequence: bigint("dialogue_sequence", { mode: "number" }).notNull(),
	source: text().notNull(),
	sourceId: text("source_id").notNull(),
	outboxId: uuid("outbox_id").notNull(),
	payloadHash: char("payload_hash", { length: 64 }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("dialogue_deliveries_order_idx").using("btree", table.dialogueId.asc().nullsLast().op("int8_ops"), table.dialogueSequence.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "dialogue_deliveries_dialogue_id_fkey"
		}),
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "dialogue_deliveries_outbox_id_fkey"
		}),
	unique("dialogue_deliveries_dialogue_sequence_unique").on(table.dialogueId, table.dialogueSequence),
	unique("dialogue_deliveries_source_unique").on(table.source, table.sourceId),
	unique("dialogue_deliveries_outbox_id_key").on(table.outboxId),
	check("dialogue_deliveries_hash_check", sql`payload_hash ~ '^[0-9a-f]{64}$'::text`),
	check("dialogue_deliveries_sequence_positive", sql`dialogue_sequence > 0`),
	check("dialogue_deliveries_source_check", sql`source = ANY (ARRAY['deterministic'::text, 'selarti'::text])`),
]);

export const dialogueInboundTombstones = pgTable("dialogue_inbound_tombstones", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	provider: text().notNull(),
	botKey: text("bot_key").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	providerUpdateId: bigint("provider_update_id", { mode: "number" }).notNull(),
	payloadHash: char("payload_hash", { length: 64 }).notNull(),
	route: text().notNull(),
	occurredAt: timestamp("occurred_at", { withTimezone: true, mode: 'string' }).notNull(),
	purgedAt: timestamp("purged_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "dialogue_inbound_tombstones_dialogue_id_fkey"
		}),
	unique("dialogue_inbound_tombstones_scope_unique").on(table.provider, table.botKey, table.providerUpdateId),
	check("dialogue_inbound_tombstones_hash_check", sql`payload_hash ~ '^[0-9a-f]{64}$'::text`),
	check("dialogue_inbound_tombstones_route_check", sql`route = ANY (ARRAY['deterministic'::text, 'complex_dialogue'::text])`),
]);

export const selartiBudgetPolicies = pgTable("selarti_budget_policies", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	version: integer().notNull(),
	status: text().notNull(),
	effectiveFrom: timestamp("effective_from", { withTimezone: true, mode: 'string' }).notNull(),
	effectiveTo: timestamp("effective_to", { withTimezone: true, mode: 'string' }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	globalCapRubMinor: bigint("global_cap_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	globalWarningRubMinor: bigint("global_warning_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	globalSoftRubMinor: bigint("global_soft_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	perUserWarningRubMinor: bigint("per_user_warning_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	perUserSoftRubMinor: bigint("per_user_soft_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	perUserHardRubMinor: bigint("per_user_hard_rub_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	officialUsdRubQuoteMicros: bigint("official_usd_rub_quote_micros", { mode: "number" }).notNull(),
	selartiUpliftBps: integer("selarti_uplift_bps").default(1000).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	usdMicrosPerRequest: bigint("usd_micros_per_request", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	usdMicrosPerUnit: bigint("usd_micros_per_unit", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	worstCaseBillableUnits: bigint("worst_case_billable_units", { mode: "number" }).notNull(),
	rateVersion: text("rate_version").notNull(),
	modelVersion: text("model_version").notNull(),
	stressInflationBps: integer("stress_inflation_bps").default(6000).notNull(),
	approvalId: uuid("approval_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("selarti_budget_policy_one_active_idx").using("btree", table.status.asc().nullsLast().op("text_ops")).where(sql`((status = 'approved'::text) AND (effective_to IS NULL))`),
	foreignKey({
			columns: [table.approvalId],
			foreignColumns: [adminApprovals.id],
			name: "selarti_budget_policies_approval_id_fkey"
		}),
	unique("selarti_budget_policy_id_version_unique").on(table.id, table.version),
	unique("selarti_budget_policies_version_key").on(table.version),
	unique("selarti_budget_policies_approval_id_key").on(table.approvalId),
	check("selarti_budget_policy_cost_check", sql`(official_usd_rub_quote_micros > 0) AND (official_usd_rub_quote_micros <= '999999999999'::bigint) AND (selarti_uplift_bps = 1000) AND (usd_micros_per_request >= 0) AND (usd_micros_per_request <= '999999999999'::bigint) AND (usd_micros_per_unit >= 0) AND (usd_micros_per_unit <= '999999999999'::bigint) AND (worst_case_billable_units > 0) AND (worst_case_billable_units <= 1000000) AND (stress_inflation_bps = 6000) AND (ceil((((((usd_micros_per_request)::numeric + ((usd_micros_per_unit)::numeric * (worst_case_billable_units)::numeric)) * ceil((((official_usd_rub_quote_micros)::numeric * ((10000 + selarti_uplift_bps))::numeric) / (10000)::numeric))) * (100)::numeric) / ('1000000000000'::bigint)::numeric)) > (0)::numeric) AND (ceil((((((usd_micros_per_request)::numeric + ((usd_micros_per_unit)::numeric * (worst_case_billable_units)::numeric)) * ceil((((official_usd_rub_quote_micros)::numeric * ((10000 + selarti_uplift_bps))::numeric) / (10000)::numeric))) * (100)::numeric) / ('1000000000000'::bigint)::numeric)) <= ('999999999999'::bigint)::numeric)`),
	check("selarti_budget_policy_status_check", sql`status = ANY (ARRAY['approved'::text, 'retired'::text])`),
	check("selarti_budget_policy_threshold_check", sql`(global_cap_rub_minor > 0) AND (global_cap_rub_minor <= '999999999999'::bigint) AND (global_warning_rub_minor >= 0) AND (global_warning_rub_minor <= '999999999999'::bigint) AND (global_warning_rub_minor <= global_soft_rub_minor) AND (global_soft_rub_minor <= '999999999999'::bigint) AND (global_soft_rub_minor <= global_cap_rub_minor) AND (per_user_warning_rub_minor >= 0) AND (per_user_warning_rub_minor <= '999999999999'::bigint) AND (per_user_warning_rub_minor <= per_user_soft_rub_minor) AND (per_user_soft_rub_minor <= '999999999999'::bigint) AND (per_user_soft_rub_minor <= per_user_hard_rub_minor) AND (per_user_hard_rub_minor <= '999999999999'::bigint) AND (per_user_hard_rub_minor <= global_cap_rub_minor)`),
	check("selarti_budget_policy_window_check", sql`(effective_to IS NULL) OR (effective_to > effective_from)`),
]);

export const selartiCostReservations = pgTable("selarti_cost_reservations", {
	requestId: text("request_id").primaryKey().notNull(),
	payloadHash: char("payload_hash", { length: 64 }).notNull(),
	policyId: uuid("policy_id").notNull(),
	policyVersion: integer("policy_version").notNull(),
	userId: uuid("user_id").notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	periodStart: date("period_start").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	officialUsdRubQuoteMicros: bigint("official_usd_rub_quote_micros", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	effectiveUsdRubQuoteMicros: bigint("effective_usd_rub_quote_micros", { mode: "number" }).notNull(),
	selartiUpliftBps: integer("selarti_uplift_bps").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	usdMicrosPerRequest: bigint("usd_micros_per_request", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	usdMicrosPerUnit: bigint("usd_micros_per_unit", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	worstCaseBillableUnits: bigint("worst_case_billable_units", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	worstCaseUsdMicros: bigint("worst_case_usd_micros", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	reservedRubMinor: bigint("reserved_rub_minor", { mode: "number" }).notNull(),
	rateVersion: text("rate_version").notNull(),
	modelVersion: text("model_version").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("selarti_cost_reservations_period_idx").using("btree", table.periodStart.asc().nullsLast().op("date_ops"), table.userId.asc().nullsLast().op("date_ops")),
	foreignKey({
			columns: [table.policyId, table.policyVersion],
			foreignColumns: [selartiBudgetPolicies.id, selartiBudgetPolicies.version],
			name: "selarti_cost_reservation_policy_fk"
		}),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "selarti_cost_reservations_dialogue_id_fkey"
		}),
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [selartiBudgetPolicies.id],
			name: "selarti_cost_reservations_policy_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "selarti_cost_reservations_user_id_fkey"
		}),
	check("selarti_cost_reservation_amount_check", sql`(reserved_rub_minor > 0) AND (worst_case_usd_micros > 0)`),
	check("selarti_cost_reservation_hash_check", sql`payload_hash ~ '^[0-9a-f]{64}$'::text`),
]);

export const selartiActualUsageFacts = pgTable("selarti_actual_usage_facts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	factId: text("fact_id").notNull(),
	requestId: text("request_id").notNull(),
	payloadHash: char("payload_hash", { length: 64 }).notNull(),
	outcome: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	actualUsdMicros: bigint("actual_usd_micros", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	actualRubMinor: bigint("actual_rub_minor", { mode: "number" }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("selarti_actual_usage_request_idx").using("btree", table.requestId.asc().nullsLast().op("text_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("text_ops")),
	uniqueIndex("selarti_actual_usage_terminal_unique").using("btree", table.requestId.asc().nullsLast().op("text_ops")).where(sql`(outcome = ANY (ARRAY['not_applied'::text, 'applied'::text]))`),
	uniqueIndex("selarti_actual_usage_unknown_unique").using("btree", table.requestId.asc().nullsLast().op("text_ops")).where(sql`(outcome = 'unknown'::text)`),
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [selartiCostReservations.requestId],
			name: "selarti_actual_usage_facts_request_id_fkey"
		}),
	unique("selarti_actual_usage_facts_fact_id_key").on(table.factId),
	check("selarti_actual_usage_amount_check", sql`((outcome = 'applied'::text) AND (actual_usd_micros IS NOT NULL) AND (actual_usd_micros >= 0) AND (actual_rub_minor IS NOT NULL) AND (actual_rub_minor >= 0)) OR ((outcome <> 'applied'::text) AND (actual_usd_micros IS NULL) AND (actual_rub_minor IS NULL))`),
	check("selarti_actual_usage_hash_check", sql`payload_hash ~ '^[0-9a-f]{64}$'::text`),
	check("selarti_actual_usage_outcome_check", sql`outcome = ANY (ARRAY['unknown'::text, 'not_applied'::text, 'applied'::text])`),
]);

export const selartiCostAdjustments = pgTable("selarti_cost_adjustments", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	requestId: text("request_id").notNull(),
	kind: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountRubMinor: bigint("amount_rub_minor", { mode: "number" }).notNull(),
	factId: text("fact_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [selartiCostReservations.requestId],
			name: "selarti_cost_adjustments_request_id_fkey"
		}),
	unique("selarti_cost_adjustment_unique").on(table.requestId, table.kind),
	check("selarti_cost_adjustment_amount_check", sql`amount_rub_minor >= 0`),
	check("selarti_cost_adjustment_kind_check", sql`kind = ANY (ARRAY['released'::text, 'consumed'::text, 'unused_released'::text, 'overrun'::text])`),
]);

export const selartiBudgetAlerts = pgTable("selarti_budget_alerts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	requestId: text("request_id").notNull(),
	policyVersion: integer("policy_version").notNull(),
	outcome: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountRubMinor: bigint("amount_rub_minor", { mode: "number" }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("selarti_budget_alerts_created_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	unique("selarti_budget_alert_unique").on(table.requestId, table.outcome),
	check("selarti_budget_alert_amount_check", sql`amount_rub_minor >= 0`),
	check("selarti_budget_alert_outcome_check", sql`outcome = ANY (ARRAY['warning'::text, 'soft_stop'::text, 'hard_stop'::text, 'overrun'::text, 'unknown'::text])`),
]);

export const commercialParticipants = pgTable("commercial_participants", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	participantKind: text("participant_kind"),
	onboardingState: text("onboarding_state").default('started').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("commercial_participants_pending_user_unique").using("btree", table.userId.asc().nullsLast().op("uuid_ops")).where(sql`(participant_kind IS NULL)`),
	index("commercial_participants_user_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops"), table.createdAt.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "commercial_participants_user_id_fkey"
		}).onDelete("cascade"),
	unique("commercial_participants_id_kind_unique").on(table.id, table.participantKind),
	unique("commercial_participants_user_kind_unique").on(table.userId, table.participantKind),
	check("commercial_participants_kind_check", sql`participant_kind = ANY (ARRAY['EXPERT'::text, 'CENTER'::text, 'ORGANIZER'::text])`),
	check("commercial_participants_onboarding_state_check", sql`onboarding_state = ANY (ARRAY['started'::text, 'kind_selected'::text, 'profile_incomplete'::text, 'profile_ready'::text, 'offer_available'::text])`),
	check("commercial_participants_state_kind_coherence_check", sql`((onboarding_state = 'started'::text) AND (participant_kind IS NULL)) OR ((onboarding_state <> 'started'::text) AND (participant_kind IS NOT NULL))`),
]);

export const organizationProfiles = pgTable("organization_profiles", {
	participantId: uuid("participant_id").primaryKey().notNull(),
	participantKind: text("participant_kind").notNull(),
	legalName: text("legal_name").notNull(),
	city: text().notNull(),
	onlineOnly: boolean("online_only").default(false).notNull(),
	cityMillionPlus: boolean("city_million_plus").default(false).notNull(),
	verificationState: text("verification_state").default('unverified').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.participantId, table.participantKind],
			foreignColumns: [commercialParticipants.id, commercialParticipants.participantKind],
			name: "organization_profiles_participant_fk"
		}).onDelete("cascade"),
	check("organization_profiles_city_check", sql`(char_length(city) >= 1) AND (char_length(city) <= 200)`),
	check("organization_profiles_kind_check", sql`participant_kind = ANY (ARRAY['CENTER'::text, 'ORGANIZER'::text])`),
	check("organization_profiles_legal_name_check", sql`(char_length(legal_name) >= 1) AND (char_length(legal_name) <= 300)`),
	check("organization_profiles_verification_check", sql`verification_state = ANY (ARRAY['unverified'::text, 'pending'::text, 'verified'::text, 'rejected'::text])`),
]);

export const partnerTariffPolicyVersions = pgTable("partner_tariff_policy_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	policyVersionId: text("policy_version_id").notNull(),
	policyVersion: integer("policy_version").notNull(),
	partnerKind: text("partner_kind").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	standardPriceMinor: bigint("standard_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	referredSixPriceMinor: bigint("referred_six_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	referredTenPriceMinor: bigint("referred_ten_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	onlineOnlySurchargeMinor: bigint("online_only_surcharge_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	cityMillionPlusSurchargeMinor: bigint("city_million_plus_surcharge_minor", { mode: "number" }).notNull(),
	currency: text().notNull(),
	durationSeconds: integer("duration_seconds").notNull(),
	eventEntitlements: jsonb("event_entitlements").notNull(),
	residentCommissionBps: integer("resident_commission_bps").notNull(),
	nonresidentCommissionBps: integer("nonresident_commission_bps").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	nonresidentCardFeeMinor: bigint("nonresident_card_fee_minor", { mode: "number" }).notNull(),
	status: text().default('draft').notNull(),
	effectiveFrom: timestamp("effective_from", { withTimezone: true, mode: 'string' }).notNull(),
	effectiveTo: timestamp("effective_to", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("partner_tariff_policy_versions_active_idx").using("btree", table.partnerKind.asc().nullsLast().op("text_ops")).where(sql`((status = 'approved'::text) AND (effective_to IS NULL))`),
	index("partner_tariff_policy_versions_effective_idx").using("btree", table.partnerKind.asc().nullsLast().op("timestamptz_ops"), table.effectiveFrom.asc().nullsLast().op("timestamptz_ops"), table.effectiveTo.asc().nullsLast().op("timestamptz_ops")),
	unique("partner_tariff_policy_versions_id_version_unique").on(table.policyVersionId, table.policyVersion),
	unique("partner_tariff_policy_versions_kind_identity_unique").on(table.policyVersionId, table.partnerKind),
	check("partner_tariff_policy_versions_currency_check", sql`currency = 'RUB'::text`),
	check("partner_tariff_policy_versions_entitlements_check", sql`((partner_kind = 'CENTER'::text) AND (event_entitlements = '{"bands": [{"count": 10, "capacity": 30}]}'::jsonb)) OR ((partner_kind = 'ORGANIZER'::text) AND (event_entitlements = '{"bands": [{"count": 5, "capacity": 50}, {"count": 3, "capacity": 100}, {"count": 1, "capacity": 500}]}'::jsonb))`),
	check("partner_tariff_policy_versions_id_check", sql`(char_length(policy_version_id) >= 1) AND (char_length(policy_version_id) <= 128)`),
	check("partner_tariff_policy_versions_kind_check", sql`partner_kind = ANY (ARRAY['CENTER'::text, 'ORGANIZER'::text])`),
	check("partner_tariff_policy_versions_money_check", sql`(standard_price_minor > 0) AND (referred_six_price_minor > 0) AND (referred_ten_price_minor > 0) AND (referred_ten_price_minor <= referred_six_price_minor) AND (referred_six_price_minor <= standard_price_minor) AND (online_only_surcharge_minor = 300000) AND (city_million_plus_surcharge_minor = 500000) AND (duration_seconds = 2592000) AND (resident_commission_bps = 1000) AND (nonresident_commission_bps = 1500) AND (nonresident_card_fee_minor = 450000)`),
	check("partner_tariff_policy_versions_status_check", sql`status = ANY (ARRAY['draft'::text, 'approved'::text, 'retired'::text])`),
	check("partner_tariff_policy_versions_version_check", sql`policy_version > 0`),
	check("partner_tariff_policy_versions_window_check", sql`(effective_to IS NULL) OR (effective_to > effective_from)`),
]);

export const partnerShadowQuotes = pgTable("partner_shadow_quotes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	participantId: uuid("participant_id").notNull(),
	policyId: uuid("policy_id").notNull(),
	policyVersionId: text("policy_version_id").notNull(),
	policyVersion: integer("policy_version").notNull(),
	partnerKind: text("partner_kind").notNull(),
	qualifiedExpertCount: integer("qualified_expert_count").notNull(),
	tier: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	basePriceMinor: bigint("base_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	onlineOnlySurchargeMinor: bigint("online_only_surcharge_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	cityMillionPlusSurchargeMinor: bigint("city_million_plus_surcharge_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	finalPriceMinor: bigint("final_price_minor", { mode: "number" }).notNull(),
	currency: text().notNull(),
	durationSeconds: integer("duration_seconds").notNull(),
	eventEntitlements: jsonb("event_entitlements").notNull(),
	residentCommissionBps: integer("resident_commission_bps").notNull(),
	nonresidentCommissionBps: integer("nonresident_commission_bps").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	nonresidentCardFeeMinor: bigint("nonresident_card_fee_minor", { mode: "number" }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("partner_shadow_quotes_participant_idx").using("btree", table.participantId.asc().nullsLast().op("uuid_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.participantId],
			foreignColumns: [commercialParticipants.id],
			name: "partner_shadow_quotes_participant_id_fkey"
		}),
	foreignKey({
			columns: [table.participantId, table.partnerKind],
			foreignColumns: [commercialParticipants.id, commercialParticipants.participantKind],
			name: "partner_shadow_quotes_participant_kind_fk"
		}),
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [partnerTariffPolicyVersions.id],
			name: "partner_shadow_quotes_policy_id_fkey"
		}),
	foreignKey({
			columns: [table.policyVersionId, table.partnerKind],
			foreignColumns: [partnerTariffPolicyVersions.policyVersionId, partnerTariffPolicyVersions.partnerKind],
			name: "partner_shadow_quotes_policy_kind_fk"
		}),
	check("partner_shadow_quotes_arithmetic_check", sql`((base_price_minor + online_only_surcharge_minor) + city_million_plus_surcharge_minor) = final_price_minor`),
	check("partner_shadow_quotes_count_check", sql`qualified_expert_count >= 0`),
	check("partner_shadow_quotes_currency_check", sql`(currency = 'RUB'::text) AND (duration_seconds = 2592000)`),
	check("partner_shadow_quotes_entitlements_check", sql`((partner_kind = 'CENTER'::text) AND (event_entitlements = '{"bands": [{"count": 10, "capacity": 30}]}'::jsonb)) OR ((partner_kind = 'ORGANIZER'::text) AND (event_entitlements = '{"bands": [{"count": 5, "capacity": 50}, {"count": 3, "capacity": 100}, {"count": 1, "capacity": 500}]}'::jsonb))`),
	check("partner_shadow_quotes_kind_check", sql`partner_kind = ANY (ARRAY['CENTER'::text, 'ORGANIZER'::text])`),
	check("partner_shadow_quotes_money_check", sql`(base_price_minor > 0) AND (online_only_surcharge_minor >= 0) AND (city_million_plus_surcharge_minor >= 0) AND (final_price_minor > 0) AND (resident_commission_bps = 1000) AND (nonresident_commission_bps = 1500) AND (nonresident_card_fee_minor = 450000)`),
	check("partner_shadow_quotes_tier_check", sql`tier = ANY (ARRAY['STANDARD'::text, 'REFERRED_6_9'::text, 'REFERRED_10_PLUS'::text])`),
]);

export const partnerCommandReceipts = pgTable("partner_command_receipts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	command: text().notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	payloadHash: text("payload_hash").notNull(),
	result: jsonb().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "partner_command_receipts_user_id_fkey"
		}).onDelete("cascade"),
	unique("partner_command_receipts_idempotency_unique").on(table.userId, table.idempotencyKey),
	check("partner_command_receipts_command_check", sql`command = ANY (ARRAY['partner_onboarding'::text, 'partner_quote'::text])`),
	check("partner_command_receipts_hash_check", sql`payload_hash ~ '^[0-9a-f]{64}$'::text`),
]);

export const testExpertPromptAssets = pgTable("test_expert_prompt_assets", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	assetKey: text("asset_key").notNull(),
	version: integer().notNull(),
	sha256: char({ length: 64 }).notNull(),
	sourcePath: text("source_path").notNull(),
	status: text().default('inactive').notNull(),
	officialContractEvidence: text("official_contract_evidence"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("test_expert_prompt_id_version_unique").on(table.id, table.version),
	unique("test_expert_prompt_key_version_unique").on(table.assetKey, table.version),
	check("test_expert_prompt_activation_check", sql`(status <> 'approved'::text) OR ((official_contract_evidence IS NOT NULL) AND ((char_length(official_contract_evidence) >= 1) AND (char_length(official_contract_evidence) <= 512)))`),
	check("test_expert_prompt_digest_check", sql`sha256 ~ '^[0-9a-f]{64}$'::text`),
	check("test_expert_prompt_key_bounded", sql`(char_length(asset_key) >= 1) AND (char_length(asset_key) <= 128)`),
	check("test_expert_prompt_source_bounded", sql`((char_length(source_path) >= 1) AND (char_length(source_path) <= 512)) AND (source_path !~ '[[:cntrl:]]'::text)`),
	check("test_expert_prompt_status_check", sql`status = ANY (ARRAY['inactive'::text, 'approved'::text, 'retired'::text])`),
	check("test_expert_prompt_version_positive", sql`version > 0`),
]);

export const testExpertCampaignVersions = pgTable("test_expert_campaign_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	code: text().notNull(),
	version: integer().notNull(),
	status: text().default('inactive').notNull(),
	capUnits: integer("cap_units").default(100).notNull(),
	providerCallsPerMessage: integer("provider_calls_per_message").default(1).notNull(),
	promptAssetId: uuid("prompt_asset_id"),
	promptAssetVersion: integer("prompt_asset_version"),
	effectiveFrom: timestamp("effective_from", { withTimezone: true, mode: 'string' }),
	effectiveTo: timestamp("effective_to", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("test_expert_campaign_one_active_idx").using("btree", table.code.asc().nullsLast().op("text_ops")).where(sql`(status = 'active'::text)`),
	foreignKey({
			columns: [table.promptAssetId, table.promptAssetVersion],
			foreignColumns: [testExpertPromptAssets.id, testExpertPromptAssets.version],
			name: "test_expert_campaign_prompt_asset_fk"
		}).onDelete("restrict"),
	unique("test_expert_campaign_code_version_unique").on(table.code, table.version),
	check("test_expert_campaign_cap_check", sql`cap_units = 100`),
	check("test_expert_campaign_code_bounded", sql`(char_length(code) >= 1) AND (char_length(code) <= 128)`),
	check("test_expert_campaign_period_check", sql`(effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to > effective_from)`),
	check("test_expert_campaign_prompt_activation_check", sql`(status <> 'active'::text) OR ((prompt_asset_id IS NOT NULL) AND (prompt_asset_version IS NOT NULL) AND (effective_from IS NOT NULL))`),
	check("test_expert_campaign_provider_calls_check", sql`provider_calls_per_message = 1`),
	check("test_expert_campaign_status_check", sql`status = ANY (ARRAY['inactive'::text, 'active'::text, 'retired'::text])`),
	check("test_expert_campaign_version_positive", sql`version > 0`),
]);

export const testExpertLifecycleAuditEvents = pgTable("test_expert_lifecycle_audit_events", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	entityType: text("entity_type").notNull(),
	entityId: uuid("entity_id").notNull(),
	fromStatus: text("from_status").notNull(),
	toStatus: text("to_status").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	check("test_expert_lifecycle_entity_type_check", sql`entity_type = ANY (ARRAY['prompt'::text, 'campaign'::text])`),
	check("test_expert_lifecycle_transition_check", sql`from_status <> to_status`),
]);

export const testExpertSessions = pgTable("test_expert_sessions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	campaignVersionId: uuid("campaign_version_id"),
	userId: uuid("user_id").notNull(),
	dialogueId: uuid("dialogue_id").notNull(),
	botKey: text("bot_key").notNull(),
	externalChatId: text("external_chat_id").notNull(),
	state: text().notNull(),
	version: integer().default(1).notNull(),
	segment: text(),
	nameDigest: char("name_digest", { length: 64 }),
	specializationDigest: char("specialization_digest", { length: 64 }),
	copyVersion: text("copy_version").notNull(),
	sellingActivation: text("selling_activation").default('inactive').notNull(),
	status: text().default('active').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	redemptionId: uuid("redemption_id"),
}, (table) => [
	uniqueIndex("test_expert_session_one_active_scope_idx").using("btree", table.botKey.asc().nullsLast().op("text_ops"), table.externalChatId.asc().nullsLast().op("text_ops")).where(sql`(status = 'active'::text)`),
	index("test_expert_sessions_user_idx").using("btree", table.userId.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.userId, table.dialogueId, table.botKey, table.externalChatId],
			foreignColumns: [dialogues.id, dialogues.userId, dialogues.botKey, dialogues.externalChatId],
			name: "test_expert_session_dialogue_scope_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.campaignVersionId, table.userId, table.redemptionId],
			foreignColumns: [testExpertRedemptions.id, testExpertRedemptions.campaignVersionId, testExpertRedemptions.userId],
			name: "test_expert_session_redemption_scope_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.campaignVersionId],
			foreignColumns: [testExpertCampaignVersions.id],
			name: "test_expert_sessions_campaign_version_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.dialogueId],
			foreignColumns: [dialogues.id],
			name: "test_expert_sessions_dialogue_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "test_expert_sessions_user_id_fkey"
		}).onDelete("restrict"),
	check("test_expert_session_closed_equivalence_check", sql`(state = 'closed'::text) = (status = 'closed'::text)`),
	check("test_expert_session_copy_bounded", sql`(char_length(copy_version) >= 1) AND (char_length(copy_version) <= 128)`),
	check("test_expert_session_digest_check", sql`((name_digest IS NULL) OR (name_digest ~ '^[0-9a-f]{64}$'::text)) AND ((specialization_digest IS NULL) OR (specialization_digest ~ '^[0-9a-f]{64}$'::text))`),
	check("test_expert_session_progress_check", sql`((state = 'awaiting_name'::text) AND (name_digest IS NULL) AND (specialization_digest IS NULL) AND (segment IS NULL)) OR ((state = 'awaiting_specialization'::text) AND (name_digest IS NOT NULL) AND (specialization_digest IS NULL) AND (segment IS NULL)) OR ((state = 'awaiting_segment'::text) AND (name_digest IS NOT NULL) AND (specialization_digest IS NOT NULL) AND (segment IS NULL)) OR ((state = ANY (ARRAY['ready'::text, 'qualified'::text, 'closed'::text])) AND (name_digest IS NOT NULL) AND (specialization_digest IS NOT NULL) AND (segment IS NOT NULL))`),
	check("test_expert_session_qualified_authority_check", sql`(state <> 'qualified'::text) OR ((campaign_version_id IS NOT NULL) AND (redemption_id IS NOT NULL))`),
	check("test_expert_session_scope_bounded", sql`((char_length(bot_key) >= 1) AND (char_length(bot_key) <= 128)) AND ((char_length(external_chat_id) >= 1) AND (char_length(external_chat_id) <= 64))`),
	check("test_expert_session_segment_check", sql`(segment IS NULL) OR (segment = ANY (ARRAY['EXPERT'::text, 'CENTER'::text, 'ORGANIZER'::text]))`),
	check("test_expert_session_selling_inactive", sql`selling_activation = 'inactive'::text`),
	check("test_expert_session_state_check", sql`state = ANY (ARRAY['awaiting_name'::text, 'awaiting_specialization'::text, 'awaiting_segment'::text, 'ready'::text, 'qualified'::text, 'closed'::text])`),
	check("test_expert_session_status_check", sql`status = ANY (ARRAY['active'::text, 'closed'::text])`),
	check("test_expert_session_version_positive", sql`version > 0`),
]);

export const testExpertDeterministicRequests = pgTable("test_expert_deterministic_requests", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	sessionId: uuid("session_id").notNull(),
	outboxId: uuid("outbox_id").notNull(),
	botKey: text("bot_key").notNull(),
	requestKey: text("request_key").notNull(),
	requestDigest: char("request_digest", { length: 64 }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.outboxId],
			foreignColumns: [integrationOutbox.id],
			name: "test_expert_deterministic_requests_outbox_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.sessionId],
			foreignColumns: [testExpertSessions.id],
			name: "test_expert_deterministic_requests_session_id_fkey"
		}).onDelete("restrict"),
	unique("test_expert_deterministic_scope_key_unique").on(table.botKey, table.requestKey),
	check("test_expert_deterministic_bot_bounded", sql`(char_length(bot_key) >= 1) AND (char_length(bot_key) <= 128)`),
	check("test_expert_deterministic_digest_check", sql`request_digest ~ '^[0-9a-f]{64}$'::text`),
	check("test_expert_deterministic_key_bounded", sql`(char_length(request_key) >= 1) AND (char_length(request_key) <= 128)`),
]);

export const testExpertRedemptions = pgTable("test_expert_redemptions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	campaignVersionId: uuid("campaign_version_id").notNull(),
	userId: uuid("user_id").notNull(),
	redemptionIdempotencyKey: text("redemption_idempotency_key").notNull(),
	grantedUnits: integer("granted_units").default(100).notNull(),
	consumedUnits: integer("consumed_units").default(0).notNull(),
	reservedUnits: integer("reserved_units").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("test_expert_redemptions_user_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops"), table.campaignVersionId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.campaignVersionId],
			foreignColumns: [testExpertCampaignVersions.id],
			name: "test_expert_redemptions_campaign_version_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "test_expert_redemptions_user_id_fkey"
		}).onDelete("restrict"),
	unique("test_expert_redemption_scope_unique").on(table.id, table.campaignVersionId, table.userId),
	unique("test_expert_redemption_key_unique").on(table.redemptionIdempotencyKey),
	check("test_expert_redemption_capacity_check", sql`(consumed_units + reserved_units) <= granted_units`),
	check("test_expert_redemption_granted_check", sql`granted_units = 100`),
	check("test_expert_redemption_key_bounded", sql`(char_length(redemption_idempotency_key) >= 1) AND (char_length(redemption_idempotency_key) <= 128)`),
	check("test_expert_redemption_nonnegative_check", sql`(consumed_units >= 0) AND (reserved_units >= 0)`),
	check("test_expert_redemption_units_even_check", sql`((consumed_units % 2) = 0) AND ((reserved_units % 2) = 0)`),
]);

export const testExpertReservations = pgTable("test_expert_reservations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	redemptionId: uuid("redemption_id").notNull(),
	requestKey: text("request_key").notNull(),
	requestDigest: text("request_digest").notNull(),
	units: integer().default(2).notNull(),
	status: text().default('reserved').notNull(),
	providerRequestId: text("provider_request_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("test_expert_reservations_provider_request_idx").using("btree", table.providerRequestId.asc().nullsLast().op("text_ops")).where(sql`(provider_request_id IS NOT NULL)`),
	index("test_expert_reservations_redemption_status_idx").using("btree", table.redemptionId.asc().nullsLast().op("timestamptz_ops"), table.status.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("test_expert_reservations_unknown_global_idx").using("btree", table.createdAt.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(status = ANY (ARRAY['reserved'::text, 'unknown'::text]))`),
	foreignKey({
			columns: [table.redemptionId],
			foreignColumns: [testExpertRedemptions.id],
			name: "test_expert_reservations_redemption_id_fkey"
		}).onDelete("restrict"),
	unique("test_expert_reservation_request_unique").on(table.redemptionId, table.requestKey),
	check("test_expert_reservation_digest_check", sql`request_digest ~ '^[0-9a-f]{64}$'::text`),
	check("test_expert_reservation_key_bounded", sql`(char_length(request_key) >= 1) AND (char_length(request_key) <= 128)`),
	check("test_expert_reservation_provider_request_check", sql`((status = ANY (ARRAY['unknown'::text, 'applied'::text])) AND (provider_request_id ~ '^sha256:[0-9a-f]{64}$'::text)) OR ((status = ANY (ARRAY['reserved'::text, 'not_applied'::text])) AND ((provider_request_id IS NULL) OR (provider_request_id ~ '^sha256:[0-9a-f]{64}$'::text)))`),
	check("test_expert_reservation_status_check", sql`status = ANY (ARRAY['reserved'::text, 'unknown'::text, 'applied'::text, 'not_applied'::text])`),
	check("test_expert_reservation_units_check", sql`units = 2`),
]);

export const testExpertOutcomes = pgTable("test_expert_outcomes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reservationId: uuid("reservation_id").notNull(),
	outcome: text().notNull(),
	providerRequestId: text("provider_request_id"),
	recordedAt: timestamp("recorded_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("test_expert_outcomes_reservation_idx").using("btree", table.reservationId.asc().nullsLast().op("timestamptz_ops"), table.recordedAt.asc().nullsLast().op("timestamptz_ops")),
	uniqueIndex("test_expert_outcomes_terminal_unique").using("btree", table.reservationId.asc().nullsLast().op("uuid_ops")).where(sql`(outcome = ANY (ARRAY['applied'::text, 'not_applied'::text]))`),
	uniqueIndex("test_expert_outcomes_unknown_unique").using("btree", table.reservationId.asc().nullsLast().op("uuid_ops")).where(sql`(outcome = 'unknown'::text)`),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [testExpertReservations.id],
			name: "test_expert_outcomes_reservation_id_fkey"
		}).onDelete("restrict"),
	unique("test_expert_outcome_reservation_unique").on(table.reservationId, table.outcome),
	check("test_expert_outcome_provider_request_check", sql`((outcome = ANY (ARRAY['unknown'::text, 'applied'::text])) AND (provider_request_id ~ '^sha256:[0-9a-f]{64}$'::text)) OR ((outcome = 'not_applied'::text) AND ((provider_request_id IS NULL) OR (provider_request_id ~ '^sha256:[0-9a-f]{64}$'::text)))`),
	check("test_expert_outcome_value_check", sql`outcome = ANY (ARRAY['unknown'::text, 'applied'::text, 'not_applied'::text])`),
]);

export const testExpertAuditEvents = pgTable("test_expert_audit_events", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	redemptionId: uuid("redemption_id").notNull(),
	reservationId: uuid("reservation_id"),
	eventType: text("event_type").notNull(),
	eventDigest: text("event_digest"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("test_expert_audit_redemption_idx").using("btree", table.redemptionId.asc().nullsLast().op("timestamptz_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.redemptionId],
			foreignColumns: [testExpertRedemptions.id],
			name: "test_expert_audit_events_redemption_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [testExpertReservations.id],
			name: "test_expert_audit_events_reservation_id_fkey"
		}).onDelete("restrict"),
	check("test_expert_audit_digest_check", sql`(event_digest IS NULL) OR (event_digest ~ '^[0-9a-f]{64}$'::text)`),
	check("test_expert_audit_type_bounded", sql`(char_length(event_type) >= 1) AND (char_length(event_type) <= 64)`),
]);

export const consentDocumentVersions = pgTable("consent_document_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	documentKey: text("document_key").notNull(),
	version: integer().notNull(),
	title: text().notNull(),
	body: text().notNull(),
	textSha256: char("text_sha256", { length: 64 }).notNull(),
	status: text().default('inactive').notNull(),
	effectiveAt: timestamp("effective_at", { withTimezone: true, mode: 'string' }),
	approvedAt: timestamp("approved_at", { withTimezone: true, mode: 'string' }),
	approvedBy: text("approved_by"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("consent_document_key_version_unique").on(table.documentKey, table.version),
	check("consent_document_approval_check", sql`(status <> 'approved'::text) OR ((approved_at IS NOT NULL) AND ((char_length(approved_by) >= 1) AND (char_length(approved_by) <= 128)))`),
	check("consent_document_body_bounded", sql`(char_length(body) >= 1) AND (char_length(body) <= 65536)`),
	check("consent_document_body_matches_digest", sql`(text_sha256)::text = encode(digest(body, 'sha256'::text), 'hex'::text)`),
	check("consent_document_digest_check", sql`text_sha256 ~ '^[0-9a-f]{64}$'::text`),
	check("consent_document_key_bounded", sql`(char_length(document_key) >= 1) AND (char_length(document_key) <= 128)`),
	check("consent_document_status_check", sql`status = ANY (ARRAY['inactive'::text, 'approved'::text, 'retired'::text])`),
	check("consent_document_title_bounded", sql`(char_length(title) >= 1) AND (char_length(title) <= 256)`),
	check("consent_document_transition_audit_required", sql`(status <> 'retired'::text) OR (approved_at IS NOT NULL)`),
	check("consent_document_version_positive", sql`version > 0`),
]);

export const consentPresentations = pgTable("consent_presentations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id"),
	sessionKey: text("session_key"),
	purpose: text().notNull(),
	documentVersionId: uuid("document_version_id").notNull(),
	tokenDigest: text("token_digest").notNull(),
	channel: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	revokeEpoch: bigint("revoke_epoch", { mode: "number" }).default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	consumedAt: timestamp("consumed_at", { withTimezone: true, mode: 'string' }),
	invalidatedAt: timestamp("invalidated_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("consent_presentations_subject_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops"), table.purpose.asc().nullsLast().op("text_ops"), table.createdAt.desc().nullsFirst().op("uuid_ops")),
	uniqueIndex("consent_presentations_token_unique").using("btree", table.tokenDigest.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.documentVersionId],
			foreignColumns: [consentDocumentVersions.id],
			name: "consent_presentations_document_version_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "consent_presentations_user_id_fkey"
		}).onDelete("restrict"),
	check("consent_presentations_channel_check", sql`channel = ANY (ARRAY['web'::text, 'telegram'::text])`),
	check("consent_presentations_epoch_check", sql`revoke_epoch >= 0`),
	check("consent_presentations_expiry_check", sql`expires_at > created_at`),
	check("consent_presentations_purpose_bounded", sql`(char_length(purpose) >= 1) AND (char_length(purpose) <= 64)`),
	check("consent_presentations_session_bounded", sql`(session_key IS NULL) OR ((char_length(session_key) >= 8) AND (char_length(session_key) <= 128))`),
	check("consent_presentations_subject_check", sql`(user_id IS NOT NULL) <> (session_key IS NOT NULL)`),
	check("consent_presentations_token_digest_check", sql`token_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
]);

export const clientSessionBookingGrants = pgTable("client_session_booking_grants", {
	sessionTokenDigest: char("session_token_digest", { length: 71 }).primaryKey().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.sessionTokenDigest],
			foreignColumns: [clientSessions.tokenDigest],
			name: "client_session_booking_grants_session_fk"
		}).onDelete("cascade"),
]);

export const clientErasureRequests = pgTable("client_erasure_requests", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	receiptDigest: text("receipt_digest").notNull(),
	receiptRevokedAt: timestamp("receipt_revoked_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	jobId: uuid("job_id"),
}, (table) => [
	foreignKey({
			columns: [table.userId, table.jobId],
			foreignColumns: [privacyDeletionJobs.id, privacyDeletionJobs.userId],
			name: "client_erasure_requests_job_subject_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_erasure_requests_user_id_fkey"
		}),
	unique("client_erasure_requests_subject_unique").on(table.userId),
	unique("client_erasure_requests_digest_unique").on(table.receiptDigest),
	unique("client_erasure_requests_job_unique").on(table.jobId),
	check("client_erasure_requests_created_check", sql`CHECK (isfinite(created_at`),
	check("client_erasure_requests_digest_check", sql`receipt_digest ~ '^[0-9a-f]{64}$'::text`),
]);

export const clientPaidOrders = pgTable("client_paid_orders", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	packageCode: text("package_code").notNull(),
	policyVersion: text("policy_version").notNull(),
	currency: text().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
	units: integer().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	couponGrantMinor: bigint("coupon_grant_minor", { mode: "number" }).notNull(),
	mode: text().notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { precision: 3, withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_paid_orders_user_id_fkey"
		}),
	unique("client_paid_orders_user_key_unique").on(table.userId, table.idempotencyKey),
	check("client_paid_orders_created_finite", sql`CHECK (isfinite(created_at`),
	check("client_paid_orders_key", sql`idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text`),
	check("client_paid_orders_mode", sql`mode = ANY (ARRAY['live'::text, 'test'::text])`),
	check("client_paid_orders_terms", sql`(policy_version = 'client_paid_v1'::text) AND (currency = 'RUB'::text) AND (coupon_grant_minor = (price_minor * 2)) AND (((package_code = 'start'::text) AND (price_minor = 499900) AND (units = 500)) OR ((package_code = 'base'::text) AND (price_minor = 599900) AND (units = 1000)) OR ((package_code = 'deep'::text) AND (price_minor = 799900) AND (units = 1500)) OR ((package_code = 'maximum'::text) AND (price_minor = 1099000) AND (units = 2000)))`),
]);

export const clientPaidPaymentBindings = pgTable("client_paid_payment_bindings", {
	orderId: uuid("order_id").primaryKey().notNull(),
	providerPaymentId: text("provider_payment_id").notNull(),
	createdAt: timestamp("created_at", { precision: 3, withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [clientPaidOrders.id],
			name: "client_paid_payment_bindings_order_id_fkey"
		}),
	unique("client_paid_bindings_order_payment_unique").on(table.orderId, table.providerPaymentId),
	unique("client_paid_bindings_payment_unique").on(table.providerPaymentId),
	check("client_paid_bindings_payment_id", sql`provider_payment_id ~ '^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$'::text`),
]);

export const clientCouponGrants = pgTable("client_coupon_grants", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	orderId: uuid("order_id").notNull(),
	userId: uuid("user_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
	capturedAt: timestamp("captured_at", { precision: 3, withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { precision: 3, withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [clientPaidOrders.id],
			name: "client_coupon_grants_order_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "client_coupon_grants_user_id_fkey"
		}),
	unique("client_coupon_grants_order_id_unique").on(table.id, table.orderId),
	unique("client_coupon_grants_order_unique").on(table.orderId),
	check("client_coupon_grants_expiry", sql`isfinite(captured_at) AND isfinite(expires_at) AND (expires_at = (captured_at + '1080:00:00'::interval))`),
	check("client_coupon_grants_positive", sql`amount_minor > 0`),
]);

export const clientPaidSettlements = pgTable("client_paid_settlements", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	orderId: uuid("order_id").notNull(),
	providerPaymentId: text("provider_payment_id").notNull(),
	packageId: uuid("package_id").notNull(),
	ledgerEntryId: uuid("ledger_entry_id").notNull(),
	couponGrantId: uuid("coupon_grant_id").notNull(),
	capturedAt: timestamp("captured_at", { precision: 3, withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.orderId, table.providerPaymentId],
			foreignColumns: [clientPaidPaymentBindings.orderId, clientPaidPaymentBindings.providerPaymentId],
			name: "client_paid_settlements_binding_fk"
		}),
	foreignKey({
			columns: [table.orderId, table.couponGrantId],
			foreignColumns: [clientCouponGrants.id, clientCouponGrants.orderId],
			name: "client_paid_settlements_coupon_fk"
		}),
	foreignKey({
			columns: [table.ledgerEntryId],
			foreignColumns: [messageLedgerEntries.id],
			name: "client_paid_settlements_ledger_entry_id_fkey"
		}),
	foreignKey({
			columns: [table.packageId],
			foreignColumns: [messagePackages.id],
			name: "client_paid_settlements_package_id_fkey"
		}),
	unique("client_paid_settlements_order_unique").on(table.orderId),
	unique("client_paid_settlements_package_unique").on(table.packageId),
	unique("client_paid_settlements_ledger_unique").on(table.ledgerEntryId),
	unique("client_paid_settlements_coupon_unique").on(table.couponGrantId),
	check("client_paid_settlements_captured_finite", sql`CHECK (isfinite(captured_at`),
]);

export const planerkaServiceMappings = pgTable("planerka_service_mappings", {
	expertServiceId: uuid("expert_service_id").primaryKey().notNull(),
	accountId: integer("account_id").notNull(),
	eventTypeId: integer("event_type_id").notNull(),
	durationMinutes: integer("duration_minutes").notNull(),
	timeZone: text("time_zone").notNull(),
	enabled: boolean().default(false).notNull(),
	verifiedAt: timestamp("verified_at", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.expertServiceId],
			foreignColumns: [expertServices.id],
			name: "planerka_service_mappings_expert_service_id_fkey"
		}),
	unique("planerka_service_mappings_account_id_event_type_id_key").on(table.accountId, table.eventTypeId),
	check("planerka_service_mappings_account_id_check", sql`account_id > 0`),
	check("planerka_service_mappings_duration_minutes_check", sql`(duration_minutes >= 1) AND (duration_minutes <= 1440)`),
	check("planerka_service_mappings_event_type_id_check", sql`event_type_id > 0`),
	check("planerka_service_mappings_time_zone_check", sql`(length(time_zone) >= 1) AND (length(time_zone) <= 128)`),
]);

export const bookingNotificationDeliveries = pgTable("booking_notification_deliveries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	sourceOutboxId: uuid("source_outbox_id").notNull(),
	reservationId: uuid("reservation_id").notNull(),
	recipientRole: text("recipient_role").notNull(),
	recipientUserId: uuid("recipient_user_id").notNull(),
	recipientIdentityId: uuid("recipient_identity_id"),
	originalIdentityId: uuid("original_identity_id"),
	botKey: text("bot_key").notNull(),
	externalUserId: text("external_user_id"),
	externalChatId: text("external_chat_id"),
	kind: text().notNull(),
	sourceVersion: integer("source_version"),
	providerOperationId: uuid("provider_operation_id"),
	templateVersion: integer("template_version").default(1).notNull(),
	state: text().default('pending').notNull(),
	reasonCode: text("reason_code"),
	attemptCount: integer("attempt_count").default(0).notNull(),
	nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	leaseToken: uuid("lease_token"),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	workerId: text("worker_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("booking_notification_deliveries_due").using("btree", table.nextAttemptAt.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(state = ANY (ARRAY['pending'::text, 'retry_wait'::text]))`),
	foreignKey({
			columns: [table.providerOperationId],
			foreignColumns: [planerkaBookingOperations.id],
			name: "booking_notification_deliveries_provider_operation_id_fkey"
		}),
	foreignKey({
			columns: [table.recipientIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "booking_notification_deliveries_recipient_identity_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.recipientUserId],
			foreignColumns: [users.id],
			name: "booking_notification_deliveries_recipient_user_id_fkey"
		}),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "booking_notification_deliveries_reservation_id_fkey"
		}),
	foreignKey({
			columns: [table.sourceOutboxId],
			foreignColumns: [integrationOutbox.id],
			name: "booking_notification_deliveries_source_outbox_id_fkey"
		}),
	unique("booking_notification_deliveri_source_outbox_id_recipient_ro_key").on(table.sourceOutboxId, table.recipientRole),
	check("booking_notification_deliveries_attempt_count_check", sql`(attempt_count >= 0) AND (attempt_count <= 5)`),
	check("booking_notification_deliveries_check", sql`((external_user_id IS NULL) AND (external_chat_id IS NULL) AND (original_identity_id IS NULL)) OR ((external_user_id IS NOT NULL) AND (external_chat_id IS NOT NULL) AND (external_user_id ~ '^[1-9][0-9]{0,15}$'::text) AND (external_chat_id = external_user_id) AND (original_identity_id IS NOT NULL))`),
	check("booking_notification_deliveries_check1", sql`(lease_token IS NULL) = (lease_until IS NULL)`),
	check("booking_notification_deliveries_kind_check", sql`kind = ANY (ARRAY['telegram.reservation_request'::text, 'client.booking_confirmed'::text, 'telegram.booking_cancelled'::text, 'client.booking_cancelled'::text, 'client.reservation_expired'::text, 'expert.reservation_expired'::text, 'client.booking_completed'::text, 'client.booking_no_show'::text])`),
	check("booking_notification_deliveries_recipient_role_check", sql`recipient_role = ANY (ARRAY['client'::text, 'expert'::text])`),
	check("booking_notification_deliveries_source_version_check", sql`source_version > 0`),
	check("booking_notification_deliveries_state_check", sql`state = ANY (ARRAY['pending'::text, 'retry_wait'::text, 'sending'::text, 'delivered'::text, 'suppressed'::text, 'unknown'::text, 'manual'::text, 'failed'::text])`),
	check("booking_notification_deliveries_template_version_check", sql`template_version = 1`),
	check("booking_notification_lease_shape", sql`((lease_token IS NULL) = (worker_id IS NULL)) AND ((worker_id IS NULL) OR (length(worker_id) > 0))`),
	check("booking_notification_state_lease", sql`(state = ANY (ARRAY['pending'::text, 'retry_wait'::text])) OR ((state = 'sending'::text) AND (lease_token IS NOT NULL) AND (attempt_count > 0)) OR ((state = ANY (ARRAY['delivered'::text, 'suppressed'::text, 'unknown'::text, 'manual'::text, 'failed'::text])) AND (lease_token IS NULL))`),
]);

export const planerkaBookingOperations = pgTable("planerka_booking_operations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reservationId: uuid("reservation_id").notNull(),
	accountId: integer("account_id").notNull(),
	eventTypeId: integer("event_type_id").notNull(),
	request: jsonb().notNull(),
	requestFingerprint: text("request_fingerprint").notNull(),
	startsAt: timestamp("starts_at", { withTimezone: true, mode: 'string' }).notNull(),
	endsAt: timestamp("ends_at", { withTimezone: true, mode: 'string' }).notNull(),
	state: text().default('pending').notNull(),
	providerUid: text("provider_uid"),
	cancelRequested: boolean("cancel_requested").default(false).notNull(),
	sendAdmittedAt: timestamp("send_admitted_at", { withTimezone: true, mode: 'string' }),
	leaseToken: uuid("lease_token"),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	recoveryCount: integer("recovery_count").default(0).notNull(),
	nextAttemptAt: timestamp("next_attempt_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	reasonCode: text("reason_code"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("planerka_booking_operations_due").using("btree", table.nextAttemptAt.asc().nullsLast().op("timestamptz_ops"), table.leaseUntil.asc().nullsLast().op("timestamptz_ops")).where(sql`(state = ANY (ARRAY['pending'::text, 'sending'::text, 'unknown'::text, 'cancel_pending'::text, 'cancelling'::text, 'cancel_unknown'::text]))`),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "planerka_booking_operations_reservation_id_fkey"
		}),
	unique("planerka_booking_operations_reservation_id_key").on(table.reservationId),
	unique("planerka_booking_operations_provider_uid_key").on(table.providerUid),
	check("planerka_booking_operations_account_id_check", sql`account_id > 0`),
	check("planerka_booking_operations_check", sql`ends_at > starts_at`),
	check("planerka_booking_operations_check1", sql`(lease_token IS NULL) = (lease_until IS NULL)`),
	check("planerka_booking_operations_check2", sql`(state <> ALL (ARRAY['booked'::text, 'finished'::text, 'cancel_pending'::text, 'cancelling'::text, 'cancel_unknown'::text])) OR (provider_uid IS NOT NULL)`),
	check("planerka_booking_operations_check3", sql`(state <> ALL (ARRAY['sending'::text, 'unknown'::text])) OR (send_admitted_at IS NOT NULL)`),
	check("planerka_booking_operations_event_type_id_check", sql`event_type_id > 0`),
	check("planerka_booking_operations_provider_uid_check", sql`(provider_uid ~ '^[A-Za-z0-9_-]+$'::text) AND ((length(provider_uid) >= 1) AND (length(provider_uid) <= 256))`),
	check("planerka_booking_operations_recovery_count_check", sql`(recovery_count >= 0) AND (recovery_count <= 5)`),
	check("planerka_booking_operations_request_fingerprint_check", sql`request_fingerprint ~ '^[0-9a-f]{64}$'::text`),
	check("planerka_booking_operations_state_check", sql`state = ANY (ARRAY['pending'::text, 'sending'::text, 'unknown'::text, 'booked'::text, 'finished'::text, 'cancel_pending'::text, 'cancelling'::text, 'cancel_unknown'::text, 'cancelled'::text, 'rejected'::text, 'manual'::text])`),
]);

export const planerkaAccountRequests = pgTable("planerka_account_requests", {
	accountId: integer("account_id").primaryKey().notNull(),
	nextRequestAt: timestamp("next_request_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	check("planerka_account_requests_account_id_check", sql`account_id > 0`),
]);

export const planerkaLegacyBookingReviews = pgTable("planerka_legacy_booking_reviews", {
	reservationId: uuid("reservation_id").primaryKey().notNull(),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }),
	evidenceReference: text("evidence_reference"),
}, (table) => [
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "planerka_legacy_booking_reviews_reservation_id_fkey"
		}),
	check("planerka_legacy_booking_reviews_check", sql`(resolved_at IS NULL) = (evidence_reference IS NULL)`),
]);

export const bookingNotificationAttempts = pgTable("booking_notification_attempts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	deliveryId: uuid("delivery_id").notNull(),
	ordinal: integer().notNull(),
	claimToken: uuid("claim_token").notNull(),
	requestDigest: text("request_digest").notNull(),
	admittedAt: timestamp("admitted_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	botKey: text("bot_key").notNull(),
	chatId: text("chat_id").notNull(),
	outcome: text().default('started').notNull(),
	wireVersion: integer("wire_version"),
}, (table) => [
	foreignKey({
			columns: [table.deliveryId],
			foreignColumns: [bookingNotificationDeliveries.id],
			name: "booking_notification_attempts_delivery_id_fkey"
		}),
	unique("booking_notification_attempts_delivery_id_ordinal_key").on(table.deliveryId, table.ordinal),
	unique("booking_notification_attempts_claim_token_key").on(table.claimToken),
	check("booking_notification_attempts_ordinal_check", sql`(ordinal >= 1) AND (ordinal <= 5)`),
	check("booking_notification_attempts_outcome_check", sql`outcome = 'started'::text`),
	check("booking_notification_attempts_request_digest_check", sql`request_digest ~ '^[a-f0-9]{64}$'::text`),
	check("booking_notification_attempts_wire_version_check", sql`wire_version = 1`),
]);

export const bookingNotificationContexts = pgTable("booking_notification_contexts", {
	reservationId: uuid("reservation_id").primaryKey().notNull(),
	botKey: text("bot_key").notNull(),
	clientUserId: uuid("client_user_id").notNull(),
	expertUserId: uuid("expert_user_id").notNull(),
	clientIdentityId: uuid("client_identity_id"),
	clientOriginalIdentityId: uuid("client_original_identity_id"),
	clientExternalUserId: text("client_external_user_id"),
	clientExternalChatId: text("client_external_chat_id"),
	clientUnavailableReason: text("client_unavailable_reason"),
	expertIdentityId: uuid("expert_identity_id"),
	expertOriginalIdentityId: uuid("expert_original_identity_id"),
	expertExternalUserId: text("expert_external_user_id"),
	expertExternalChatId: text("expert_external_chat_id"),
	expertUnavailableReason: text("expert_unavailable_reason"),
	clientConsentAuthority: jsonb("client_consent_authority"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.clientIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "booking_notification_contexts_client_identity_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.clientUserId],
			foreignColumns: [users.id],
			name: "booking_notification_contexts_client_user_id_fkey"
		}),
	foreignKey({
			columns: [table.expertIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "booking_notification_contexts_expert_identity_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.expertUserId],
			foreignColumns: [users.id],
			name: "booking_notification_contexts_expert_user_id_fkey"
		}),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "booking_notification_contexts_reservation_id_fkey"
		}),
	check("booking_notification_client_tuple", sql`((client_original_identity_id IS NOT NULL) AND (client_external_user_id IS NOT NULL) AND (client_external_chat_id IS NOT NULL) AND (client_external_user_id ~ '^[1-9][0-9]{0,15}$'::text) AND (client_external_chat_id = client_external_user_id) AND (client_unavailable_reason IS NULL)) OR ((client_original_identity_id IS NULL) AND (client_external_user_id IS NULL) AND (client_external_chat_id IS NULL) AND (client_unavailable_reason IS NOT NULL))`),
	check("booking_notification_consent_shape", sql`(client_consent_authority IS NULL) OR (((jsonb_typeof(client_consent_authority) = 'object'::text) AND ((client_consent_authority - ARRAY['v'::text, 'subjectId'::text, 'purposes'::text]) = '{}'::jsonb) AND ((client_consent_authority -> 'v'::text) = '1'::jsonb) AND ((client_consent_authority ->> 'subjectId'::text) = (client_user_id)::text) AND (jsonb_typeof((client_consent_authority -> 'purposes'::text)) = 'object'::text) AND (((client_consent_authority -> 'purposes'::text) - 'client_messaging'::text) = '{}'::jsonb) AND (jsonb_typeof((client_consent_authority #> '{purposes,client_messaging}'::text[])) = 'object'::text) AND (((client_consent_authority #> '{purposes,client_messaging}'::text[]) - ARRAY['decisionId'::text, 'revision'::text]) = '{}'::jsonb) AND ((client_consent_authority #>> '{purposes,client_messaging,decisionId}'::text[]) ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$'::text) AND (jsonb_typeof((client_consent_authority #> '{purposes,client_messaging,revision}'::text[])) = 'string'::text) AND ((client_consent_authority #>> '{purposes,client_messaging,revision}'::text[]) ~ '^[1-9][0-9]{0,18}$'::text) AND (((client_consent_authority #>> '{purposes,client_messaging,revision}'::text[]))::numeric <= ('9223372036854775807'::bigint)::numeric)) IS TRUE)`),
	check("booking_notification_contexts_bot_key_check", sql`length(bot_key) > 0`),
	check("booking_notification_contexts_client_unavailable_reason_check", sql`client_unavailable_reason = ANY (ARRAY['recipient_unavailable'::text, 'erased'::text])`),
	check("booking_notification_contexts_expert_unavailable_reason_check", sql`expert_unavailable_reason = ANY (ARRAY['recipient_unavailable'::text, 'erased'::text])`),
	check("booking_notification_expert_tuple", sql`((expert_original_identity_id IS NOT NULL) AND (expert_external_user_id IS NOT NULL) AND (expert_external_chat_id IS NOT NULL) AND (expert_external_user_id ~ '^[1-9][0-9]{0,15}$'::text) AND (expert_external_chat_id = expert_external_user_id) AND (expert_unavailable_reason IS NULL)) OR ((expert_original_identity_id IS NULL) AND (expert_external_user_id IS NULL) AND (expert_external_chat_id IS NULL) AND (expert_unavailable_reason IS NOT NULL))`),
]);

export const bookingNotificationAttemptFacts = pgTable("booking_notification_attempt_facts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	attemptId: uuid("attempt_id").notNull(),
	outcome: text().notNull(),
	botKey: text("bot_key"),
	responseChatId: text("response_chat_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	telegramMessageId: bigint("telegram_message_id", { mode: "number" }),
	retryAfterSeconds: integer("retry_after_seconds"),
	reasonCode: text("reason_code").notNull(),
	resolvedAt: timestamp("resolved_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	resolutionEvidenceRef: text("resolution_evidence_ref"),
}, (table) => [
	foreignKey({
			columns: [table.attemptId],
			foreignColumns: [bookingNotificationAttempts.id],
			name: "booking_notification_attempt_facts_attempt_id_fkey"
		}),
	unique("booking_notification_attempt_facts_attempt_id_outcome_key").on(table.attemptId, table.outcome),
	unique("booking_notification_attempt__bot_key_response_chat_id_tele_key").on(table.botKey, table.responseChatId, table.telegramMessageId),
	check("booking_notification_attempt_facts_check", sql`((outcome = 'applied'::text) AND (bot_key IS NOT NULL) AND (response_chat_id IS NOT NULL) AND (telegram_message_id IS NOT NULL) AND (telegram_message_id > 0)) OR ((outcome <> 'applied'::text) AND (bot_key IS NULL) AND (response_chat_id IS NULL) AND (telegram_message_id IS NULL))`),
	check("booking_notification_attempt_facts_outcome_check", sql`outcome = ANY (ARRAY['not_applied'::text, 'applied'::text, 'unknown'::text, 'failed'::text])`),
	check("booking_notification_attempt_facts_retry_after_seconds_check", sql`(retry_after_seconds >= 0) AND (retry_after_seconds <= 2147483647)`),
]);

export const bookingNotificationBotControls = pgTable("booking_notification_bot_controls", {
	botKey: text("bot_key").primaryKey().notNull(),
	admissionEnabled: boolean("admission_enabled").default(false).notNull(),
	pausedAt: timestamp("paused_at", { withTimezone: true, mode: 'string' }),
	pauseReason: text("pause_reason"),
	notBefore: timestamp("not_before", { withTimezone: true, mode: 'string' }).default(sql`'-infinity'`).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	check("booking_notification_bot_controls_bot_key_check", sql`(length(bot_key) >= 1) AND (length(bot_key) <= 128)`),
	check("booking_notification_bot_controls_check", sql`(paused_at IS NULL) = (pause_reason IS NULL)`),
	check("booking_notification_bot_controls_pause_reason_check", sql`pause_reason = ANY (ARRAY['bot_rejected'::text, 'bot_mismatch'::text, 'request_invalid'::text])`),
]);

export const bookingHandoffRevocationReceipts = pgTable("booking_handoff_revocation_receipts", {
	sourceOutboxId: uuid("source_outbox_id").primaryKey().notNull(),
	consentDecisionId: uuid("consent_decision_id"),
	outcome: text().notNull(),
	coverage: text().notNull(),
	knownRecipientCount: integer("known_recipient_count").default(0).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.consentDecisionId],
			foreignColumns: [consents.id],
			name: "booking_handoff_revocation_receipts_consent_decision_id_fkey"
		}),
	foreignKey({
			columns: [table.sourceOutboxId],
			foreignColumns: [integrationOutbox.id],
			name: "booking_handoff_revocation_receipts_source_outbox_id_fkey"
		}),
	check("booking_handoff_revocation_outcome_check", sql`((outcome = 'processed'::text) AND (consent_decision_id IS NOT NULL) AND (coverage = 'historical_disclosure_untracked'::text)) OR ((outcome = 'quarantined_invalid'::text) AND (consent_decision_id IS NULL) AND (coverage = 'invalid_source'::text)) OR ((outcome = 'quarantined_legacy'::text) AND (consent_decision_id IS NOT NULL) AND (coverage = 'historical_disclosure_untracked'::text))`),
	check("booking_handoff_revocation_recipient_count_check", sql`known_recipient_count = 0`),
]);

export const expertSessions = pgTable("expert_sessions", {
	tokenDigest: text("token_digest").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	channelIdentityId: uuid("channel_identity_id").notNull(),
	externalId: text("external_id").notNull(),
	botKey: text("bot_key"),
	externalChatId: text("external_chat_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("expert_sessions_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("text_ops"), table.tokenDigest.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.channelIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "expert_sessions_channel_identity_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_sessions_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_sessions_user_id_fkey"
		}),
	check("expert_sessions_digest", sql`token_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_sessions_identity", sql`(external_id ~ '^[1-9][0-9]{0,15}$'::text) AND ((bot_key IS NULL) OR (bot_key ~ '^[A-Za-z0-9_-]{1,64}$'::text)) AND (((external_chat_id IS NOT NULL) AND (external_chat_id = external_id)) OR ((bot_key IS NULL) AND (external_chat_id IS NULL)))`),
	check("expert_sessions_lifetime", sql`isfinite(created_at) AND isfinite(expires_at) AND (expires_at > created_at) AND (expires_at <= (created_at + '01:00:00'::interval)) AND ((revoked_at IS NULL) OR (isfinite(revoked_at) AND (revoked_at >= created_at)))`),
]);

export const expertIdentityProofReceipts = pgTable("expert_identity_proof_receipts", {
	replayDigest: text("replay_digest").primaryKey().notNull(),
	sessionTokenDigest: text("session_token_digest"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	index("expert_identity_proof_expiry_idx").using("btree", table.expiresAt.asc().nullsLast().op("text_ops"), table.replayDigest.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.sessionTokenDigest],
			foreignColumns: [expertSessions.tokenDigest],
			name: "expert_identity_proof_receipts_session_token_digest_fkey"
		}).onDelete("set null"),
	unique("expert_identity_proof_receipts_session_token_digest_key").on(table.sessionTokenDigest),
	check("expert_proof_digest", sql`replay_digest ~ '^expert-login:v1:[0-9a-f]{64}$'::text`),
	check("expert_proof_lifetime", sql`isfinite(created_at) AND isfinite(expires_at) AND (expires_at > created_at) AND (expires_at <= (created_at + '00:05:30'::interval))`),
]);

export const expertPromoRegistrations = pgTable("expert_promo_registrations", {
	identityDigest: text("identity_digest"),
	erasedAt: timestamp("erased_at", { withTimezone: true, mode: 'string' }),
	userId: uuid("user_id").primaryKey().notNull(),
	referrerUserId: uuid("referrer_user_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_promo_referrer_idx").using("btree", table.referrerUserId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.referrerUserId],
			foreignColumns: [users.id],
			name: "expert_promo_registrations_referrer_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_registrations_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_promo_registrations_identity_digest_key").on(table.identityDigest),
	unique("expert_promo_registration_owner_unique").on(table.userId, table.referrerUserId),
	check("expert_promo_identity_digest", sql`identity_digest ~ '^[0-9a-f]{64}$'::text`),
	check("expert_promo_no_self", sql`user_id IS DISTINCT FROM referrer_user_id`),
]);

export const payerReceiptContacts = pgTable("payer_receipt_contacts", {
	id: uuid().primaryKey().notNull(),
	quoteId: uuid("quote_id").notNull(),
	userId: uuid("user_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	kind: text().notNull(),
	basis: text().notNull(),
	capturedAt: timestamp("captured_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	keyId: text("key_id"),
	ciphertext: text(),
	redactedAt: timestamp("redacted_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("payer_receipt_cleanup").using("btree", table.expiresAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(redacted_at IS NULL)`),
	foreignKey({
			columns: [table.quoteId, table.userId],
			foreignColumns: [expertCampaignQuotes.id, expertCampaignQuotes.userId],
			name: "payer_receipt_quote_owner_fk"
		}),
	unique("payer_receipt_identity_unique").on(table.id, table.quoteId, table.userId),
	unique("payer_receipt_user_key_unique").on(table.userId, table.idempotencyKey),
	check("payer_receipt_contacts_basis_check", sql`basis = 'fiscal_payment_dec_plt_004_v1'::text`),
	check("payer_receipt_contacts_kind_check", sql`kind = 'email'::text`),
	check("payer_receipt_envelope_valid", sql`((redacted_at IS NULL) AND (key_id IS NOT NULL) AND (key_id ~ '^[A-Za-z0-9_-]{1,64}$'::text) AND (ciphertext IS NOT NULL) AND ((length(ciphertext) >= 45) AND (length(ciphertext) <= 405)) AND (ciphertext ~ '^prc1\.[A-Za-z0-9_-]+$'::text)) OR ((redacted_at IS NOT NULL) AND isfinite(redacted_at) AND (redacted_at >= captured_at) AND (key_id IS NULL) AND (ciphertext IS NULL))`),
	check("payer_receipt_key_valid", sql`idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$'::text`),
	check("payer_receipt_time_valid", sql`isfinite(captured_at) AND isfinite(expires_at) AND (captured_at = date_trunc('milliseconds'::text, captured_at)) AND (expires_at = date_trunc('milliseconds'::text, expires_at)) AND (expires_at > captured_at) AND (expires_at <= (captured_at + '400 days'::interval))`),
]);

export const payerReceiptOrderBindings = pgTable("payer_receipt_order_bindings", {
	orderId: uuid("order_id").primaryKey().notNull(),
	contactId: uuid("contact_id").notNull(),
	quoteId: uuid("quote_id").notNull(),
	userId: uuid("user_id").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.contactId, table.quoteId, table.userId],
			foreignColumns: [payerReceiptContacts.id, payerReceiptContacts.quoteId, payerReceiptContacts.userId],
			name: "payer_receipt_binding_contact_fk"
		}),
	foreignKey({
			columns: [table.orderId, table.quoteId],
			foreignColumns: [expertResidencyOrders.id, expertResidencyOrders.campaignQuoteId],
			name: "payer_receipt_binding_order_fk"
		}),
	unique("payer_receipt_order_bindings_contact_id_key").on(table.contactId),
]);

export const expertOnboardingApplications = pgTable("expert_onboarding_applications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	campaignQuoteId: uuid("campaign_quote_id"),
	verificationStatus: text("verification_status").default('pending').notNull(),
	onboardingStage: text("onboarding_stage"),
	archivedAt: timestamp("archived_at", { withTimezone: true, mode: 'string' }),
	archiveUntilDate: timestamp("archive_until_date", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("expert_onboarding_current_user_unique").using("btree", table.userId.asc().nullsLast().op("uuid_ops")).where(sql`(verification_status <> 'rejected'::text)`),
	index("expert_onboarding_pending_queue_idx").using("btree", table.createdAt.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("timestamptz_ops")).where(sql`(verification_status = 'pending'::text)`),
	foreignKey({
			columns: [table.userId, table.campaignQuoteId],
			foreignColumns: [expertCampaignQuotes.id, expertCampaignQuotes.userId],
			name: "expert_onboarding_quote_owner_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_onboarding_user_fk"
		}),
	unique("expert_onboarding_id_user_unique").on(table.id, table.userId),
	check("expert_onboarding_archive_bounds", sql`((archived_at IS NULL) AND (archive_until_date IS NULL)) OR ((archived_at IS NOT NULL) AND (archive_until_date IS NOT NULL) AND isfinite(archived_at) AND isfinite(archive_until_date) AND (archive_until_date >= archived_at) AND (archive_until_date <= (((archived_at AT TIME ZONE 'UTC'::text) + '3 mons'::interval) AT TIME ZONE 'UTC'::text)))`),
	check("expert_onboarding_stage_valid", sql`onboarding_stage = ANY (ARRAY['interview'::text, 'card_draft'::text, 'manager_review'::text, 'promo_check'::text, 'payment_ready'::text])`),
	check("expert_onboarding_verification_valid", sql`verification_status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])`),
]);

export const expertPromoCodes = pgTable("expert_promo_codes", {
	userId: uuid("user_id").primaryKey().notNull(),
	refCode: text("ref_code").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_codes_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_promo_codes_ref_code_key").on(table.refCode),
	check("expert_promo_code_namespace", sql`ref_code ~ '^promo_[0-9a-f]{32}$'::text`),
]);

export const expertPromoGuideWork = pgTable("expert_promo_guide_work", {
	userId: uuid("user_id").primaryKey().notNull(),
	status: text().default('waiting_content').notNull(),
	contentSlot: text("content_slot").default('TODO: Wait for PDF').notNull(),
	deliveredAt: timestamp("delivered_at", { withTimezone: true, mode: 'string' }),
	deliveryReceipt: text("delivery_receipt"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	readyLogEventId: uuid("ready_log_event_id"),
}, (table) => [
	foreignKey({
			columns: [table.readyLogEventId],
			foreignColumns: [expertPromoReadyLogs.id],
			name: "expert_promo_guide_work_ready_log_event_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_guide_work_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_promo_guide_work_ready_log_event_id_key").on(table.readyLogEventId),
	check("expert_promo_guide_delivery", sql`((status = 'delivered'::text) AND (delivered_at IS NOT NULL) AND isfinite(delivered_at) AND (delivery_receipt IS NOT NULL) AND ((length(delivery_receipt) >= 1) AND (length(delivery_receipt) <= 200))) OR ((status <> 'delivered'::text) AND (delivered_at IS NULL) AND (delivery_receipt IS NULL))`),
	check("expert_promo_guide_status", sql`status = ANY (ARRAY['waiting_content'::text, 'pending'::text, 'delivered'::text, 'cancelled'::text])`),
]);

export const expertPromoBonusIndications = pgTable("expert_promo_bonus_indications", {
	userId: uuid("user_id").primaryKey().notNull(),
	bonusPoints: integer("bonus_points").default(100).notNull(),
	status: text().default('frozen').notNull(),
	policyVersion: text("policy_version").default('promo_advance_within_qualified_1000_v1').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_bonus_indications_user_id_fkey"
		}).onDelete("cascade"),
	check("expert_promo_indication_nonfinancial", sql`(bonus_points = 100) AND (status = 'frozen'::text) AND (policy_version = 'promo_advance_within_qualified_1000_v1'::text)`),
]);

export const expertPromoManagerWork = pgTable("expert_promo_manager_work", {
	applicationId: uuid("application_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	status: text().default('pending').notNull(),
	contentSlot: text("content_slot").default('TODO: Wait for Content Spec').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	uniqueIndex("expert_promo_manager_current_owner").using("btree", table.userId.asc().nullsLast().op("uuid_ops")).where(sql`(status = 'pending'::text)`),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_promo_manager_work_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_manager_work_user_id_fkey"
		}).onDelete("cascade"),
	check("expert_promo_manager_status", sql`status = ANY (ARRAY['pending'::text, 'completed'::text, 'cancelled'::text])`),
]);

export const expertPromoEnrollments = pgTable("expert_promo_enrollments", {
	userId: uuid("user_id").primaryKey().notNull(),
	channelIdentityId: uuid("channel_identity_id").notNull(),
	botId: text("bot_id").notNull(),
	refCode: text("ref_code"),
	presentationId: uuid("presentation_id"),
	policyVersion: text("policy_version"),
	status: text().default('pending').notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(now() + '24:00:00'::interval)`).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.channelIdentityId],
			foreignColumns: [channelIdentities.id],
			name: "expert_promo_enrollments_channel_identity_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.presentationId],
			foreignColumns: [consentPresentations.id],
			name: "expert_promo_enrollments_presentation_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_enrollments_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_promo_enrollments_channel_identity_id_key").on(table.channelIdentityId),
	check("expert_promo_enrollment_bot", sql`bot_id ~ '^[1-9][0-9]{0,19}$'::text`),
	check("expert_promo_enrollment_expiry", sql`isfinite(expires_at) AND (expires_at > created_at) AND (expires_at <= (created_at + '24:00:00'::interval))`),
	check("expert_promo_enrollment_ref", sql`(ref_code IS NULL) OR (ref_code ~ '^promo_[0-9a-f]{32}$'::text)`),
	check("expert_promo_enrollment_status", sql`status = ANY (ARRAY['pending'::text, 'granted'::text, 'denied'::text])`),
]);

export const expertOnboardingInvoices = pgTable("expert_onboarding_invoices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	userId: uuid("user_id").notNull(),
	decisionId: uuid("decision_id").notNull(),
	decision: text().default('approved').notNull(),
	purpose: text().default('onboarding').notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).default(300000).notNull(),
	currency: text().default('RUB').notNull(),
	providerMode: text("provider_mode").notNull(),
	status: text().default('pending').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	salesAttemptNumber: integer("sales_attempt_number"),
}, (table) => [
	uniqueIndex("expert_onboarding_legacy_application_once").using("btree", table.applicationAuditId.asc().nullsLast().op("uuid_ops")).where(sql`(sales_attempt_number IS NULL)`),
	uniqueIndex("expert_onboarding_legacy_decision_once").using("btree", table.decisionId.asc().nullsLast().op("uuid_ops")).where(sql`(sales_attempt_number IS NULL)`),
	uniqueIndex("expert_onboarding_sales_attempt_once").using("btree", table.decisionId.asc().nullsLast().op("int4_ops"), table.salesAttemptNumber.asc().nullsLast().op("int4_ops")).where(sql`(sales_attempt_number IS NOT NULL)`),
	foreignKey({
			columns: [table.applicationAuditId, table.userId, table.decisionId, table.decision],
			foreignColumns: [expertVerificationDecisions.id, expertVerificationDecisions.applicationAuditId, expertVerificationDecisions.userId, expertVerificationDecisions.decision],
			name: "expert_onboarding_invoice_decision_fk"
		}),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_onboarding_invoices_application_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_onboarding_invoices_user_id_fkey"
		}),
	unique("expert_onboarding_invoice_binding").on(table.id, table.applicationAuditId, table.userId, table.purpose, table.amountMinor, table.currency, table.providerMode),
	check("expert_onboarding_invoice_audit", sql`(application_id IS NULL) OR (application_id = application_audit_id)`),
	check("expert_onboarding_invoice_mode", sql`provider_mode = ANY (ARRAY['test'::text, 'live'::text])`),
	check("expert_onboarding_invoice_purpose", sql`(purpose = 'onboarding'::text) AND (amount_minor = 300000) AND (currency = 'RUB'::text) AND (decision = 'approved'::text)`),
	check("expert_onboarding_invoice_status", sql`status = ANY (ARRAY['pending'::text, 'settled'::text, 'cancelled'::text])`),
	check("expert_onboarding_invoices_sales_attempt_number_check", sql`sales_attempt_number > 0`),
]);

export const expertVerificationDecisions = pgTable("expert_verification_decisions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	userId: uuid("user_id").notNull(),
	managerId: uuid("manager_id").notNull(),
	managerSessionHash: text("manager_session_hash").notNull(),
	decision: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_verification_decisions_application_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_verification_decisions_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.managerSessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_verification_decisions_manager_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_verification_decisions_user_id_fkey"
		}),
	unique("expert_verification_decision_binding").on(table.id, table.applicationAuditId, table.userId, table.decision),
	unique("expert_verification_decisions_application_audit_id_key").on(table.applicationAuditId),
	unique("expert_verification_decision_replay").on(table.managerId, table.idempotencyKey),
	check("expert_verification_application_audit", sql`(application_id IS NULL) OR (application_id = application_audit_id)`),
	check("expert_verification_decision_status", sql`decision = ANY (ARRAY['approved'::text, 'rejected'::text])`),
	check("expert_verification_reason_code", sql`reason_code ~ '^[a-z][a-z0-9_]{0,63}$'::text`),
	check("expert_verification_request_key", sql`idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text`),
]);

export const expertOnboardingPaymentOperations = pgTable("expert_onboarding_payment_operations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	invoiceId: uuid("invoice_id").notNull(),
	applicationAuditId: uuid("application_audit_id").notNull(),
	userId: uuid("user_id").notNull(),
	purpose: text().default('onboarding').notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).default(300000).notNull(),
	currency: text().default('RUB').notNull(),
	providerMode: text("provider_mode").notNull(),
	providerObjectId: text("provider_object_id"),
	status: text().default('created').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId, table.applicationAuditId, table.userId, table.purpose, table.amountMinor, table.currency, table.providerMode],
			foreignColumns: [expertOnboardingInvoices.id, expertOnboardingInvoices.applicationAuditId, expertOnboardingInvoices.userId, expertOnboardingInvoices.purpose, expertOnboardingInvoices.amountMinor, expertOnboardingInvoices.currency, expertOnboardingInvoices.providerMode],
			name: "expert_onboarding_operation_invoice_fk"
		}),
	unique("expert_onboarding_operation_binding").on(table.id, table.invoiceId, table.userId, table.purpose, table.amountMinor, table.currency, table.providerMode, table.providerObjectId),
	unique("expert_onboarding_payment_operations_invoice_id_key").on(table.invoiceId),
	unique("expert_onboarding_payment_operations_provider_object_id_key").on(table.providerObjectId),
	check("expert_onboarding_operation_mode", sql`provider_mode = ANY (ARRAY['test'::text, 'live'::text])`),
	check("expert_onboarding_operation_provider_id", sql`(provider_object_id IS NULL) OR (provider_object_id ~ '^[A-Za-z0-9_-]{1,64}$'::text)`),
	check("expert_onboarding_operation_purpose", sql`(purpose = 'onboarding'::text) AND (amount_minor = 300000) AND (currency = 'RUB'::text)`),
	check("expert_onboarding_operation_status", sql`status = ANY (ARRAY['created'::text, 'pending'::text, 'unknown_outcome'::text, 'succeeded'::text, 'cancelled'::text])`),
]);

export const expertOnboardingPaymentFacts = pgTable("expert_onboarding_payment_facts", {
	invoiceId: uuid("invoice_id").primaryKey().notNull(),
	operationId: uuid("operation_id").notNull(),
	userId: uuid("user_id").notNull(),
	purpose: text().default('onboarding').notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).default(300000).notNull(),
	currency: text().default('RUB').notNull(),
	providerMode: text("provider_mode").notNull(),
	providerObjectId: text("provider_object_id").notNull(),
	eventId: text("event_id").notNull(),
	evidenceDigest: text("evidence_digest").notNull(),
	capturedAt: timestamp("captured_at", { withTimezone: true, mode: 'string' }).notNull(),
	admission: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId, table.operationId, table.userId, table.purpose, table.amountMinor, table.currency, table.providerMode, table.providerObjectId],
			foreignColumns: [expertOnboardingPaymentOperations.id, expertOnboardingPaymentOperations.invoiceId, expertOnboardingPaymentOperations.userId, expertOnboardingPaymentOperations.purpose, expertOnboardingPaymentOperations.amountMinor, expertOnboardingPaymentOperations.currency, expertOnboardingPaymentOperations.providerMode, expertOnboardingPaymentOperations.providerObjectId],
			name: "expert_onboarding_fact_operation_fk"
		}),
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertOnboardingInvoices.id],
			name: "expert_onboarding_payment_facts_invoice_id_fkey"
		}),
	unique("expert_onboarding_payment_facts_operation_id_key").on(table.operationId),
	unique("expert_onboarding_payment_facts_provider_object_id_key").on(table.providerObjectId),
	unique("expert_onboarding_payment_facts_event_id_key").on(table.eventId),
	check("expert_onboarding_fact_admission", sql`((admission = 'interview'::text) AND (reason_code = 'payment_verified'::text)) OR ((admission = 'blocked'::text) AND (reason_code = ANY (ARRAY['application_erased'::text, 'owner_inactive'::text, 'consent_unavailable'::text, 'application_unavailable'::text, 'expired_terms'::text, 'duplicate_fee'::text, 'capture_unproven'::text])))`),
	check("expert_onboarding_fact_binding", sql`(purpose = 'onboarding'::text) AND (amount_minor = 300000) AND (currency = 'RUB'::text) AND (provider_mode = ANY (ARRAY['test'::text, 'live'::text]))`),
	check("expert_onboarding_fact_capture", sql`isfinite(captured_at) AND (captured_at >= '1970-01-01 00:00:00+00'::timestamp with time zone)`),
	check("expert_onboarding_fact_evidence", sql`(evidence_digest ~ '^sha256:[0-9a-f]{64}$'::text) AND ((length(event_id) >= 1) AND (length(event_id) <= 200))`),
]);

export const expertCardEntries = pgTable("expert_card_entries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	kind: text().notNull(),
	textContent: text("text_content"),
	mediaReference: text("media_reference"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_entry_owner"
		}).onDelete("cascade"),
	check("expert_card_entry_revision", sql`CHECK (COALESCE(((revision >= 1) AND (revision <= 1000000)), false`),
	check("expert_card_entry_value", sql`CHECK (COALESCE((((kind = 'text'::text) AND ((char_length(text_content) >= 1) AND (char_length(text_content) <= 4000)) AND (media_reference IS NULL)) OR ((kind = ANY (ARRAY['photo'::text, 'document'::text])) AND (text_content IS NULL) AND (media_reference IS NOT NULL) AND ((char_length(media_reference) >= 15) AND (char_length(media_reference) <= 526)) AND (media_reference ~ '^telegram:file:[A-Za-z0-9_-]+$'::text))), false`),
]);

export const expertVerificationWork = pgTable("expert_verification_work", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	kind: text().notNull(),
	reasonCode: text("reason_code"),
	contentSlot: text("content_slot").default('TODO: Wait for Content Spec').notNull(),
	status: text().default('pending').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	attemptId: uuid("attempt_id"),
	attemptedAt: timestamp("attempted_at", { withTimezone: true, mode: 'string' }),
	deliveryMessageId: text("delivery_message_id"),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_verification_work_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_verification_work_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_verification_work_once").on(table.applicationId, table.kind),
	check("expert_verification_work_kind", sql`kind = ANY (ARRAY['onboarding_invoice'::text, 'verification_rejected'::text, 'interview_ready'::text])`),
	check("expert_verification_work_reason", sql`(reason_code IS NULL) OR (reason_code ~ '^[a-z][a-z0-9_]{0,63}$'::text)`),
	check("expert_verification_work_status", sql`status = ANY (ARRAY['pending'::text, 'completed'::text, 'cancelled'::text, 'unknown_outcome'::text])`),
	check("expert_workspace_notification_attempt", sql`((attempt_id IS NULL) AND (attempted_at IS NULL) AND (delivery_message_id IS NULL)) OR ((kind = 'interview_ready'::text) AND (attempt_id IS NOT NULL) AND (attempted_at IS NOT NULL) AND isfinite(attempted_at) AND (status = ANY (ARRAY['unknown_outcome'::text, 'completed'::text, 'cancelled'::text])) AND ((delivery_message_id IS NULL) OR (delivery_message_id ~ '^[1-9][0-9]{0,19}$'::text)))`),
]);

export const expertCardMaterialJobs = pgTable("expert_card_material_jobs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	reviewId: uuid("review_id").notNull(),
	revision: integer().notNull(),
	templateId: uuid("template_id"),
	contentVersion: text("content_version"),
	attemptId: uuid("attempt_id"),
	attemptStartedAt: timestamp("attempt_started_at", { withTimezone: true, mode: 'string' }),
	expectedMessageCount: integer("expected_message_count"),
	status: text().default('waiting_content').notNull(),
	deliveryReceipt: jsonb("delivery_receipt"),
	payloadDigest: text("payload_digest"),
	deliveredAt: timestamp("delivered_at", { withTimezone: true, mode: 'string' }),
	targetBotId: text("target_bot_id").notNull(),
	targetChatId: text("target_chat_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_material_jobs_review_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_material_owner"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.templateId, table.contentVersion],
			foreignColumns: [expertCardMaterialTemplates.id, expertCardMaterialTemplates.contentVersion],
			name: "expert_card_material_template"
		}),
	unique("expert_card_material_once").on(table.reviewId),
	check("expert_card_material_attempt", sql`CHECK (COALESCE((((attempt_id IS NULL) AND (attempt_started_at IS NULL)) OR ((attempt_id IS NOT NULL) AND (attempt_started_at IS NOT NULL) AND isfinite(attempt_started_at))), false`),
	check("expert_card_material_receipt", sql`CHECK (COALESCE((((status = 'delivered'::text) AND (template_id IS NOT NULL) AND (content_version IS NOT NULL) AND (delivered_at IS NOT NULL) AND isfinite(delivered_at) AND (attempt_id IS NOT NULL) AND (payload_digest IS NOT NULL) AND (payload_digest ~ '^sha256:[0-9a-f]{64}$'::text) AND expert_card_delivery_receipt_valid(delivery_receipt, target_bot_id, target_chat_id, content_version, payload_digest, expected_message_count)) OR ((status <> 'delivered'::text) AND (delivery_receipt IS NULL) AND (delivered_at IS NULL))), false`),
	check("expert_card_material_status", sql`CHECK (COALESCE((status = ANY (ARRAY['waiting_content'::text, 'pending'::text, 'delivered'::text, 'cancelled'::text, 'unknown_outcome'::text])), false`),
]);

export const expertCardMaterialTemplates = pgTable("expert_card_material_templates", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	contentVersion: text("content_version").notNull(),
	status: text().default('inactive').notNull(),
	contentSlot: text("content_slot").default('TODO: Wait for Content Spec').notNull(),
	textBody: text("text_body"),
	assets: jsonb().default([]).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	unique("expert_card_template_identity").on(table.id, table.contentVersion),
	unique("expert_card_material_templates_content_version_key").on(table.contentVersion),
	check("expert_card_template_value", sql`CHECK (COALESCE((((length(content_version) >= 1) AND (length(content_version) <= 128)) AND (jsonb_typeof(assets) = 'array'::text) AND (jsonb_array_length(assets) <= 8) AND (((status = 'inactive'::text) AND (text_body IS NULL)) OR ((status = 'approved'::text) AND ((char_length(text_body) >= 1) AND (char_length(text_body) <= 4000))))), false`),
]);

export const expertCardPromoProofs = pgTable("expert_card_promo_proofs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	reviewId: uuid("review_id").notNull(),
	revision: integer().notNull(),
	kind: text().notNull(),
	reference: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_promo_proofs_review_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_proof_owner"
		}).onDelete("cascade"),
	check("expert_card_proof_value", sql`CHECK (COALESCE((((kind = 'link'::text) AND ((length(reference) >= 1) AND (length(reference) <= 2048)) AND (reference ~~ 'https://%'::text)) OR ((kind = ANY (ARRAY['photo'::text, 'document'::text])) AND (reference IS NOT NULL) AND ((char_length(reference) >= 15) AND (char_length(reference) <= 526)) AND (reference ~ '^telegram:file:[A-Za-z0-9_-]+$'::text))), false`),
]);

export const expertCardPromoConfirmations = pgTable("expert_card_promo_confirmations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	reviewId: uuid("review_id").notNull(),
	revision: integer().notNull(),
	proofDigest: text("proof_digest").notNull(),
	managerId: uuid("manager_id").notNull(),
	managerSessionHash: text("manager_session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_card_promo_confirmations_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.managerSessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_card_promo_confirmations_manager_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_promo_confirmations_review_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_promo_owner"
		}).onDelete("cascade"),
	unique("expert_card_promo_once").on(table.reviewId, table.proofDigest),
	check("expert_card_promo_digest", sql`CHECK (COALESCE((proof_digest ~ '^sha256:[0-9a-f]{64}$'::text), false`),
]);

export const expertCardHandoffs = pgTable("expert_card_handoffs", {
	tokenDigest: text("token_digest").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	applicationId: uuid("application_id").notNull(),
	sourceBotKey: text("source_bot_key").notNull(),
	externalId: text("external_id").notNull(),
	targetBotId: text("target_bot_id").notNull(),
	targetBotKey: text("target_bot_key").notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(now() + '00:10:00'::interval)`).notNull(),
	consumedAt: timestamp("consumed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_card_handoffs_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_card_handoffs_user_id_fkey"
		}),
	check("expert_card_handoff_digest", sql`CHECK (COALESCE((token_digest ~ '^sha256:[0-9a-f]{64}$'::text), false`),
	check("expert_card_handoff_scope", sql`CHECK (COALESCE(((external_id ~ '^[1-9][0-9]{0,19}$'::text) AND (target_bot_id ~ '^[1-9][0-9]{0,19}$'::text)), false`),
	check("expert_card_handoff_time", sql`CHECK (COALESCE((isfinite(expires_at) AND (expires_at > created_at) AND (expires_at <= (created_at + '00:10:00'::interval)) AND ((consumed_at IS NULL) OR isfinite(consumed_at))), false`),
]);

export const expertCardStaffActions = pgTable("expert_card_staff_actions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	managerId: uuid("manager_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	draftId: uuid("draft_id").notNull(),
	operation: text().notNull(),
	semanticDigest: text("semantic_digest").notNull(),
	resultId: uuid("result_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "expert_card_staff_actions_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_card_staff_actions_manager_id_fkey"
		}),
	unique("expert_card_staff_request").on(table.managerId, table.idempotencyKey),
	check("expert_card_staff_value", sql`CHECK (COALESCE(((operation = ANY (ARRAY['edit_public'::text, 'approve'::text, 'return_changes'::text, 'confirm_promo'::text])) AND (semantic_digest ~ '^[0-9a-f]{64}$'::text) AND (idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text)), false`),
]);

export const expertCardConsentEpoch = pgTable("expert_card_consent_epoch", {
	id: integer().default(1).primaryKey().notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	revision: bigint({ mode: "number" }).default(1).notNull(),
}, (table) => [
	check("expert_card_consent_epoch_singleton", sql`CHECK (COALESCE(((id = 1) AND (revision > 0)), false`),
]);

export const expertCardMainAcceptances = pgTable("expert_card_main_acceptances", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	reviewId: uuid("review_id"),
	reviewAuditId: uuid("review_audit_id").notNull(),
	revision: integer().notNull(),
	publicDigest: text("public_digest").notNull(),
	quoteId: uuid("quote_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	acceptanceSource: text("acceptance_source").default('explicit').notNull(),
	offerScheduleId: uuid("offer_schedule_id"),
}, (table) => [
	foreignKey({
			columns: [table.userId, table.expertId],
			foreignColumns: [experts.id, experts.userId],
			name: "expert_card_acceptance_owner_fk"
		}),
	foreignKey({
			columns: [table.userId, table.quoteId],
			foreignColumns: [expertCampaignQuotes.id, expertCampaignQuotes.userId],
			name: "expert_card_acceptance_quote_fk"
		}),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_card_main_acceptances_application_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.offerScheduleId],
			foreignColumns: [expertOfferSchedules.id],
			name: "expert_card_main_acceptances_offer_schedule_id_fkey"
		}),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_main_acceptances_review_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_card_main_acceptances_user_id_fkey"
		}),
	unique("expert_card_acceptance_identity").on(table.id, table.userId, table.expertId, table.quoteId),
	unique("expert_card_acceptance_once").on(table.userId, table.reviewAuditId, table.quoteId),
	check("expert_card_acceptance_live", sql`((application_id IS NULL) OR (application_id = application_audit_id)) AND ((review_id IS NULL) OR (review_id = review_audit_id))`),
	check("expert_card_acceptance_source_valid", sql`((acceptance_source = 'explicit'::text) AND (offer_schedule_id IS NULL)) OR ((acceptance_source = 'schedule'::text) AND (offer_schedule_id IS NOT NULL))`),
	check("expert_card_main_acceptances_public_digest_check", sql`public_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_card_main_acceptances_revision_check", sql`revision > 0`),
]);

export const expertCardMainOrders = pgTable("expert_card_main_orders", {
	orderId: uuid("order_id").primaryKey().notNull(),
	acceptanceId: uuid("acceptance_id").notNull(),
	applicationId: uuid("application_id"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	quoteId: uuid("quote_id").notNull(),
	reviewId: uuid("review_id"),
	reviewAuditId: uuid("review_audit_id").notNull(),
	revision: integer().notNull(),
	publicDigest: text("public_digest").notNull(),
	purpose: text().default('main_residency').notNull(),
	providerMode: text("provider_mode").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.acceptanceId, table.userId, table.expertId, table.quoteId],
			foreignColumns: [expertCardMainAcceptances.id, expertCardMainAcceptances.userId, expertCardMainAcceptances.expertId, expertCardMainAcceptances.quoteId],
			name: "expert_card_main_order_acceptance_fk"
		}),
	foreignKey({
			columns: [table.orderId, table.expertId],
			foreignColumns: [expertResidencyOrders.id, expertResidencyOrders.expertId],
			name: "expert_card_main_order_owner_fk"
		}),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_card_main_orders_application_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_main_orders_review_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_card_main_orders_user_id_fkey"
		}),
	unique("expert_card_main_order_identity").on(table.orderId, table.userId, table.expertId),
	unique("expert_card_main_orders_acceptance_id_key").on(table.acceptanceId),
	check("expert_card_main_order_live", sql`((application_id IS NULL) OR (application_id = application_audit_id)) AND ((review_id IS NULL) OR (review_id = review_audit_id))`),
	check("expert_card_main_orders_provider_mode_check", sql`provider_mode = ANY (ARRAY['test'::text, 'live'::text])`),
	check("expert_card_main_orders_public_digest_check", sql`public_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_card_main_orders_purpose_check", sql`purpose = 'main_residency'::text`),
	check("expert_card_main_orders_revision_check", sql`revision > 0`),
]);

export const expertPromoQualificationAudits = pgTable("expert_promo_qualification_audits", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	mainOrderId: uuid("main_order_id").notNull(),
	inviteeUserId: uuid("invitee_user_id").notNull(),
	inviterUserId: uuid("inviter_user_id").notNull(),
	inviteeExpertId: uuid("invitee_expert_id").notNull(),
	inviterExpertId: uuid("inviter_expert_id").notNull(),
	providerEventId: uuid("provider_event_id").notNull(),
	qualifiedAt: timestamp("qualified_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.providerEventId],
			foreignColumns: [expertResidencyProviderEventInbox.id],
			name: "expert_promo_qualification_audits_provider_event_id_fkey"
		}),
	foreignKey({
			columns: [table.inviterUserId, table.inviterExpertId],
			foreignColumns: [experts.id, experts.userId],
			name: "expert_promo_qualification_inviter_fk"
		}),
	foreignKey({
			columns: [table.mainOrderId, table.inviteeUserId, table.inviteeExpertId],
			foreignColumns: [expertCardMainOrders.orderId, expertCardMainOrders.userId, expertCardMainOrders.expertId],
			name: "expert_promo_qualification_order_fk"
		}),
	foreignKey({
			columns: [table.inviteeUserId, table.inviterUserId],
			foreignColumns: [expertPromoRegistrations.userId, expertPromoRegistrations.referrerUserId],
			name: "expert_promo_qualification_registration_fk"
		}),
	unique("expert_promo_qualification_identity").on(table.id, table.inviteeExpertId, table.inviterExpertId),
	unique("expert_promo_qualification_audits_main_order_id_key").on(table.mainOrderId),
	unique("expert_promo_qualification_audits_provider_event_id_key").on(table.providerEventId),
	check("expert_promo_qualification_distinct", sql`(invitee_user_id <> inviter_user_id) AND (invitee_expert_id <> inviter_expert_id)`),
]);

export const expertsPublished = pgTable("experts_published", {
	expertId: uuid("expert_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	applicationAuditId: uuid("application_audit_id").notNull(),
	draftId: uuid("draft_id"),
	reviewId: uuid("review_id"),
	revision: integer().notNull(),
	publicPayload: jsonb("public_payload").notNull(),
	publicDigest: text("public_digest").notNull(),
	paidOrderId: uuid("paid_order_id").notNull(),
	nextBillingDate: timestamp("next_billing_date", { withTimezone: true, mode: 'string' }).notNull(),
	active: boolean().default(false).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "experts_published_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.expertId, table.userId],
			foreignColumns: [experts.id, experts.userId],
			name: "experts_published_owner_fk"
		}),
	foreignKey({
			columns: [table.expertId, table.paidOrderId],
			foreignColumns: [expertResidencyOrders.id, expertResidencyOrders.expertId],
			name: "experts_published_paid_order_fk"
		}),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "experts_published_review_id_fkey"
		}).onDelete("cascade"),
	check("experts_published_next_billing_date_check", sql`CHECK (isfinite(next_billing_date`),
	check("experts_published_public_digest_check", sql`public_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("experts_published_revision_check", sql`revision > 0`),
]);

export const expertResidencyLifecycle = pgTable("expert_residency_lifecycle", {
	userId: uuid("user_id").primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	status: text().default('active').notNull(),
	pausedUntil: date("paused_until"),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_residency_lifecycle_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.expertId],
			foreignColumns: [experts.id, experts.userId],
			name: "expert_residency_lifecycle_owner_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_residency_lifecycle_user_id_fkey"
		}).onDelete("cascade"),
	unique("expert_residency_lifecycle_expert_id_key").on(table.expertId),
	check("expert_residency_lifecycle_pause", sql`CHECK (COALESCE((((status = 'paused'::text) AND (paused_until IS NOT NULL) AND isfinite(paused_until)) OR ((status <> 'paused'::text) AND (paused_until IS NULL))), false`),
	check("expert_residency_lifecycle_status_check", sql`status = ANY (ARRAY['active'::text, 'paused'::text, 'payment_required'::text])`),
]);

export const expertResidencyRenewalBills = pgTable("expert_residency_renewal_bills", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id"),
	ownerAuditId: uuid("owner_audit_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	cycleEnd: timestamp("cycle_end", { withTimezone: true, mode: 'string' }).notNull(),
	sourceOrderId: uuid("source_order_id").notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	termMonths: integer("term_months").notNull(),
	quoteId: uuid("quote_id"),
	acceptanceId: uuid("acceptance_id"),
	orderId: uuid("order_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.acceptanceId],
			foreignColumns: [expertCardMainAcceptances.id],
			name: "expert_residency_renewal_bills_acceptance_id_fkey"
		}),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_residency_renewal_bills_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_residency_renewal_bills_order_id_fkey"
		}),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_residency_renewal_bills_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.sourceOrderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_residency_renewal_bills_source_order_id_fkey"
		}),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_residency_renewal_bills_tariff_version_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_residency_renewal_bills_user_id_fkey"
		}).onDelete("set null"),
	unique("expert_residency_renewal_cycle_unique").on(table.expertId, table.cycleEnd),
	check("expert_residency_renewal_bills_cycle_end_check", sql`CHECK (isfinite(cycle_end`),
	check("expert_residency_renewal_bills_term_months_check", sql`term_months = ANY (ARRAY[1, 3])`),
]);

export const expertResidencyLifecycleAudits = pgTable("expert_residency_lifecycle_audits", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	action: text().notNull(),
	cycleEnd: timestamp("cycle_end", { withTimezone: true, mode: 'string' }),
	returnDate: date("return_date"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId, table.expertId],
			foreignColumns: [experts.id, experts.userId],
			name: "expert_residency_lifecycle_audit_owner"
		}),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_residency_lifecycle_audits_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_residency_lifecycle_audits_user_id_fkey"
		}).onDelete("cascade"),
	check("expert_residency_lifecycle_audit_pause", sql`(action = 'pause'::text) = (return_date IS NOT NULL)`),
	check("expert_residency_lifecycle_audits_action_check", sql`action = ANY (ARRAY['pause'::text, 'resume'::text, 'automatic_return'::text, 'suspend'::text, 'restore'::text])`),
	check("expert_residency_lifecycle_audits_cycle_end_check", sql`(cycle_end IS NULL) OR isfinite(cycle_end)`),
	check("expert_residency_lifecycle_audits_return_date_check", sql`(return_date IS NULL) OR isfinite(return_date)`),
]);

export const expertResidencyLifecycleNotices = pgTable("expert_residency_lifecycle_notices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	cycleEnd: timestamp("cycle_end", { withTimezone: true, mode: 'string' }).notNull(),
	stage: text().notNull(),
	status: text().default('waiting_content').notNull(),
	targetBotId: text("target_bot_id"),
	targetChatId: text("target_chat_id"),
	templateVersion: text("template_version"),
	payloadDigest: text("payload_digest"),
	attemptId: uuid("attempt_id"),
	attemptedAt: timestamp("attempted_at", { withTimezone: true, mode: 'string' }),
	receipt: jsonb(),
	deliveredAt: timestamp("delivered_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_residency_notice_due").using("btree", table.status.asc().nullsLast().op("text_ops"), table.createdAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(attempt_id IS NULL)`),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_residency_lifecycle_notices_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_residency_lifecycle_notices_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId, table.expertId],
			foreignColumns: [experts.id, experts.userId],
			name: "expert_residency_notice_owner"
		}),
	unique("expert_residency_notice_unique").on(table.expertId, table.cycleEnd, table.stage),
	check("expert_residency_lifecycle_notices_cycle_end_check", sql`CHECK (isfinite(cycle_end`),
	check("expert_residency_lifecycle_notices_stage_check", sql`stage = ANY (ARRAY['seven_days'::text, 'one_day'::text, 'overdue'::text, 'archive_offer'::text])`),
	check("expert_residency_lifecycle_notices_status_check", sql`status = ANY (ARRAY['waiting_content'::text, 'pending'::text, 'unknown_outcome'::text, 'delivered'::text, 'cancelled'::text])`),
	check("expert_residency_notice_attempt", sql`CHECK (COALESCE((((attempt_id IS NULL) = (attempted_at IS NULL)) AND ((attempted_at IS NULL) OR isfinite(attempted_at))), false`),
	check("expert_residency_notice_content", sql`CHECK (COALESCE((((template_version IS NULL) AND (payload_digest IS NULL)) OR ((template_version IS NOT NULL) AND (template_version = (('lifecycle.'::text || stage) || '.v1'::text)) AND (payload_digest IS NOT NULL) AND (payload_digest ~ '^sha256:[0-9a-f]{64}$'::text))), false`),
	check("expert_residency_notice_receipt", sql`CHECK (COALESCE((((status = 'delivered'::text) AND (attempt_id IS NOT NULL) AND (template_version IS NOT NULL) AND (receipt IS NOT NULL) AND (delivered_at IS NOT NULL) AND isfinite(delivered_at) AND expert_card_delivery_receipt_valid(receipt, target_bot_id, target_chat_id, template_version, payload_digest, 1) AND ((receipt ->> 'contentVersion'::text) = template_version) AND ((receipt ->> 'payloadDigest'::text) = payload_digest)) OR ((status <> 'delivered'::text) AND (receipt IS NULL) AND (delivered_at IS NULL))), false`),
]);

export const expertCampaignQuotes = pgTable("expert_campaign_quotes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	ruleVersion: text("rule_version").notNull(),
	calculationTimestamp: timestamp("calculation_timestamp", { withTimezone: true, mode: 'string' }).notNull(),
	quotedAt: timestamp("quoted_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	termMonths: integer("term_months").notNull(),
	durationSeconds: integer("duration_seconds").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	baseMonthlyMinor: bigint("base_monthly_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	discountedMonthlyMinor: bigint("discounted_monthly_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	monthlyPriceMinor: bigint("monthly_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
	currency: text().notNull(),
	energyDiscountBps: integer("energy_discount_bps").notNull(),
	startDiscountBps: integer("start_discount_bps").notNull(),
	floorApplied: boolean("floor_applied").notNull(),
	displayName: text("display_name").notNull(),
	creditCapBps: integer("credit_cap_bps").notNull(),
	individualServicesEnabled: boolean("individual_services_enabled").notNull(),
	groupEventLimit: integer("group_event_limit").notNull(),
	statisticsLevel: text("statistics_level").notNull(),
	supportPriority: text("support_priority").notNull(),
	profileRevision: integer("profile_revision"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	packagePriceMinor: bigint("package_price_minor", { mode: "number" }),
	salesSelectionId: uuid("sales_selection_id"),
	paidLockInvoiceId: uuid("paid_lock_invoice_id"),
}, (table) => [
	foreignKey({
			columns: [table.userId, table.ruleVersion, table.calculationTimestamp],
			foreignColumns: [expertCampaignAnchors.userId, expertCampaignAnchors.ruleVersion, expertCampaignAnchors.calculationTimestamp],
			name: "expert_campaign_quote_anchor_fk"
		}),
	foreignKey({
			columns: [table.userId, table.profileRevision],
			foreignColumns: [expertOfferProfiles.userId, expertOfferProfiles.revision],
			name: "expert_campaign_quote_profile_fk"
		}),
	foreignKey({
			columns: [table.paidLockInvoiceId],
			foreignColumns: [expertSalesPaidLocks.invoiceId],
			name: "expert_campaign_quotes_paid_lock_invoice_id_fkey"
		}),
	foreignKey({
			columns: [table.salesSelectionId],
			foreignColumns: [expertSalesSelections.id],
			name: "expert_campaign_quotes_sales_selection_id_fkey"
		}),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_campaign_quotes_tariff_version_id_fkey"
		}),
	unique("payer_receipt_quote_owner_unique").on(table.id, table.userId),
	unique("expert_campaign_quote_user_key").on(table.userId, table.idempotencyKey),
	check("expert_campaign_quote_arithmetic_valid", sql`(rule_version = 'expert_separated_sales_v3'::text) OR ((rule_version = 'expert_energy_start_v2'::text) OR ((base_monthly_minor > 0) AND (discounted_monthly_minor >= 0) AND ((discounted_monthly_minor)::numeric = div(((((base_monthly_minor)::numeric * ((10000)::numeric - (energy_discount_bps)::numeric)) * ((10000)::numeric - (start_discount_bps)::numeric)) + (50000000)::numeric), (100000000)::numeric)) AND (monthly_price_minor = GREATEST(discounted_monthly_minor, (500000)::bigint)) AND (floor_applied = (discounted_monthly_minor < 500000)) AND ((price_minor)::numeric = ((monthly_price_minor)::numeric * (term_months)::numeric)) AND ((price_minor >= 1) AND (price_minor <= '999999999999'::bigint))))`),
	check("expert_campaign_quote_identity_valid", sql`(rule_version = 'expert_separated_sales_v3'::text) OR ((rule_version = 'expert_energy_start_v2'::text) OR ((rule_version = 'expert_energy_start_v1'::text) AND (currency = 'RUB'::text) AND (idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text)))`),
	check("expert_campaign_quote_stage_valid", sql`(rule_version = 'expert_separated_sales_v3'::text) OR ((rule_version = 'expert_energy_start_v2'::text) OR ((term_months = ANY (ARRAY[1, 3])) AND (duration_seconds = ((2592000)::bigint * term_months)) AND ((term_months = 1) OR ((quoted_at - calculation_timestamp) < '144:00:00'::interval)) AND (energy_discount_bps =
CASE
    WHEN ((quoted_at - calculation_timestamp) < '72:00:00'::interval) THEN 4000
    WHEN ((quoted_at - calculation_timestamp) < '144:00:00'::interval) THEN 3000
    WHEN ((quoted_at - calculation_timestamp) < '216:00:00'::interval) THEN 2000
    ELSE 0
END) AND (start_discount_bps =
CASE
    WHEN (term_months = 1) THEN 0
    WHEN ((quoted_at - calculation_timestamp) < '72:00:00'::interval) THEN 1500
    ELSE 1000
END)))`),
	check("expert_campaign_quote_time_valid", sql`(rule_version = 'expert_separated_sales_v3'::text) OR ((rule_version = 'expert_energy_start_v2'::text) OR (isfinite(calculation_timestamp) AND isfinite(quoted_at) AND isfinite(expires_at) AND (calculation_timestamp >= '1970-01-01 00:00:00+00'::timestamp with time zone) AND (calculation_timestamp <= quoted_at) AND (quoted_at < expires_at) AND (expires_at <= '275760-09-13 00:00:00+00'::timestamp with time zone) AND (calculation_timestamp = date_trunc('milliseconds'::text, calculation_timestamp)) AND (quoted_at = date_trunc('milliseconds'::text, quoted_at)) AND (expires_at = date_trunc('milliseconds'::text, expires_at)) AND (expires_at <= (quoted_at + '00:15:00'::interval))))`),
	check("expert_campaign_quote_v2_valid", sql`(rule_version = 'expert_separated_sales_v3'::text) OR (((rule_version = 'expert_energy_start_v1'::text) AND (profile_revision IS NULL) AND (package_price_minor IS NULL)) OR ((rule_version = 'expert_energy_start_v2'::text) AND (profile_revision IS NOT NULL) AND (currency = 'RUB'::text) AND isfinite(calculation_timestamp) AND isfinite(quoted_at) AND isfinite(expires_at) AND (calculation_timestamp <= quoted_at) AND (quoted_at < expires_at) AND (((quoted_at - calculation_timestamp) < '240:00:00'::interval) OR (expires_at <= (quoted_at + '24:00:00'::interval))) AND (calculation_timestamp = date_trunc('milliseconds'::text, calculation_timestamp)) AND (quoted_at = date_trunc('milliseconds'::text, quoted_at)) AND (expires_at = date_trunc('milliseconds'::text, expires_at)) AND (idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text) AND (term_months = ANY (ARRAY[1, 3])) AND (duration_seconds = ((2592000)::bigint * term_months)) AND ((term_months = 1) OR ((quoted_at - calculation_timestamp) < '168:00:00'::interval)) AND (energy_discount_bps =
CASE
    WHEN ((quoted_at - calculation_timestamp) < '96:00:00'::interval) THEN 4000
    WHEN ((quoted_at - calculation_timestamp) < '168:00:00'::interval) THEN 3000
    WHEN ((quoted_at - calculation_timestamp) < '240:00:00'::interval) THEN 2000
    ELSE 0
END) AND (base_monthly_minor >= 0) AND ((monthly_price_minor)::numeric = GREATEST((500000)::numeric, div((((base_monthly_minor)::numeric * ((10000 - energy_discount_bps))::numeric) + (5000)::numeric), (10000)::numeric))) AND ((discounted_monthly_minor)::numeric = div((((base_monthly_minor)::numeric * ((10000 - energy_discount_bps))::numeric) + (5000)::numeric), (10000)::numeric)) AND (floor_applied =
CASE
    WHEN (term_months = 1) THEN (discounted_monthly_minor < 500000)
    ELSE (div((((((base_monthly_minor)::numeric * (3)::numeric) * ((10000 - energy_discount_bps))::numeric) * ((10000 - start_discount_bps))::numeric) + (50000000)::numeric), (100000000)::numeric) < (1500000)::numeric)
END) AND ((((quoted_at - calculation_timestamp) >= '168:00:00'::interval) AND (package_price_minor IS NULL) AND (start_discount_bps = 0)) OR (((quoted_at - calculation_timestamp) < '168:00:00'::interval) AND (package_price_minor IS NOT NULL) AND ((package_price_minor)::numeric = GREATEST((1500000)::numeric, div((((((base_monthly_minor)::numeric * (3)::numeric) * ((10000 - energy_discount_bps))::numeric) * ((10000 - start_discount_bps))::numeric) + (50000000)::numeric), (100000000)::numeric))))) AND (price_minor =
CASE
    WHEN (term_months = 1) THEN monthly_price_minor
    ELSE package_price_minor
END) AND ((price_minor >= 1) AND (price_minor <= '999999999999'::bigint))))`),
	check("expert_sales_quote_identity", sql`((rule_version = 'expert_separated_sales_v3'::text) AND (sales_selection_id IS NOT NULL) AND (currency = 'RUB'::text) AND (term_months = ANY (ARRAY[1, 3])) AND (duration_seconds = (2592000 * term_months)) AND ((price_minor >= 500000) AND (price_minor <= '999999999999'::bigint)) AND isfinite(quoted_at) AND isfinite(expires_at) AND (quoted_at < expires_at) AND (expires_at <= (quoted_at + '24:00:00'::interval)) AND (idempotency_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,199}$'::text)) OR ((rule_version <> 'expert_separated_sales_v3'::text) AND (sales_selection_id IS NULL) AND (paid_lock_invoice_id IS NULL))`),
]);

export const expertOfferSchedules = pgTable("expert_offer_schedules", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	applicationId: uuid("application_id"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	profileRevision: integer("profile_revision").notNull(),
	termMonths: integer("term_months").notNull(),
	sourceUpdateId: text("source_update_id").notNull(),
	consentVersion: text("consent_version").notNull(),
	originalAcceptanceId: uuid("original_acceptance_id").notNull(),
	revision: integer().notNull(),
	originalQuoteId: uuid("original_quote_id").notNull(),
	reviewId: uuid("review_id"),
	reviewAuditId: uuid("review_audit_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	publicDigest: text("public_digest").notNull(),
	botId: text("bot_id"),
	botKey: text("bot_key"),
	chatId: text("chat_id"),
	requestKey: text("request_key").notNull(),
	requestDigest: text("request_digest").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_offer_schedules_application_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_offer_schedules_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.originalAcceptanceId],
			foreignColumns: [expertCardMainAcceptances.id],
			name: "expert_offer_schedules_original_acceptance_id_fkey"
		}),
	foreignKey({
			columns: [table.originalQuoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_offer_schedules_original_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_offer_schedules_review_id_fkey"
		}).onDelete("set null"),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_offer_schedules_tariff_version_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_offer_schedules_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.profileRevision],
			foreignColumns: [expertOfferProfiles.userId, expertOfferProfiles.revision],
			name: "expert_offer_schedules_user_id_profile_revision_fkey"
		}),
	unique("expert_offer_schedules_user_id_source_update_id_key").on(table.userId, table.sourceUpdateId),
	check("expert_offer_schedules_revision_check", sql`revision > 0`),
	check("expert_offer_schedules_term_months_check", sql`term_months = ANY (ARRAY[1, 3])`),
]);

export const expertPersonalOfferState = pgTable("expert_personal_offer_state", {
	userId: uuid("user_id").primaryKey().notNull(),
	quoteId: uuid("quote_id").notNull(),
	scheduleId: uuid("schedule_id"),
	orderId: uuid("order_id"),
	paymentId: text("payment_id"),
	paymentUrl: text("payment_url"),
	refreshedAt: timestamp("refreshed_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	nextRefreshAt: timestamp("next_refresh_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	index("expert_personal_offer_refresh_due").using("btree", table.nextRefreshAt.asc().nullsLast().op("timestamptz_ops")),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_personal_offer_state_order_id_fkey"
		}),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_personal_offer_state_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.scheduleId],
			foreignColumns: [expertOfferSchedules.id],
			name: "expert_personal_offer_state_schedule_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_personal_offer_state_user_id_fkey"
		}),
]);

export const expertPersonalOfferNotices = pgTable("expert_personal_offer_notices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	quoteId: uuid("quote_id").notNull(),
	stageDeadline: timestamp("stage_deadline", { withTimezone: true, mode: 'string' }).notNull(),
	leadHours: integer("lead_hours").notNull(),
	status: text().default('pending').notNull(),
	attemptId: uuid("attempt_id"),
	attemptedAt: timestamp("attempted_at", { withTimezone: true, mode: 'string' }),
	receipt: jsonb(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	index("expert_personal_offer_notice_pending").using("btree", table.stageDeadline.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = 'pending'::text)`),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_personal_offer_notices_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_personal_offer_notices_user_id_fkey"
		}),
	unique("expert_personal_offer_notices_user_id_stage_deadline_lead_h_key").on(table.userId, table.stageDeadline, table.leadHours),
	check("expert_personal_offer_notices_lead_hours_check", sql`lead_hours = ANY (ARRAY[24, 3, 0])`),
	check("expert_personal_offer_notices_status_check", sql`status = ANY (ARRAY['pending'::text, 'unknown_outcome'::text, 'delivered'::text, 'cancelled'::text])`),
]);

export const expertManagerTelegramPairings = pgTable("expert_manager_telegram_pairings", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	tokenHash: text("token_hash").notNull(),
	sessionHash: text("session_hash").notNull(),
	botId: text("bot_id").notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	telegramUserId: text("telegram_user_id"),
	telegramChatId: text("telegram_chat_id"),
	pairedAt: timestamp("paired_at", { withTimezone: true, mode: 'string' }),
	revokedAt: timestamp("revoked_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_manager_telegram_pairings_session_hash_fkey"
		}),
	unique("expert_manager_telegram_pairings_token_hash_key").on(table.tokenHash),
	check("expert_manager_telegram_pairings_check", sql`((telegram_user_id IS NULL) AND (telegram_chat_id IS NULL) AND (paired_at IS NULL)) OR ((telegram_user_id IS NOT NULL) AND (telegram_chat_id IS NOT NULL) AND (paired_at IS NOT NULL))`),
	check("expert_manager_telegram_pairings_expires_at_check", sql`CHECK (isfinite(expires_at`),
]);

export const expertManagerTelegramCallbacks = pgTable("expert_manager_telegram_callbacks", {
	profileRevision: integer("profile_revision"),
	id: uuid().defaultRandom().primaryKey().notNull(),
	pairingId: uuid("pairing_id").notNull(),
	applicationId: uuid("application_id").notNull(),
	decision: text().notNull(),
	nonceHash: text("nonce_hash").notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_manager_telegram_callbacks_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.pairingId],
			foreignColumns: [expertManagerTelegramPairings.id],
			name: "expert_manager_telegram_callbacks_pairing_id_fkey"
		}),
	unique("expert_manager_telegram_callbacks_nonce_hash_key").on(table.nonceHash),
	check("expert_manager_telegram_callbacks_decision_check", sql`decision = ANY (ARRAY['approved'::text, 'rejected'::text])`),
	check("expert_manager_telegram_callbacks_expires_at_check", sql`CHECK (isfinite(expires_at`),
]);

export const expertManagerTelegramNotifications = pgTable("expert_manager_telegram_notifications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	pairingId: uuid("pairing_id").notNull(),
	applicationId: uuid("application_id").notNull(),
	status: text().default('pending').notNull(),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	fence: uuid(),
	sentAt: timestamp("sent_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_manager_telegram_notifications_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.pairingId],
			foreignColumns: [expertManagerTelegramPairings.id],
			name: "expert_manager_telegram_notifications_pairing_id_fkey"
		}),
	unique("expert_manager_telegram_notificat_pairing_id_application_id_key").on(table.pairingId, table.applicationId),
	check("expert_manager_telegram_notifications_status_check", sql`status = ANY (ARRAY['pending'::text, 'sending'::text, 'sent'::text])`),
]);

export const expertApplicationPromoConfirmations = pgTable("expert_application_promo_confirmations", {
	id: uuid().defaultRandom().notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	applicationId: uuid("application_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	proofDigest: text("proof_digest").notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [expertOnboardingApplications.id, expertOnboardingApplications.userId],
			name: "expert_application_confirmation_owner_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_application_promo_confirmations_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_application_promo_confirmations_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_application_promo_confirmations_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_application_promo_confirmations_user_id_fkey"
		}),
	unique("expert_application_promo_confirmations_id_key").on(table.id),
	unique("expert_application_promo_confirm_manager_id_idempotency_key_key").on(table.idempotencyKey, table.managerId),
]);

export const expertPromoReadyLogs = pgTable("expert_promo_ready_logs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	event: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	check("expert_promo_ready_logs_event_check", sql`event = 'Ready to send'::text`),
]);

export const expertSpaceTariffApprovals = pgTable("expert_space_tariff_approvals", {
	tariffVersionId: uuid("tariff_version_id").primaryKey().notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_space_tariff_approvals_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_space_tariff_approvals_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_space_tariff_approvals_tariff_version_id_fkey"
		}),
]);

export const expertApplicationMaterialJobs = pgTable("expert_application_material_jobs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	status: text().default('waiting_content').notNull(),
	targetBotId: text("target_bot_id"),
	targetBotKey: text("target_bot_key"),
	targetChatId: text("target_chat_id"),
	templateId: uuid("template_id"),
	contentVersion: text("content_version"),
	payloadDigest: text("payload_digest"),
	deliveryReceipt: jsonb("delivery_receipt"),
	attemptId: uuid("attempt_id"),
	expectedMessageCount: integer("expected_message_count"),
	deliveredAt: timestamp("delivered_at", { withTimezone: true, mode: 'string' }),
	attemptStartedAt: timestamp("attempt_started_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_application_material_jobs_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.templateId],
			foreignColumns: [expertCardMaterialTemplates.id],
			name: "expert_application_material_jobs_template_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_application_material_jobs_user_id_fkey"
		}),
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [expertOnboardingApplications.id, expertOnboardingApplications.userId],
			name: "expert_application_material_owner_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.templateId, table.contentVersion],
			foreignColumns: [expertCardMaterialTemplates.id, expertCardMaterialTemplates.contentVersion],
			name: "expert_application_material_template_fk"
		}),
	unique("expert_application_material_jobs_application_id_key").on(table.applicationId),
	check("expert_application_material_attempt", sql`CHECK (COALESCE((((attempt_id IS NULL) AND (attempt_started_at IS NULL)) OR ((attempt_id IS NOT NULL) AND (attempt_started_at IS NOT NULL) AND isfinite(attempt_started_at))), false`),
	check("expert_application_material_jobs_status_check", sql`status = ANY (ARRAY['waiting_content'::text, 'pending'::text, 'delivered'::text, 'unknown_outcome'::text, 'cancelled'::text])`),
	check("expert_application_material_receipt", sql`CHECK (COALESCE((((status = 'delivered'::text) AND (template_id IS NOT NULL) AND (content_version IS NOT NULL) AND (delivered_at IS NOT NULL) AND isfinite(delivered_at) AND (attempt_id IS NOT NULL) AND (payload_digest IS NOT NULL) AND (payload_digest ~ '^sha256:[0-9a-f]{64}$'::text) AND expert_card_delivery_receipt_valid(delivery_receipt, target_bot_id, target_chat_id, content_version, payload_digest, expected_message_count)) OR ((status <> 'delivered'::text) AND (delivery_receipt IS NULL) AND (delivered_at IS NULL))), false`),
]);

export const expertApplicationPromoProofs = pgTable("expert_application_promo_proofs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	kind: text().notNull(),
	reference: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_application_promo_proofs_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_application_promo_proofs_user_id_fkey"
		}),
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [expertOnboardingApplications.id, expertOnboardingApplications.userId],
			name: "expert_application_proof_owner_fk"
		}).onDelete("cascade"),
	check("expert_application_promo_proofs_kind_check", sql`kind = ANY (ARRAY['link'::text, 'photo'::text, 'document'::text])`),
	check("expert_application_proof_value", sql`CHECK (COALESCE((((kind = 'link'::text) AND ((length(reference) >= 1) AND (length(reference) <= 2048)) AND (reference ~~ 'https://%'::text)) OR ((kind = ANY (ARRAY['photo'::text, 'document'::text])) AND ((char_length(reference) >= 15) AND (char_length(reference) <= 526)) AND (reference ~ '^telegram:file:[A-Za-z0-9_-]+$'::text))), false`),
]);

export const expertMainActivationAdmissions = pgTable("expert_main_activation_admissions", {
	orderId: uuid("order_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	quoteId: uuid("quote_id").notNull(),
	profileRevision: integer("profile_revision"),
	applicationAuditId: uuid("application_audit_id").notNull(),
	reviewAuditId: uuid("review_audit_id").notNull(),
	publicDigest: text("public_digest").notNull(),
	providerEventId: uuid("provider_event_id").notNull(),
	admittedAt: timestamp("admitted_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "expert_main_activation_admissions_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_main_activation_admissions_order_id_fkey"
		}),
	foreignKey({
			columns: [table.providerEventId],
			foreignColumns: [expertResidencyProviderEventInbox.id],
			name: "expert_main_activation_admissions_provider_event_id_fkey"
		}),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_main_activation_admissions_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_main_activation_admissions_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.profileRevision],
			foreignColumns: [expertOfferProfiles.userId, expertOfferProfiles.revision],
			name: "expert_main_admission_profile_fk"
		}),
	unique("expert_main_activation_admissions_provider_event_id_key").on(table.providerEventId),
	check("expert_main_activation_admissions_admitted_at_check", sql`CHECK (isfinite(admitted_at`),
	check("expert_main_activation_admissions_profile_revision_check", sql`profile_revision > 0`),
	check("expert_main_activation_admissions_public_digest_check", sql`public_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
]);

export const residentVerificationCohorts = pgTable("resident_verification_cohorts", {
	userId: uuid("user_id").primaryKey().notNull(),
	enrolledAt: timestamp("enrolled_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_verification_cohorts_user_id_fkey"
		}),
]);

export const hashtagsDb = pgTable("hashtags_db", {
	id: uuid().primaryKey().notNull(),
	parentCategory: text("parent_category").notNull(),
	subCategory: text("sub_category").notNull(),
	tagValue: text("tag_value").notNull(),
	displayLabel: text("display_label").notNull(),
	synonymsJson: jsonb("synonyms_json").notNull(),
	weightScore: integer("weight_score").default(5).notNull(),
	isActive: boolean("is_active").default(true).notNull(),
	sourceSha256: text("source_sha256").default('f5211313189e3d3074a761868693796e93bb160c01d87f3d2989bac48b2ab75e').notNull(),
	synonymProvenance: jsonb("synonym_provenance").default([]).notNull(),
}, (table) => [
	unique("hashtags_db_tag_value_key").on(table.tagValue),
	check("hashtags_db_source", sql`source_sha256 ~ '^[0-9a-f]{64}$'::text`),
	check("hashtags_db_synonyms", sql`CHECK (hashtags_synonyms_valid(synonyms_json`),
	check("hashtags_db_value", sql`((length(tag_value) >= 1) AND (length(tag_value) <= 100)) AND ((length(display_label) >= 1) AND (length(display_label) <= 101)) AND ((length(parent_category) >= 1) AND (length(parent_category) <= 200)) AND ((length(sub_category) >= 1) AND (length(sub_category) <= 200))`),
	check("hashtags_db_weight", sql`(weight_score >= 1) AND (weight_score <= 10)`),
]);

export const residentVerificationCheckWork = pgTable("resident_verification_check_work", {
	applicationId: uuid("application_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	submittedRevision: integer("submitted_revision").notNull(),
	status: text().default('pending').notNull(),
	educationResult: text("education_result").default('unknown').notNull(),
	socialResult: text("social_result").default('pending').notNull(),
	uploadState: text("upload_state").default('pending_upload').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [residentsApplications.id, residentsApplications.userId],
			name: "resident_verification_check_work_application_id_user_id_fkey"
		}).onDelete("cascade"),
	check("resident_verification_check_work_education_result_check", sql`education_result = 'unknown'::text`),
	check("resident_verification_check_work_social_result_check", sql`social_result = 'pending'::text`),
	check("resident_verification_check_work_status_check", sql`status = ANY (ARRAY['pending'::text, 'cancelled'::text])`),
	check("resident_verification_check_work_submitted_revision_check", sql`submitted_revision > 0`),
	check("resident_verification_check_work_upload_state_check", sql`upload_state = 'pending_upload'::text`),
]);

export const expertSalesBases = pgTable("expert_sales_bases", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	tariffVersionId: uuid("tariff_version_id").notNull(),
	profileRevision: integer("profile_revision").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	baseTariffAmount: bigint("base_tariff_amount", { mode: "number" }).notNull(),
	baseOfferShownAt: timestamp("base_offer_shown_at", { withTimezone: true, mode: 'string' }).default(sql`date_trunc('milliseconds'::text, clock_timestamp())`).notNull(),
	participantKind: text("participant_kind").notNull(),
	policyVersion: text("policy_version").default('expert_separated_sales_v3').notNull(),
	botId: text("bot_id"),
	botKey: text("bot_key"),
	chatId: text("chat_id"),
	consentVersion: text("consent_version"),
}, (table) => [
	foreignKey({
			columns: [table.tariffVersionId],
			foreignColumns: [expertResidencyTariffVersions.id],
			name: "expert_sales_bases_tariff_version_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_sales_bases_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.profileRevision],
			foreignColumns: [expertOfferProfiles.userId, expertOfferProfiles.revision],
			name: "expert_sales_bases_user_id_profile_revision_fkey"
		}),
	unique("expert_sales_bases_id_user_id_key").on(table.id, table.userId),
	unique("expert_sales_bases_user_id_key").on(table.userId),
	check("expert_sales_bases_base_offer_shown_at_check", sql`CHECK (isfinite(base_offer_shown_at`),
	check("expert_sales_bases_base_tariff_amount_check", sql`(base_tariff_amount >= 0) AND (base_tariff_amount <= '999999999999'::bigint)`),
	check("expert_sales_bases_participant_kind_check", sql`participant_kind = ANY (ARRAY['expert'::text, 'space'::text])`),
	check("expert_sales_bases_policy_version_check", sql`policy_version = 'expert_separated_sales_v3'::text`),
]);

export const expertSalesFormBridges = pgTable("expert_sales_form_bridges", {
	applicationId: uuid("application_id").primaryKey().notNull(),
	formId: uuid("form_id").notNull(),
	userId: uuid("user_id").notNull(),
	submittedRevision: integer("submitted_revision").notNull(),
	selectionId: uuid("selection_id").notNull(),
	quoteId: uuid("quote_id").notNull(),
	submittedDigest: text("submitted_digest"),
	submittedAt: timestamp("submitted_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [expertOnboardingApplications.id],
			name: "expert_sales_form_bridges_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.formId, table.userId],
			foreignColumns: [residentsApplications.id, residentsApplications.userId],
			name: "expert_sales_form_bridges_form_id_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_sales_form_bridges_quote_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.selectionId],
			foreignColumns: [expertSalesSelections.id, expertSalesSelections.userId],
			name: "expert_sales_form_bridges_selection_id_user_id_fkey"
		}),
	unique("expert_sales_form_bridges_form_id_key").on(table.formId),
	check("expert_sales_submission_proof", sql`((submitted_digest IS NULL) AND (submitted_at IS NULL)) OR ((submitted_digest IS NOT NULL) AND (submitted_digest ~ '^[0-9a-f]{64}$'::text) AND (submitted_at IS NOT NULL) AND isfinite(submitted_at))`),
]);

export const expertSalesChoices = pgTable("expert_sales_choices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	baseId: uuid("base_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	action: text().notNull(),
	chosenAt: timestamp("chosen_at", { withTimezone: true, mode: 'string' }).default(sql`date_trunc('milliseconds'::text, clock_timestamp())`).notNull(),
	requestKey: text("request_key"),
	requestDigest: text("request_digest"),
}, (table) => [
	foreignKey({
			columns: [table.baseId, table.userId],
			foreignColumns: [expertSalesBases.id, expertSalesBases.userId],
			name: "expert_sales_choices_base_id_user_id_fkey"
		}),
	unique("expert_sales_choices_id_user_id_key").on(table.id, table.userId),
	unique("expert_sales_choices_base_id_revision_key").on(table.baseId, table.revision),
	unique("expert_sales_choices_base_id_request_key_key").on(table.baseId, table.requestKey),
	check("expert_sales_choices_action_check", sql`action = ANY (ARRAY['positive'::text, 'promo'::text, 'base'::text, 'month'::text, 'quarter'::text])`),
	check("expert_sales_choices_request_digest_check", sql`request_digest ~ '^[0-9a-f]{64}$'::text`),
	check("expert_sales_choices_revision_check", sql`revision > 0`),
]);

export const expertSalesSelections = pgTable("expert_sales_selections", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	baseId: uuid("base_id").notNull(),
	userId: uuid("user_id").notNull(),
	choiceId: uuid("choice_id").notNull(),
	promoAcceptedFlag: boolean("promo_accepted_flag").notNull(),
	termMonths: integer("term_months").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	monthlyPriceMinor: bigint("monthly_price_minor", { mode: "number" }).notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	packagePriceMinor: bigint("package_price_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	selectedTotalMinor: bigint("selected_total_minor", { mode: "number" }).notNull(),
	energyDiscountBps: integer("energy_discount_bps").notNull(),
	packageDiscountBps: integer("package_discount_bps").notNull(),
	selectedAt: timestamp("selected_at", { withTimezone: true, mode: 'string' }).default(sql`date_trunc('milliseconds'::text, clock_timestamp())`).notNull(),
	offerExpiryDate: timestamp("offer_expiry_date", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	uniqueIndex("expert_sales_selection_clock_once").using("btree", table.choiceId.asc().nullsLast().op("timestamptz_ops"), table.selectedAt.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.baseId, table.userId],
			foreignColumns: [expertSalesBases.id, expertSalesBases.userId],
			name: "expert_sales_selections_base_id_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.choiceId],
			foreignColumns: [expertSalesChoices.id, expertSalesChoices.userId],
			name: "expert_sales_selections_choice_id_user_id_fkey"
		}),
	unique("expert_sales_selections_id_user_id_key").on(table.id, table.userId),
	check("expert_sales_selections_check", sql`isfinite(selected_at) AND isfinite(offer_expiry_date) AND (selected_at < offer_expiry_date)`),
	check("expert_sales_selections_check1", sql`((term_months = 1) AND (selected_total_minor = monthly_price_minor)) OR ((term_months = 3) AND (package_price_minor IS NOT NULL) AND (selected_total_minor = package_price_minor) AND (package_price_minor >= 1500000))`),
	check("expert_sales_selections_monthly_price_minor_check", sql`monthly_price_minor >= 500000`),
	check("expert_sales_selections_selected_total_minor_check", sql`(selected_total_minor >= 500000) AND (selected_total_minor <= '999999999999'::bigint)`),
	check("expert_sales_selections_term_months_check", sql`term_months = ANY (ARRAY[1, 3])`),
]);

export const expertSalesFeeAttempts = pgTable("expert_sales_fee_attempts", {
	invoiceId: uuid("invoice_id").primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	selectionId: uuid("selection_id").notNull(),
	policyVersion: text("policy_version").default('expert_separated_sales_v3').notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertOnboardingInvoices.id],
			name: "expert_sales_fee_attempts_invoice_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.selectionId],
			foreignColumns: [expertSalesSelections.id, expertSalesSelections.userId],
			name: "expert_sales_fee_attempts_selection_id_user_id_fkey"
		}),
	check("expert_sales_fee_attempts_check", sql`isfinite(expires_at) AND isfinite(created_at) AND (expires_at > created_at)`),
	check("expert_sales_fee_attempts_policy_version_check", sql`policy_version = 'expert_separated_sales_v3'::text`),
]);

export const expertSalesPaidLocks = pgTable("expert_sales_paid_locks", {
	userId: uuid("user_id").primaryKey().notNull(),
	invoiceId: uuid("invoice_id").notNull(),
	selectionId: uuid("selection_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	finalLockedPrice: bigint("final_locked_price", { mode: "number" }).notNull(),
	termMonths: integer("term_months").notNull(),
	lockedAt: timestamp("locked_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertOnboardingPaymentFacts.invoiceId],
			name: "expert_sales_paid_locks_invoice_id_fkey"
		}),
	foreignKey({
			columns: [table.userId, table.selectionId],
			foreignColumns: [expertSalesSelections.id, expertSalesSelections.userId],
			name: "expert_sales_paid_locks_selection_id_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_sales_paid_locks_user_id_fkey"
		}),
	unique("expert_sales_paid_locks_invoice_id_key").on(table.invoiceId),
	check("expert_sales_paid_locks_check", sql`((final_locked_price >= 500000) AND (final_locked_price <= '999999999999'::bigint)) AND (term_months = ANY (ARRAY[1, 3]))`),
]);

export const expertSalesRecoveryWork = pgTable("expert_sales_recovery_work", {
	invoiceId: uuid("invoice_id").primaryKey().notNull(),
	reason: text().notNull(),
	status: text().default('refund_review').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertOnboardingPaymentFacts.invoiceId],
			name: "expert_sales_recovery_work_invoice_id_fkey"
		}),
	check("expert_sales_recovery_work_reason_check", sql`reason = ANY (ARRAY['expired_terms'::text, 'duplicate_fee'::text, 'capture_unproven'::text, 'application_erased'::text, 'owner_inactive'::text, 'consent_unavailable'::text, 'application_unavailable'::text])`),
	check("expert_sales_recovery_work_status_check", sql`status = 'refund_review'::text`),
]);

export const expertSalesProviderRequests = pgTable("expert_sales_provider_requests", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	invoiceId: uuid("invoice_id").notNull(),
	kind: text().notNull(),
	idempotencyKey: uuid("idempotency_key").notNull(),
	requestBody: text("request_body"),
	encryptedBody: text("encrypted_body"),
	keyReference: text("key_reference"),
	requestDigest: text("request_digest").notNull(),
	bodyExpiresAt: timestamp("body_expires_at", { withTimezone: true, mode: 'string' }),
	contactId: uuid("contact_id"),
	status: text().default('prepared').notNull(),
	providerObjectId: text("provider_object_id"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	dispatchedAt: timestamp("dispatched_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	foreignKey({
			columns: [table.contactId],
			foreignColumns: [payerReceiptContacts.id],
			name: "expert_sales_provider_requests_contact_id_fkey"
		}),
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertSalesFeeAttempts.invoiceId],
			name: "expert_sales_provider_requests_invoice_id_fkey"
		}),
	unique("expert_sales_provider_requests_invoice_id_kind_key").on(table.invoiceId, table.kind),
	unique("expert_sales_provider_requests_idempotency_key_key").on(table.idempotencyKey),
	check("expert_sales_provider_requests_body_expires_at_check", sql`(body_expires_at IS NULL) OR isfinite(body_expires_at)`),
	check("expert_sales_provider_requests_check", sql`((kind = 'create'::text) AND (request_body IS NULL) AND (contact_id IS NOT NULL)) OR ((kind = 'capture'::text) AND (request_body = '{"amount":{"value":"3000.00","currency":"RUB"}}'::text) AND (contact_id IS NULL)) OR ((kind = 'cancel'::text) AND (request_body = '{}'::text) AND (contact_id IS NULL))`),
	check("expert_sales_provider_requests_check1", sql`(encrypted_body IS NULL) = (key_reference IS NULL)`),
	check("expert_sales_provider_requests_kind_check", sql`kind = ANY (ARRAY['create'::text, 'capture'::text, 'cancel'::text])`),
	check("expert_sales_provider_requests_request_digest_check", sql`request_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_sales_provider_requests_status_check", sql`status = ANY (ARRAY['prepared'::text, 'dispatched'::text, 'observed'::text, 'cancelled'::text])`),
]);

export const expertSalesProviderObservations = pgTable("expert_sales_provider_observations", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	invoiceId: uuid("invoice_id").notNull(),
	providerObjectId: text("provider_object_id").notNull(),
	status: text().notNull(),
	evidenceDigest: text("evidence_digest").notNull(),
	observedAt: timestamp("observed_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertSalesFeeAttempts.invoiceId],
			name: "expert_sales_provider_observations_invoice_id_fkey"
		}),
	check("expert_sales_provider_observations_evidence_digest_check", sql`evidence_digest ~ '^sha256:[0-9a-f]{64}$'::text`),
	check("expert_sales_provider_observations_status_check", sql`status = ANY (ARRAY['pending'::text, 'waiting_for_capture'::text, 'succeeded'::text, 'canceled'::text])`),
]);

export const expertSalesErasedCohorts = pgTable("expert_sales_erased_cohorts", {
	userId: uuid("user_id").primaryKey().notNull(),
	erasedAt: timestamp("erased_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_sales_erased_cohorts_user_id_fkey"
		}),
]);

export const expertSalesTicks = pgTable("expert_sales_ticks", {
	baseId: uuid("base_id").primaryKey().notNull(),
	checkedAt: timestamp("checked_at", { withTimezone: true, mode: 'string' }).default(sql`'-infinity'`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.baseId],
			foreignColumns: [expertSalesBases.id],
			name: "expert_sales_ticks_base_id_fkey"
		}),
]);

export const expertSalesNotices = pgTable("expert_sales_notices", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	baseId: uuid("base_id").notNull(),
	stageAt: timestamp("stage_at", { withTimezone: true, mode: 'string' }).notNull(),
	kind: text().notNull(),
	status: text().default('pending').notNull(),
	attemptId: uuid("attempt_id"),
	receipt: jsonb(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	selectionId: uuid("selection_id"),
	invoiceId: uuid("invoice_id"),
	choiceRevision: integer("choice_revision"),
	preparedUntil: timestamp("prepared_until", { withTimezone: true, mode: 'string' }),
}, (table) => [
	uniqueIndex("expert_sales_replacement_notice_once").using("btree", table.invoiceId.asc().nullsLast().op("uuid_ops")).where(sql`((kind = 'refresh'::text) AND (invoice_id IS NOT NULL))`),
	uniqueIndex("expert_sales_selection_notice_once").using("btree", table.selectionId.asc().nullsLast().op("uuid_ops"), table.kind.asc().nullsLast().op("uuid_ops")).where(sql`((kind = ANY (ARRAY['refresh'::text, 'reselect'::text])) AND (invoice_id IS NULL) AND (selection_id IS NOT NULL))`),
	uniqueIndex("expert_sales_stage_notice_once").using("btree", table.baseId.asc().nullsLast().op("text_ops"), table.stageAt.asc().nullsLast().op("text_ops"), table.kind.asc().nullsLast().op("timestamptz_ops"), table.choiceRevision.asc().nullsLast().op("int4_ops")).where(sql`(kind = ANY (ARRAY['24h'::text, '3h'::text]))`),
	foreignKey({
			columns: [table.baseId],
			foreignColumns: [expertSalesBases.id],
			name: "expert_sales_notices_base_id_fkey"
		}),
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertOnboardingInvoices.id],
			name: "expert_sales_notices_invoice_id_fkey"
		}),
	foreignKey({
			columns: [table.selectionId],
			foreignColumns: [expertSalesSelections.id],
			name: "expert_sales_notices_selection_id_fkey"
		}),
	check("expert_sales_notices_check", sql`(receipt IS NULL) OR (status = 'delivered'::text)`),
	check("expert_sales_notices_kind_check", sql`kind = ANY (ARRAY['refresh'::text, '24h'::text, '3h'::text, 'reselect'::text])`),
	check("expert_sales_notices_status_check", sql`status = ANY (ARRAY['pending'::text, 'preparing'::text, 'dispatched'::text, 'delivered'::text, 'cancelled'::text])`),
]);

export const expertSalesOperatorRecoveries = pgTable("expert_sales_operator_recoveries", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	invoiceId: uuid("invoice_id").notNull(),
	userId: uuid("user_id").notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	requestKey: text("request_key").notNull(),
	providerObjectId: text("provider_object_id").notNull(),
	observedStatus: text("observed_status").notNull(),
	evidenceDigest: text("evidence_digest").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.invoiceId],
			foreignColumns: [expertSalesFeeAttempts.invoiceId],
			name: "expert_sales_operator_recoveries_invoice_id_fkey"
		}),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_sales_operator_recoveries_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_sales_operator_recoveries_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_sales_operator_recoveries_user_id_fkey"
		}),
	unique("expert_sales_operator_recoveries_manager_id_request_key_key").on(table.managerId, table.requestKey),
	check("expert_sales_operator_recoveries_request_key_check", sql`request_key ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{7,127}$'::text`),
]);

export const residentSafetyPublications = pgTable("resident_safety_publications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	policyId: uuid("policy_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	generation: bigint({ mode: "number" }).generatedAlwaysAsIdentity({ name: "resident_safety_publications_generation_seq", startWith: 1, increment: 1, minValue: 1, maxValue: 9223372036854775807, cache: 1 }),
	managerId: uuid("manager_id"),
	managerSessionHash: text("manager_session_hash"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	transactionId: bigint("transaction_id", { mode: "number" }).default(sql`txid_current()`).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_safety_publications_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.managerSessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "resident_safety_publications_manager_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [residentSafetyPolicies.id],
			name: "resident_safety_publications_policy_id_fkey"
		}),
	unique("resident_safety_publications_generation_key").on(table.generation),
]);

export const residentSafetyPolicies = pgTable("resident_safety_policies", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	engine: text().default('resident_safe_regex_v1').notNull(),
	publishedAt: timestamp("published_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	firstPublicationId: uuid("first_publication_id"),
}, (table) => [
	foreignKey({
			columns: [table.firstPublicationId],
			foreignColumns: [residentSafetyPublications.id],
			name: "resident_safety_policies_first_publication_id_fkey"
		}),
]);

export const forbiddenPatterns = pgTable("forbidden_patterns", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	policyId: uuid("policy_id").notNull(),
	patternRegex: text("pattern_regex").notNull(),
	category: text().notNull(),
	severityLevel: text("severity_level").notNull(),
	errorMessageTemplate: text("error_message_template").notNull(),
	isActive: boolean("is_active").default(true).notNull(),
	compiled: jsonb(),
	provenance: text().notNull(),
	positiveWitness: text("positive_witness").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [residentSafetyPolicies.id],
			name: "forbidden_patterns_policy_id_fkey"
		}),
	check("forbidden_patterns_category_check", sql`category = ANY (ARRAY['MEDICAL_CLAIM'::text, 'FINANCIAL_GUARANTEE'::text, 'POLITICAL_RELIGIOUS'::text, 'HATE_SPEECH'::text, 'SPAM_SCAM'::text])`),
	check("forbidden_patterns_error_message_template_check", sql`(length(error_message_template) >= 1) AND (length(error_message_template) <= 1000)`),
	check("forbidden_patterns_severity_level_check", sql`severity_level = ANY (ARRAY['BLOCKER'::text, 'WARNING'::text])`),
]);

export const residentSafetyActive = pgTable("resident_safety_active", {
	id: integer().primaryKey().notNull(),
	policyId: uuid("policy_id").notNull(),
	publicationId: uuid("publication_id").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [residentSafetyPolicies.id],
			name: "resident_safety_active_policy_id_fkey"
		}),
	foreignKey({
			columns: [table.publicationId],
			foreignColumns: [residentSafetyPublications.id],
			name: "resident_safety_active_publication_id_fkey"
		}),
	check("resident_safety_active_id_check", sql`id = 1`),
]);

export const residentCardCorrections = pgTable("resident_card_corrections", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	entryId: uuid("entry_id").notNull(),
	revision: integer().notNull(),
	textContent: text("text_content").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_card_corrections_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.entryId],
			foreignColumns: [expertCardEntries.id],
			name: "resident_card_corrections_entry_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_card_corrections_user_id_fkey"
		}),
	unique("resident_card_corrections_draft_id_revision_key").on(table.draftId, table.revision),
	check("resident_card_corrections_revision_check", sql`revision > 0`),
	check("resident_card_corrections_text_content_check", sql`(length(text_content) >= 1) AND (length(text_content) <= 4000)`),
]);

export const residentSafetyOutcomes = pgTable("resident_safety_outcomes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	draftId: uuid("draft_id").notNull(),
	requestKey: text("request_key").notNull(),
	blocked: boolean().notNull(),
	policyId: uuid("policy_id").notNull(),
	revision: integer().notNull(),
	issues: jsonb().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_safety_outcomes_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [residentSafetyPolicies.id],
			name: "resident_safety_outcomes_policy_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_safety_outcomes_user_id_fkey"
		}),
	unique("resident_safety_outcomes_user_id_request_key_key").on(table.userId, table.requestKey),
]);

export const securityLogs = pgTable("security_logs", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	draftId: uuid("draft_id").notNull(),
	outcomeId: uuid("outcome_id").notNull(),
	fieldName: text("field_name").notNull(),
	matchedPatternId: uuid("matched_pattern_id"),
	policyId: uuid("policy_id").notNull(),
	revision: integer().notNull(),
	actionTaken: text("action_taken").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "security_logs_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.matchedPatternId],
			foreignColumns: [forbiddenPatterns.id],
			name: "security_logs_matched_pattern_id_fkey"
		}),
	foreignKey({
			columns: [table.outcomeId],
			foreignColumns: [residentSafetyOutcomes.id],
			name: "security_logs_outcome_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.policyId],
			foreignColumns: [residentSafetyPolicies.id],
			name: "security_logs_policy_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "security_logs_user_id_fkey"
		}),
	check("security_logs_action_taken_check", sql`action_taken = ANY (ARRAY['Blocked'::text, 'Warned'::text])`),
]);

export const residentCardProposalChanges = pgTable("resident_card_proposal_changes", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	previousProposal: jsonb("previous_proposal").notNull(),
	replacementProposal: jsonb("replacement_proposal"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_card_proposal_changes_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_card_proposal_changes_user_id_fkey"
		}),
	unique("resident_card_proposal_changes_draft_id_revision_key").on(table.draftId, table.revision),
	check("resident_card_proposal_changes_revision_check", sql`revision > 0`),
]);

export const residentsApplications = pgTable("residents_applications", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	userId: uuid("user_id").notNull(),
	botId: text("bot_id").notNull(),
	botKey: text("bot_key").notNull(),
	channelIdentityId: uuid("channel_identity_id").notNull(),
	telegramUserId: text("telegram_user_id").notNull(),
	chatId: text("chat_id").notNull(),
	revision: integer().default(0).notNull(),
	formVersion: integer("form_version").default(2).notNull(),
	policyVersion: text("policy_version").default('resident_form_v2').notNull(),
	educationRequirement: text("education_requirement").default('optional').notNull(),
	draft: jsonb().default({}).notNull(),
	roleType: text("role_type").generatedAlwaysAs(sql`(draft ->> 'primaryRole'::text)`),
	targetCategory: text("target_category").generatedAlwaysAs(sql`(draft ->> 'category'::text)`),
	taxStatus: text("tax_status").generatedAlwaysAs(sql`(draft ->> 'tax'::text)`),
	locationCity: text("location_city").generatedAlwaysAs(sql`(draft ->> 'city'::text)`),
	socialLinksJson: jsonb("social_links_json").generatedAlwaysAs(sql`resident_verification_social_projection((draft -> 'socialLinks'::text))`),
	motivationText: text("motivation_text").generatedAlwaysAs(sql`(draft ->> 'motivation'::text)`),
	educationRefsJson: jsonb("education_refs_json").generatedAlwaysAs(sql`(draft -> 'education'::text)`),
	propertyRefsJson: jsonb("property_refs_json").generatedAlwaysAs(sql`(draft -> 'propertyEvidence'::text)`),
	systemCheckResult: jsonb("system_check_result").default({"social":"pending","upload":"pending_upload","education":"unknown"}).notNull(),
	managerNotes: text("manager_notes"),
	currentField: text("current_field"),
	status: text().default('PENDING_DOCS').notNull(),
	progress: text().default('FORM_FILLING').notNull(),
	submittedDraft: jsonb("submitted_draft"),
	submittedAt: timestamp("submitted_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	isCurrent: boolean("is_current").default(true).notNull(),
	attemptNumber: integer("attempt_number").default(1).notNull(),
	submittedRevision: integer("submitted_revision"),
	checkGeneration: integer("check_generation").default(0).notNull(),
	activeRequestId: uuid("active_request_id"),
}, (table) => [
	uniqueIndex("resident_verification_current_owner").using("btree", table.userId.asc().nullsLast().op("uuid_ops")).where(sql`is_current`),
	uniqueIndex("resident_verification_owner_attempt").using("btree", table.userId.asc().nullsLast().op("int4_ops"), table.attemptNumber.asc().nullsLast().op("uuid_ops")),
	index("residents_application_role_status_idx").using("btree", table.roleType.asc().nullsLast().op("text_ops"), table.status.asc().nullsLast().op("text_ops")),
	index("residents_application_telegram_idx").using("btree", table.botId.asc().nullsLast().op("text_ops"), table.botKey.asc().nullsLast().op("text_ops"), table.telegramUserId.asc().nullsLast().op("text_ops")),
	foreignKey({
			columns: [table.userId, table.channelIdentityId],
			foreignColumns: [channelIdentities.id, channelIdentities.userId],
			name: "residents_applications_channel_identity_id_user_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "residents_applications_user_id_fkey"
		}).onDelete("cascade"),
	unique("residents_applications_id_user_id_key").on(table.id, table.userId),
	check("resident_verification_submission", sql`((submitted_at IS NULL) AND (submitted_draft IS NULL) AND (status = 'PENDING_DOCS'::text) AND (progress = 'FORM_FILLING'::text)) OR ((submitted_at IS NOT NULL) AND isfinite(submitted_at) AND (submitted_draft IS NOT NULL) AND resident_verification_version_valid(submitted_draft, form_version, true, education_requirement) AND (status <> 'PENDING_DOCS'::text))`),
	check("residents_applications_attempt_number_check", sql`attempt_number > 0`),
	check("residents_applications_bot_id_check", sql`bot_id ~ '^[1-9][0-9]{0,15}$'::text`),
	check("residents_applications_bot_key_check", sql`(length(bot_key) >= 1) AND (length(bot_key) <= 128)`),
	check("residents_applications_check", sql`chat_id = telegram_user_id`),
	check("residents_applications_check_generation_check", sql`check_generation >= 0`),
	check("residents_applications_current_field_check", sql`current_field = ANY (ARRAY['roles'::text, 'primaryRole'::text, 'category'::text, 'tax'::text, 'city'::text, 'socialLinks'::text, 'motivation'::text, 'specialization'::text, 'averageCheckMinor'::text, 'education'::text, 'propertyEvidence'::text, 'capacity'::text, 'amenities'::text, 'path'::text, 'cases'::text, 'methods'::text, 'experienceYears'::text, 'premisesType'::text, 'tourMedia'::text, 'eventFormat'::text, 'programme'::text, 'speakers'::text, 'pastEvents'::text, 'projectName'::text, 'licence'::text, 'teachingTeam'::text, 'graduateReviews'::text])`),
	check("residents_applications_draft_check", sql`CHECK (resident_verification_version_valid(draft, form_version`),
	check("residents_applications_education_requirement_check", sql`education_requirement = ANY (ARRAY['required'::text, 'optional'::text, 'unknown_manual_review'::text])`),
	check("residents_applications_form_version_check", sql`form_version = ANY (ARRAY[1, 2])`),
	check("residents_applications_manager_notes_check", sql`manager_notes IS NULL`),
	check("residents_applications_policy_version_check", sql`policy_version ~ '^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$'::text`),
	check("residents_applications_progress_check", sql`progress = ANY (ARRAY['NONE'::text, 'FORM_FILLING'::text, 'AUTO_CHECK'::text, 'MANAGER_REVIEW'::text, 'DONE'::text])`),
	check("residents_applications_revision_check", sql`revision >= 0`),
	check("residents_applications_status_check", sql`status = ANY (ARRAY['PENDING_DOCS'::text, 'UNDER_REVIEW'::text, 'INFO_REQUESTED'::text, 'APPROVED_BASIC'::text, 'APPROVED_EXCLUSIVE'::text, 'REJECTED'::text])`),
	check("residents_applications_system_check_result_check", sql`system_check_result = '{"social": "pending", "upload": "pending_upload", "education": "unknown"}'::jsonb`),
	check("residents_applications_telegram_user_id_check", sql`telegram_user_id ~ '^[1-9][0-9]{0,19}$'::text`),
]);

export const residentReviewPreviews = pgTable("resident_review_previews", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	revision: integer().notNull(),
	generation: integer().notNull(),
	templateKey: text("template_key").notNull(),
	templateVersion: integer("template_version").notNull(),
	action: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	questions: jsonb().default([]).notNull(),
	finalText: text("final_text").notNull(),
	finalHash: text("final_hash").notNull(),
	variables: jsonb().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(clock_timestamp() + '00:05:00'::interval)`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_review_previews_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_review_previews_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "resident_review_previews_session_hash_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_review_previews_user_id_fkey"
		}),
	unique("resident_review_previews_id_application_id_key").on(table.id, table.applicationId),
	check("resident_review_previews_action_check", sql`action = ANY (ARRAY['APPROVED_BASIC'::text, 'APPROVED_EXCLUSIVE'::text, 'REJECT_SOFT'::text, 'REJECT_HARD'::text, 'INFO_REQUESTED'::text])`),
	check("resident_review_previews_check", sql`final_hash = encode(digest(final_text, 'sha256'::text), 'hex'::text)`),
	check("resident_review_previews_final_text_check", sql`(octet_length(final_text) <= 12000) AND (length(final_text) <= 4096)`),
	check("resident_review_previews_questions_check", sql`(jsonb_typeof(questions) = 'array'::text) AND (jsonb_array_length(questions) <= 10)`),
]);

export const residentReviewEvents = pgTable("resident_review_events", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	attemptId: uuid("attempt_id").notNull(),
	previewId: uuid("preview_id").notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	sourceRevision: integer("source_revision").notNull(),
	sourceGeneration: integer("source_generation").notNull(),
	submittedRevision: integer("submitted_revision").notNull(),
	submittedDigest: text("submitted_digest").notNull(),
	action: text().notNull(),
	reasonCode: text("reason_code").notNull(),
	templateKey: text("template_key").notNull(),
	templateVersion: integer("template_version").notNull(),
	finalHash: text("final_hash").notNull(),
	deadline: timestamp({ withTimezone: true, mode: 'string' }),
	reapplyAt: timestamp("reapply_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_review_events_manager_id_fkey"
		}),
	unique("resident_review_events_preview_id_key").on(table.previewId),
	check("resident_review_events_final_hash_check", sql`final_hash ~ '^[0-9a-f]{64}$'::text`),
]);

export const residentInformationRequests = pgTable("resident_information_requests", {
	id: uuid().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	questions: jsonb().notNull(),
	deadline: timestamp({ withTimezone: true, mode: 'string' }).notNull(),
	status: text().default('open').notNull(),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("resident_information_requests_due").using("btree", table.deadline.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(status = 'open'::text)`),
	index("resident_information_requests_history").using("btree", table.applicationId.asc().nullsLast().op("uuid_ops"), table.id.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_information_requests_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.id],
			foreignColumns: [residentReviewEvents.id],
			name: "resident_information_requests_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_information_requests_user_id_fkey"
		}),
	check("resident_information_requests_questions_check", sql`(jsonb_typeof(questions) = 'array'::text) AND ((jsonb_array_length(questions) >= 1) AND (jsonb_array_length(questions) <= 10))`),
	check("resident_information_requests_status_check", sql`status = ANY (ARRAY['open'::text, 'completed'::text, 'timeout'::text, 'superseded'::text])`),
]);

export const residentReviewMessages = pgTable("resident_review_messages", {
	eventId: uuid("event_id").primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	consentVersion: text("consent_version").notNull(),
	finalText: text("final_text").notNull(),
	finalHash: text("final_hash").notNull(),
	status: text().default('pending').notNull(),
	attempts: integer().default(0).notNull(),
	receipt: text(),
	dispatchedAt: timestamp("dispatched_at", { withTimezone: true, mode: 'string' }),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	index("resident_review_messages_history").using("btree", table.applicationId.asc().nullsLast().op("uuid_ops"), table.eventId.asc().nullsLast().op("uuid_ops")),
	index("resident_review_messages_pending").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")).where(sql`(status = 'pending'::text)`),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_review_messages_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.eventId],
			foreignColumns: [residentReviewEvents.id],
			name: "resident_review_messages_event_id_fkey"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_review_messages_user_id_fkey"
		}),
	check("resident_review_messages_attempts_check", sql`(attempts >= 0) AND (attempts <= 3)`),
	check("resident_review_messages_check", sql`final_hash = encode(digest(final_text, 'sha256'::text), 'hex'::text)`),
	check("resident_review_messages_status_check", sql`status = ANY (ARRAY['pending'::text, 'dispatched'::text, 'delivered'::text, 'cancelled'::text, 'unknown'::text])`),
]);

export const residentVerificationApplicationUpdates = pgTable("resident_verification_application_updates", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	kind: text().notNull(),
	answers: jsonb().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	requestId: uuid("request_id"),
	questionNumber: integer("question_number"),
}, (table) => [
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [residentsApplications.id, residentsApplications.userId],
			name: "resident_verification_application_u_application_id_user_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [residentInformationRequests.id],
			name: "resident_verification_application_updates_request_id_fkey"
		}).onDelete("cascade"),
	unique("resident_verification_application_u_application_id_revision_key").on(table.applicationId, table.revision),
	check("resident_verification_application_updates_answers_check", sql`(jsonb_typeof(answers) = 'object'::text) AND (octet_length((answers)::text) <= 100000)`),
	check("resident_verification_application_updates_kind_check", sql`kind = ANY (ARRAY['patch'::text, 'submit'::text, 'followup'::text, 'question'::text])`),
	check("resident_verification_application_updates_question_number_check", sql`(question_number >= 1) AND (question_number <= 10)`),
	check("resident_verification_application_updates_revision_check", sql`revision > 0`),
	check("resident_verification_followup_check", sql`(kind <> 'followup'::text) OR resident_verification_followup_valid(answers)`),
]);

export const residentReviewRecoveries = pgTable("resident_review_recoveries", {
	eventId: uuid("event_id").primaryKey().notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	action: text().default('closed_without_resend').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.eventId],
			foreignColumns: [residentReviewEvents.id],
			name: "resident_review_recoveries_event_id_fkey"
		}),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_review_recoveries_manager_id_fkey"
		}),
	check("resident_review_recoveries_action_check", sql`action = 'closed_without_resend'::text`),
]);

export const expertCardDrafts = pgTable("expert_card_drafts", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().default(0).notNull(),
	status: text().default('collecting').notNull(),
	publicPayload: jsonb("public_payload"),
	approvedReviewId: uuid("approved_review_id"),
	messagingPolicyVersion: text("messaging_policy_version").notNull(),
	workBotId: text("work_bot_id").notNull(),
	workBotKey: text("work_bot_key").notNull(),
	workChatId: text("work_chat_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	inputMode: text("input_mode").default('INTERVIEW').notNull(),
	documentProposal: jsonb("document_proposal"),
	documentImportRevision: integer("document_import_revision"),
	richMode: boolean("rich_mode").default(false).notNull(),
	richProfile: jsonb("rich_profile"),
	richProposal: jsonb("rich_proposal"),
	richGuided: jsonb("rich_guided").default({}).notNull(),
	ownerConfirmedDigest: text("owner_confirmed_digest"),
	previewPage: integer("preview_page"),
	previewTokenDigest: text("preview_token_digest"),
	previewContentDigest: text("preview_content_digest"),
	assistanceRequestedAt: timestamp("assistance_requested_at", { withTimezone: true, mode: 'string' }),
	assistanceRevision: integer("assistance_revision"),
	assistanceResolvedAt: timestamp("assistance_resolved_at", { withTimezone: true, mode: 'string' }),
	richPendingServices: jsonb("rich_pending_services").default([]).notNull(),
	semanticTags: jsonb("semantic_tags").default([]).notNull(),
	tagPreview: jsonb("tag_preview"),
	initialSchedule: jsonb("initial_schedule"),
}, (table) => [
	foreignKey({
			columns: [table.applicationId, table.userId],
			foreignColumns: [expertOnboardingApplications.id, expertOnboardingApplications.userId],
			name: "expert_card_draft_application_owner_fk"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.approvedReviewId],
			foreignColumns: [expertCardReviews.id],
			name: "expert_card_draft_approved_review_fk"
		}),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_card_drafts_user_id_fkey"
		}),
	unique("expert_card_draft_owner").on(table.id, table.userId),
	unique("expert_card_drafts_application_id_key").on(table.applicationId),
	unique("expert_card_drafts_user_id_key").on(table.userId),
	check("expert_card_draft_approval", sql`CHECK (COALESCE(((status = 'approved'::text) = (approved_review_id IS NOT NULL)), false`),
	check("expert_card_draft_public", sql`CHECK (COALESCE(((public_payload IS NULL) OR expert_card_public_payload_valid(public_payload)), false`),
	check("expert_card_draft_revision", sql`CHECK (COALESCE(((revision >= 0) AND (revision <= 1000000)), false`),
	check("expert_card_draft_scope", sql`CHECK (COALESCE(((work_bot_id ~ '^[1-9][0-9]{0,19}$'::text) AND (work_chat_id ~ '^[1-9][0-9]{0,19}$'::text) AND ((length(work_bot_key) >= 1) AND (length(work_bot_key) <= 128))), false`),
	check("expert_card_draft_status", sql`CHECK (COALESCE((status = ANY (ARRAY['collecting'::text, 'manager_review'::text, 'changes_requested'::text, 'approved'::text])), false`),
	check("expert_card_drafts_rich_guided_check", sql`(jsonb_typeof(rich_guided) = 'object'::text) AND (octet_length((rich_guided)::text) <= 16000)`),
	check("expert_card_drafts_semantic_tags_check", sql`CHECK (resident_tag_labels_valid(semantic_tags`),
	check("expert_card_drafts_tag_preview_check", sql`(tag_preview IS NULL) OR ((jsonb_typeof(tag_preview) = 'object'::text) AND (octet_length((tag_preview)::text) <= 20000))`),
	check("expert_card_input_mode", sql`CHECK (COALESCE((((document_import_revision IS NULL) OR ((document_import_revision >= 1) AND (document_import_revision <= revision))) AND (input_mode = ANY (ARRAY['INTERVIEW'::text, 'DOCUMENT_PROPOSAL'::text])) AND (((input_mode = 'INTERVIEW'::text) AND (document_proposal IS NULL)) OR ((input_mode = 'DOCUMENT_PROPOSAL'::text) AND (jsonb_typeof(document_proposal) = 'object'::text) AND (jsonb_typeof((document_proposal -> 'source'::text)) = 'string'::text) AND (jsonb_typeof((document_proposal -> 'content'::text)) = 'string'::text) AND (document_proposal ?& ARRAY['source'::text, 'content'::text]) AND (((document_proposal - 'source'::text) - 'content'::text) = '{}'::jsonb) AND ((document_proposal ->> 'source'::text) = ANY (ARRAY['pdf'::text, 'docx'::text])) AND (length(btrim((document_proposal ->> 'content'::text))) >= 50) AND (octet_length((document_proposal)::text) <= 100000)))), false`),
	check("resident_rich_pending_services_shape", sql`(jsonb_typeof(rich_pending_services) = 'array'::text) AND (jsonb_array_length(rich_pending_services) <= 8) AND (octet_length((rich_pending_services)::text) <= 95000)`),
	check("resident_rich_shape", sql`CHECK (COALESCE((((NOT rich_mode) AND (rich_profile IS NULL) AND (rich_proposal IS NULL)) OR (rich_mode AND resident_rich_profile_valid(rich_profile))), false`),
]);

export const residentDocumentAccessAudit = pgTable("resident_document_access_audit", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	custodyId: uuid("custody_id").notNull(),
	managerId: uuid("manager_id").notNull(),
	issuedAt: timestamp("issued_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(clock_timestamp() + '00:02:00'::interval)`).notNull(),
	action: text().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_document_access_audit_manager_id_fkey"
		}),
	check("resident_document_access_audit_action_check", sql`action = ANY (ARRAY['link_issued'::text, 'reconcile_requested'::text])`),
]);

export const residentPrivateObjects = pgTable("resident_private_objects", {
	id: uuid().primaryKey().notNull(),
	applicationId: uuid("application_id").notNull(),
	generation: integer().notNull(),
	sourceRevision: integer("source_revision").notNull(),
	purpose: text().notNull(),
	reference: jsonb().notNull(),
	consentAuthority: jsonb("consent_authority").notNull(),
	state: text().default('allocated').notNull(),
	claimToken: uuid("claim_token"),
	startedAt: timestamp("started_at", { withTimezone: true, mode: 'string' }),
	sha256: text(),
	proposal: jsonb(),
	observation: jsonb(),
	confirmedAt: timestamp("confirmed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	reconciliationRequested: boolean("reconciliation_requested").default(false).notNull(),
}, (table) => [
	index("resident_private_objects_pending").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(state = 'allocated'::text)`),
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_private_objects_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.id],
			foreignColumns: [residentObjectDeletions.custodyId],
			name: "resident_private_objects_id_fkey"
		}),
	unique("resident_private_objects_application_id_generation_source_r_key").on(table.applicationId, table.generation, table.sourceRevision, table.purpose, table.reference),
	check("resident_private_objects_check", sql`(state <> 'verified'::text) OR (sha256 IS NOT NULL)`),
	check("resident_private_objects_generation_check", sql`generation >= 0`),
	check("resident_private_objects_observation_check", sql`(observation IS NULL) OR ((jsonb_typeof(observation) = 'object'::text) AND (octet_length((observation)::text) <= 16000))`),
	check("resident_private_objects_proposal_check", sql`(proposal IS NULL) OR ((jsonb_typeof(proposal) = 'object'::text) AND (octet_length((proposal)::text) <= 16000))`),
	check("resident_private_objects_purpose_check", sql`purpose = ANY (ARRAY['brief'::text, 'education'::text, 'propertyEvidence'::text, 'tourMedia'::text, 'licence'::text, 'followup'::text])`),
	check("resident_private_objects_reference_check", sql`(jsonb_typeof(reference) = 'object'::text) AND (octet_length((reference)::text) <= 4096)`),
	check("resident_private_objects_sha256_check", sql`sha256 ~ '^[0-9a-f]{64}$'::text`),
	check("resident_private_objects_source_revision_check", sql`source_revision >= 0`),
	check("resident_private_objects_state_check", sql`state = ANY (ARRAY['allocated'::text, 'inflight'::text, 'unknown'::text, 'verified'::text, 'unavailable'::text])`),
]);

export const residentCardMedia = pgTable("resident_card_media", {
	id: uuid().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	sourceReference: text("source_reference").notNull(),
	size: integer().notNull(),
	mimeType: text("mime_type").notNull(),
	state: text().default('allocated').notNull(),
	sha256: text(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_card_media_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.id],
			foreignColumns: [residentObjectDeletions.custodyId],
			name: "resident_card_media_id_fkey"
		}),
	unique("resident_card_media_draft_id_source_reference_key").on(table.draftId, table.sourceReference),
	check("resident_card_media_check", sql`(state <> 'verified'::text) OR (sha256 IS NOT NULL)`),
	check("resident_card_media_mime_type_check", sql`mime_type = ANY (ARRAY['image/jpeg'::text, 'image/png'::text])`),
	check("resident_card_media_sha256_check", sql`sha256 ~ '^[0-9a-f]{64}$'::text`),
	check("resident_card_media_size_check", sql`(size >= 1) AND (size <= 20971520)`),
	check("resident_card_media_state_check", sql`state = ANY (ARRAY['allocated'::text, 'inflight'::text, 'unknown'::text, 'verified'::text, 'unavailable'::text])`),
]);

export const residentCardVersions = pgTable("resident_card_versions", {
	reviewId: uuid("review_id").primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	revision: integer().notNull(),
	profile: jsonb(),
	publicPayload: jsonb("public_payload").notNull(),
	safetyFields: jsonb("safety_fields").notNull(),
	safetyProof: jsonb("safety_proof").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	initialSchedule: jsonb("initial_schedule"),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_card_versions_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [expertCardReviews.id],
			name: "resident_card_versions_review_id_fkey"
		}).onDelete("cascade"),
	unique("resident_card_versions_draft_id_revision_key").on(table.draftId, table.revision),
	check("resident_card_versions_profile_check", sql`(profile IS NULL) OR resident_rich_profile_valid(profile, true)`),
]);

export const residentObjectDeletions = pgTable("resident_object_deletions", {
	custodyId: uuid("custody_id").defaultRandom().primaryKey().notNull(),
	objectKey: text("object_key").notNull(),
	writeState: text("write_state").default('allocated').notNull(),
	claimToken: uuid("claim_token"),
	erased: boolean().default(false).notNull(),
	deleteState: text("delete_state").default('dormant').notNull(),
	deleteAttempts: integer("delete_attempts").default(0).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	subjectErasureKey: text("subject_erasure_key"),
	deletionJobId: uuid("deletion_job_id"),
	deletionToken: uuid("deletion_token"),
	deletionStartedAt: timestamp("deletion_started_at", { withTimezone: true, mode: 'string' }),
	deletionWriteState: text("deletion_write_state"),
}, (table) => [
	index("resident_object_deletions_job").using("btree", table.deletionJobId.asc().nullsLast().op("uuid_ops")).where(sql`(deletion_job_id IS NOT NULL)`),
	index("resident_object_deletions_pending").using("btree", table.updatedAt.asc().nullsLast().op("timestamptz_ops"), table.custodyId.asc().nullsLast().op("timestamptz_ops")).where(sql`(erased AND (delete_state = ANY (ARRAY['pending'::text, 'unknown'::text])))`),
	index("resident_object_deletions_subject").using("btree", table.subjectErasureKey.asc().nullsLast().op("text_ops")).where(sql`(subject_erasure_key IS NOT NULL)`),
	foreignKey({
			columns: [table.deletionJobId],
			foreignColumns: [privacyDeletionJobs.id],
			name: "resident_object_deletions_deletion_job_id_fkey"
		}),
	unique("resident_object_deletions_object_key_key").on(table.objectKey),
	check("resident_deletion_operation_complete", sql`((deletion_token IS NULL) AND (deletion_started_at IS NULL) AND (deletion_write_state IS NULL)) OR ((deletion_token IS NOT NULL) AND (deletion_started_at IS NOT NULL) AND (deletion_write_state IS NOT NULL) AND (deletion_write_state = ANY (ARRAY['allocated'::text, 'inflight'::text, 'settled'::text, 'unknown'::text])))`),
	check("resident_object_deletions_check", sql`object_key = ('custody/'::text || (custody_id)::text)`),
	check("resident_object_deletions_check1", sql`((NOT erased) AND (delete_state = 'dormant'::text)) OR erased`),
	check("resident_object_deletions_check2", sql`(delete_state <> 'verified'::text) OR (write_state = ANY (ARRAY['allocated'::text, 'settled'::text]))`),
	check("resident_object_deletions_delete_attempts_check", sql`(delete_attempts >= 0) AND (delete_attempts <= 3)`),
	check("resident_object_deletions_delete_state_check", sql`delete_state = ANY (ARRAY['dormant'::text, 'pending'::text, 'unknown'::text, 'verified'::text])`),
	check("resident_object_deletions_subject_erasure_key_check", sql`subject_erasure_key ~ '^[0-9a-f]{64}$'::text`),
	check("resident_object_deletions_write_state_check", sql`write_state = ANY (ARRAY['allocated'::text, 'inflight'::text, 'settled'::text, 'unknown'::text])`),
	check("resident_private_erasure_link", sql`(subject_erasure_key IS NOT NULL) OR (deletion_job_id IS NOT NULL) OR (delete_state = 'verified'::text)`),
]);

export const expertCardReviews = pgTable("expert_card_reviews", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	action: text().notNull(),
	publicPayload: jsonb("public_payload"),
	publicDigest: text("public_digest"),
	managerId: uuid("manager_id").notNull(),
	managerSessionHash: text("manager_session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	safetyProof: jsonb("safety_proof"),
	warningAcknowledgment: text("warning_acknowledgment"),
	returnReason: text("return_reason"),
}, (table) => [
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_review_owner"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_card_reviews_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.managerSessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_card_reviews_manager_session_hash_fkey"
		}),
	unique("expert_card_review_public_identity").on(table.id, table.userId, table.revision, table.publicDigest),
	unique("expert_card_review_once").on(table.draftId, table.revision, table.action),
	check("expert_card_review_value", sql`CHECK (COALESCE((((action = 'approve'::text) AND expert_card_public_payload_valid(public_payload) AND (public_digest = ('sha256:'::text || encode(digest((public_payload)::text, 'sha256'::text), 'hex'::text)))) OR ((action = 'return_changes'::text) AND (public_payload IS NULL) AND (public_digest IS NULL))), false`),
]);

export const tagEmbeddingsCache = pgTable("tag_embeddings_cache", {
	singleton: boolean().default(true).primaryKey().notNull(),
	generation: text().notNull(),
	modelDigest: text("model_digest").notNull(),
	taxonomyDigest: text("taxonomy_digest").notNull(),
	cache: jsonb().notNull(),
}, (table) => [
	check("tag_embeddings_cache_cache_check", sql`CHECK (resident_tag_cache_valid(cache`),
	check("tag_embeddings_cache_check", sql`(NOT ((cache ->> 'generation'::text) IS DISTINCT FROM generation)) AND (NOT ((cache ->> 'model'::text) IS DISTINCT FROM model_digest))`),
	check("tag_embeddings_cache_generation_check", sql`generation ~ '^[0-9a-f]{64}$'::text`),
	check("tag_embeddings_cache_model_digest_check", sql`model_digest ~ '^[0-9a-f]{64}$'::text`),
	check("tag_embeddings_cache_singleton_check", sql`CHECK (singleton)`),
	check("tag_embeddings_cache_taxonomy_digest_check", sql`taxonomy_digest ~ '^[0-9a-f]{64}$'::text`),
]);

export const residentScheduleState = pgTable("resident_schedule_state", {
	draftId: uuid("draft_id").primaryKey().notNull(),
	rules: jsonb().default({}).notNull(),
	mode: text().default('live').notNull(),
	field: integer().default(0).notNull(),
	revision: integer().default(0).notNull(),
	rawInput: text("raw_input"),
	currentPreview: uuid("current_preview"),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_schedule_state_draft_id_fkey"
		}).onDelete("cascade"),
	check("resident_schedule_state_field_check", sql`(field >= 0) AND (field <= 7)`),
	check("resident_schedule_state_mode_check", sql`mode = ANY (ARRAY['live'::text, 'card'::text])`),
	check("resident_schedule_state_raw_input_check", sql`octet_length(raw_input) <= 64000`),
	check("resident_schedule_state_revision_check", sql`revision >= 0`),
	check("resident_schedule_state_rules_check", sql`(jsonb_typeof(rules) = 'object'::text) AND (octet_length((rules)::text) <= 4000)`),
]);

export const residentSchedulePreviews = pgTable("resident_schedule_previews", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	draftId: uuid("draft_id").notNull(),
	scheduleRevision: integer("schedule_revision").notNull(),
	draftRevision: integer("draft_revision").notNull(),
	reviewId: uuid("review_id"),
	rawInput: text("raw_input"),
	profileDigest: text("profile_digest").notNull(),
	rules: jsonb().notNull(),
	entries: jsonb().notNull(),
	omissions: jsonb().default([]).notNull(),
	errors: jsonb().default([]).notNull(),
	page: integer().default(sql`'-1'`).notNull(),
	pageCount: integer("page_count").notNull(),
	tokenDigest: text("token_digest"),
	confirmedAt: timestamp("confirmed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).default(sql`(clock_timestamp() + '01:00:00'::interval)`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_schedule_previews_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [residentCardVersions.reviewId],
			name: "resident_schedule_previews_review_id_fkey"
		}).onDelete("cascade"),
	check("resident_schedule_previews_draft_revision_check", sql`draft_revision >= 0`),
	check("resident_schedule_previews_entries_check", sql`(jsonb_typeof(entries) = 'array'::text) AND (jsonb_array_length(entries) <= 500) AND (octet_length((entries)::text) <= 300000)`),
	check("resident_schedule_previews_errors_check", sql`(jsonb_typeof(errors) = 'array'::text) AND (octet_length((errors)::text) <= 150000)`),
	check("resident_schedule_previews_omissions_check", sql`(jsonb_typeof(omissions) = 'array'::text) AND (octet_length((omissions)::text) <= 150000)`),
	check("resident_schedule_previews_page_check", sql`page >= '-1'::integer`),
	check("resident_schedule_previews_page_count_check", sql`(page_count >= 1) AND (page_count <= 500)`),
	check("resident_schedule_previews_profile_digest_check", sql`profile_digest ~ '^[0-9a-f]{64}$'::text`),
	check("resident_schedule_previews_raw_input_check", sql`octet_length(raw_input) <= 64000`),
	check("resident_schedule_previews_rules_check", sql`(jsonb_typeof(rules) = 'object'::text) AND (octet_length((rules)::text) <= 4000)`),
	check("resident_schedule_previews_schedule_revision_check", sql`schedule_revision >= 0`),
	check("resident_schedule_previews_token_digest_check", sql`token_digest ~ '^[0-9a-f]{64}$'::text`),
]);

export const residentServiceVersions = pgTable("resident_service_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reviewId: uuid("review_id").notNull(),
	richServiceId: uuid("rich_service_id").notNull(),
	expertServiceId: uuid("expert_service_id").notNull(),
	title: text().notNull(),
	durationMinutes: integer("duration_minutes").notNull(),
	format: text().notNull(),
	logistics: jsonb().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.expertServiceId],
			foreignColumns: [expertServices.id],
			name: "resident_service_versions_expert_service_id_fkey"
		}),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [residentCardVersions.reviewId],
			name: "resident_service_versions_review_id_fkey"
		}).onDelete("cascade"),
	unique("resident_service_versions_review_id_rich_service_id_key").on(table.reviewId, table.richServiceId),
	check("resident_service_versions_duration_minutes_check", sql`(duration_minutes >= 5) AND (duration_minutes <= 1440)`),
	check("resident_service_versions_format_check", sql`format = ANY (ARRAY['ONLINE'::text, 'OFFLINE'::text, 'HYBRID'::text])`),
	check("resident_service_versions_logistics_check", sql`(jsonb_typeof(logistics) = 'object'::text) AND (octet_length((logistics)::text) <= 10000)`),
	check("resident_service_versions_title_check", sql`(length(title) >= 1) AND (length(title) <= 160)`),
]);

export const residentScheduleVersions = pgTable("resident_schedule_versions", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	previewId: uuid("preview_id").notNull(),
	reviewId: uuid("review_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	confirmedAt: timestamp("confirmed_at", { withTimezone: true, mode: 'string' }).notNull(),
	validUntil: timestamp("valid_until", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "resident_schedule_versions_expert_id_fkey"
		}),
	foreignKey({
			columns: [table.previewId],
			foreignColumns: [residentSchedulePreviews.id],
			name: "resident_schedule_versions_preview_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.reviewId],
			foreignColumns: [residentCardVersions.reviewId],
			name: "resident_schedule_versions_review_id_fkey"
		}).onDelete("cascade"),
	unique("resident_schedule_versions_preview_id_key").on(table.previewId),
]);

export const residentNativeSlots = pgTable("resident_native_slots", {
	slotId: uuid("slot_id").primaryKey().notNull(),
	scheduleId: uuid("schedule_id").notNull(),
	serviceVersionId: uuid("service_version_id").notNull(),
	localStart: text("local_start").notNull(),
	timezone: text().notNull(),
	bufferMinutes: integer("buffer_minutes").notNull(),
	occupiedUntil: timestamp("occupied_until", { withTimezone: true, mode: 'string' }).notNull(),
	withdrawnAt: timestamp("withdrawn_at", { withTimezone: true, mode: 'string' }),
}, (table) => [
	index("resident_native_slots_schedule").using("btree", table.scheduleId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.scheduleId],
			foreignColumns: [residentScheduleVersions.id],
			name: "resident_native_slots_schedule_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.serviceVersionId],
			foreignColumns: [residentServiceVersions.id],
			name: "resident_native_slots_service_version_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.slotId],
			foreignColumns: [slots.id],
			name: "resident_native_slots_slot_id_fkey"
		}).onDelete("cascade"),
	check("resident_native_slots_buffer_minutes_check", sql`(buffer_minutes >= 0) AND (buffer_minutes <= 240)`),
]);

export const residentScheduleBusy = pgTable("resident_schedule_busy", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	expertId: uuid("expert_id").notNull(),
	draftId: uuid("draft_id").notNull(),
	startsAt: timestamp("starts_at", { withTimezone: true, mode: 'string' }).notNull(),
	endsAt: timestamp("ends_at", { withTimezone: true, mode: 'string' }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	index("resident_schedule_busy_expert").using("btree", table.expertId.asc().nullsLast().op("uuid_ops"), table.startsAt.asc().nullsLast().op("timestamptz_ops"), table.endsAt.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_schedule_busy_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.expertId],
			foreignColumns: [experts.id],
			name: "resident_schedule_busy_expert_id_fkey"
		}),
	check("resident_schedule_busy_check", sql`ends_at > starts_at`),
]);

export const residentNativeConfirmations = pgTable("resident_native_confirmations", {
	reservationId: uuid("reservation_id").primaryKey().notNull(),
	slotId: uuid("slot_id").notNull(),
	serviceVersionId: uuid("service_version_id").notNull(),
	reservationVersion: integer("reservation_version").notNull(),
	snapshot: jsonb().notNull(),
	confirmedAt: timestamp("confirmed_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [reservations.id],
			name: "resident_native_confirmations_reservation_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.serviceVersionId],
			foreignColumns: [residentServiceVersions.id],
			name: "resident_native_confirmations_service_version_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.slotId],
			foreignColumns: [residentNativeSlots.slotId],
			name: "resident_native_confirmations_slot_id_fkey"
		}).onDelete("cascade"),
	check("resident_native_confirmations_reservation_version_check", sql`reservation_version > 1`),
	check("resident_native_confirmations_snapshot_check", sql`(jsonb_typeof(snapshot) = 'object'::text) AND (octet_length((snapshot)::text) <= 15000)`),
]);

export const residentNativeLogistics = pgTable("resident_native_logistics", {
	id: uuid().defaultRandom().primaryKey().notNull(),
	reservationId: uuid("reservation_id").notNull(),
	kind: text().notNull(),
	dueAt: timestamp("due_at", { withTimezone: true, mode: 'string' }).notNull(),
	state: text().default('pending').notNull(),
	attemptId: uuid("attempt_id"),
	attemptCount: integer("attempt_count").default(0).notNull(),
	leaseUntil: timestamp("lease_until", { withTimezone: true, mode: 'string' }),
	receipt: jsonb(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	index("resident_native_logistics_due").using("btree", table.dueAt.asc().nullsLast().op("timestamptz_ops"), table.id.asc().nullsLast().op("uuid_ops")).where(sql`(state = 'pending'::text)`),
	foreignKey({
			columns: [table.reservationId],
			foreignColumns: [residentNativeConfirmations.reservationId],
			name: "resident_native_logistics_reservation_id_fkey"
		}).onDelete("cascade"),
	unique("resident_native_logistics_reservation_id_kind_key").on(table.reservationId, table.kind),
	check("resident_native_logistics_attempt_count_check", sql`(attempt_count >= 0) AND (attempt_count <= 3)`),
	check("resident_native_logistics_kind_check", sql`kind = ANY (ARRAY['online'::text, 'offline'::text])`),
	check("resident_native_logistics_receipt_check", sql`(receipt IS NULL) OR ((jsonb_typeof(receipt) = 'object'::text) AND (octet_length((receipt)::text) <= 1000))`),
	check("resident_native_logistics_state_check", sql`state = ANY (ARRAY['pending'::text, 'sending'::text, 'unknown'::text, 'delivered'::text, 'suppressed'::text])`),
]);

export const expertCampaignAnchors = pgTable("expert_campaign_anchors", {
	userId: uuid("user_id").notNull(),
	ruleVersion: text("rule_version").notNull(),
	calculationTimestamp: timestamp("calculation_timestamp", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_campaign_anchors_user_id_fkey"
		}),
	primaryKey({ columns: [table.userId, table.ruleVersion], name: "expert_campaign_anchors_pkey"}),
	unique("expert_campaign_anchor_identity").on(table.userId, table.ruleVersion, table.calculationTimestamp),
	check("expert_campaign_anchor_valid", sql`(rule_version = ANY (ARRAY['expert_energy_start_v1'::text, 'expert_energy_start_v2'::text, 'expert_separated_sales_v3'::text])) AND isfinite(calculation_timestamp) AND ((calculation_timestamp >= '1970-01-01 00:00:00+00'::timestamp with time zone) AND (calculation_timestamp <= '275760-09-13 00:00:00+00'::timestamp with time zone)) AND (calculation_timestamp = date_trunc('milliseconds'::text, calculation_timestamp))`),
]);

export const expertCardDraftTags = pgTable("expert_card_draft_tags", {
	draftId: uuid("draft_id").notNull(),
	userId: uuid("user_id").notNull(),
	tagId: uuid("tag_id").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId, table.userId],
			foreignColumns: [expertCardDrafts.id, expertCardDrafts.userId],
			name: "expert_card_draft_tag_owner"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.tagId],
			foreignColumns: [hashtagsDb.id],
			name: "expert_card_draft_tags_tag_id_fkey"
		}),
	primaryKey({ columns: [table.draftId, table.tagId], name: "expert_card_draft_tags_pkey"}),
]);

export const residentServiceMappings = pgTable("resident_service_mappings", {
	draftId: uuid("draft_id").notNull(),
	richServiceId: uuid("rich_service_id").notNull(),
	expertServiceId: uuid("expert_service_id").notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_service_mappings_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.expertServiceId],
			foreignColumns: [expertServices.id],
			name: "resident_service_mappings_expert_service_id_fkey"
		}),
	primaryKey({ columns: [table.draftId, table.richServiceId], name: "resident_service_mappings_pkey"}),
	unique("resident_service_mappings_expert_service_id_key").on(table.expertServiceId),
]);

export const expertReferralLedgerAllocations = pgTable("expert_referral_ledger_allocations", {
	ledgerEntryId: uuid("ledger_entry_id").notNull(),
	rewardGrantId: uuid("reward_grant_id").notNull(),
	expertId: uuid("expert_id").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	amountMinor: bigint("amount_minor", { mode: "number" }).notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("expert_ledger_allocations_grant_idx").using("btree", table.rewardGrantId.asc().nullsLast().op("uuid_ops")),
	foreignKey({
			columns: [table.ledgerEntryId, table.expertId],
			foreignColumns: [expertReferralLedgerEntries.id, expertReferralLedgerEntries.expertId],
			name: "expert_ledger_allocations_entry_owner_fk"
		}),
	foreignKey({
			columns: [table.rewardGrantId, table.expertId],
			foreignColumns: [expertReferralRewardGrants.id, expertReferralRewardGrants.expertId],
			name: "expert_ledger_allocations_grant_owner_fk"
		}),
	primaryKey({ columns: [table.ledgerEntryId, table.rewardGrantId], name: "expert_ledger_allocations_pk"}),
	check("expert_ledger_allocation_nonzero", sql`(amount_minor <> 0) AND (abs(amount_minor) <= '999999999999'::bigint)`),
]);

export const expertOfferProfileVerifications = pgTable("expert_offer_profile_verifications", {
	userId: uuid("user_id").notNull(),
	profileRevision: integer("profile_revision").notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId, table.profileRevision],
			foreignColumns: [expertOfferProfiles.userId, expertOfferProfiles.revision],
			name: "expert_offer_profile_verification_user_id_profile_revision_fkey"
		}),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "expert_offer_profile_verifications_manager_id_fkey"
		}),
	foreignKey({
			columns: [table.sessionHash],
			foreignColumns: [adminSessions.sessionIdHash],
			name: "expert_offer_profile_verifications_session_hash_fkey"
		}),
	primaryKey({ columns: [table.userId, table.profileRevision], name: "expert_offer_profile_verifications_pkey"}),
]);

export const expertResidencyRenewalAttempts = pgTable("expert_residency_renewal_attempts", {
	billId: uuid("bill_id").notNull(),
	sequence: integer().notNull(),
	quoteId: uuid("quote_id").notNull(),
	acceptanceId: uuid("acceptance_id").notNull(),
	orderId: uuid("order_id").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.acceptanceId],
			foreignColumns: [expertCardMainAcceptances.id],
			name: "expert_residency_renewal_attempts_acceptance_id_fkey"
		}),
	foreignKey({
			columns: [table.billId],
			foreignColumns: [expertResidencyRenewalBills.id],
			name: "expert_residency_renewal_attempts_bill_id_fkey"
		}),
	foreignKey({
			columns: [table.orderId],
			foreignColumns: [expertResidencyOrders.id],
			name: "expert_residency_renewal_attempts_order_id_fkey"
		}),
	foreignKey({
			columns: [table.quoteId],
			foreignColumns: [expertCampaignQuotes.id],
			name: "expert_residency_renewal_attempts_quote_id_fkey"
		}),
	primaryKey({ columns: [table.billId, table.sequence], name: "expert_residency_renewal_attempts_pkey"}),
	unique("expert_residency_renewal_attempts_order_id_key").on(table.orderId),
	check("expert_residency_renewal_attempts_sequence_check", sql`sequence > 0`),
]);

export const residentMessageTemplates = pgTable("resident_message_templates", {
	keyName: text("key_name").notNull(),
	version: integer().notNull(),
	category: text().notNull(),
	bodyText: text("body_text").notNull(),
	variablesList: jsonb("variables_list").notNull(),
	isActive: boolean("is_active").default(true).notNull(),
}, (table) => [
	primaryKey({ columns: [table.keyName, table.version], name: "resident_message_templates_pkey"}),
	check("resident_message_templates_category_check", sql`category = ANY (ARRAY['REJECT_SOFT'::text, 'REJECT_HARD'::text, 'INFO_REQUEST'::text, 'REFUND_NOTICE'::text])`),
	check("resident_message_templates_variables_list_check", sql`jsonb_typeof(variables_list) = 'array'::text`),
	check("resident_message_templates_version_check", sql`version > 0`),
]);

export const consentStates = pgTable("consent_states", {
	userId: uuid("user_id").notNull(),
	purpose: text().notNull(),
	decision: text().notNull(),
	documentVersionId: uuid("document_version_id"),
	lastDecisionId: uuid("last_decision_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	revision: bigint({ mode: "number" }).notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.documentVersionId],
			foreignColumns: [consentDocumentVersions.id],
			name: "consent_states_document_version_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.lastDecisionId],
			foreignColumns: [consents.id],
			name: "consent_states_last_decision_fk"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.lastDecisionId],
			foreignColumns: [consents.id],
			name: "consent_states_last_decision_id_fkey"
		}).onDelete("restrict"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "consent_states_user_id_fkey"
		}).onDelete("cascade"),
	primaryKey({ columns: [table.userId, table.purpose], name: "consent_states_pkey"}),
	check("consent_states_decision_check", sql`decision = ANY (ARRAY['granted'::text, 'denied'::text, 'revoked'::text])`),
	check("consent_states_purpose_bounded", sql`(char_length(purpose) >= 1) AND (char_length(purpose) <= 64)`),
	check("consent_states_revision_positive", sql`revision > 0`),
]);

export const bookingNotificationCallbacks = pgTable("booking_notification_callbacks", {
	deliveryId: uuid("delivery_id").notNull(),
	action: text().notNull(),
	notificationId: uuid("notification_id").notNull(),
	callbackTokenHash: text("callback_token_hash").notNull(),
	callbackTokenCiphertext: text("callback_token_ciphertext"),
	encryptionKeyId: text("encryption_key_id"),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.deliveryId],
			foreignColumns: [bookingNotificationDeliveries.id],
			name: "booking_notification_callbacks_delivery_id_fkey"
		}),
	foreignKey({
			columns: [table.notificationId],
			foreignColumns: [notifications.id],
			name: "booking_notification_callbacks_notification_id_fkey"
		}),
	primaryKey({ columns: [table.deliveryId, table.action], name: "booking_notification_callbacks_pkey"}),
	unique("booking_notification_callbacks_notification_id_key").on(table.notificationId),
	check("booking_notification_callbacks_action_check", sql`action = ANY (ARRAY['confirm'::text, 'cancel'::text])`),
	check("booking_notification_callbacks_callback_token_hash_check", sql`callback_token_hash ~ '^[a-f0-9]{64}$'::text`),
	check("booking_notification_callbacks_check", sql`(callback_token_ciphertext IS NULL) = (encryption_key_id IS NULL)`),
]);

export const expertPromoRequests = pgTable("expert_promo_requests", {
	botId: text("bot_id").notNull(),
	requestKey: text("request_key").notNull(),
	userId: uuid("user_id"),
	requestDigest: text("request_digest"),
	erasedAt: timestamp("erased_at", { withTimezone: true, mode: 'string' }),
	operation: text().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_promo_requests_user_id_fkey"
		}),
	primaryKey({ columns: [table.botId, table.requestKey], name: "expert_promo_requests_pkey"}),
	check("expert_promo_bot_id", sql`bot_id ~ '^[1-9][0-9]{0,19}$'::text`),
	check("expert_promo_request_digest", sql`request_digest ~ '^[0-9a-f]{64}$'::text`),
	check("expert_promo_request_erasure", sql`((user_id IS NOT NULL) AND (request_digest IS NOT NULL) AND (erased_at IS NULL)) OR ((user_id IS NULL) AND (request_digest IS NULL) AND (erased_at IS NOT NULL))`),
	check("expert_promo_request_key", sql`(length(request_key) >= 1) AND (length(request_key) <= 200)`),
	check("expert_promo_request_operation", sql`operation = ANY (ARRAY['register'::text, 'application'::text, 'quote'::text, 'enroll'::text, 'consent'::text, 'tariffs'::text, 'profile'::text])`),
]);

export const residentCheckGenerations = pgTable("resident_check_generations", {
	applicationId: uuid("application_id").notNull(),
	generation: integer().notNull(),
	submittedRevision: integer("submitted_revision").notNull(),
	supplementRevision: integer("supplement_revision").notNull(),
	requestId: uuid("request_id"),
	status: text().default('pending').notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_check_generations_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.requestId],
			foreignColumns: [residentInformationRequests.id],
			name: "resident_check_generations_request_id_fkey"
		}).onDelete("cascade"),
	primaryKey({ columns: [table.applicationId, table.generation], name: "resident_check_generations_pkey"}),
	check("resident_check_generations_status_check", sql`status = ANY (ARRAY['pending'::text, 'manual_review'::text, 'cancelled'::text])`),
]);

export const residentSocialObservations = pgTable("resident_social_observations", {
	userId: uuid("user_id").notNull(),
	applicationId: uuid("application_id").notNull(),
	profile: text().notNull(),
	adapterVersion: text("adapter_version").notNull(),
	observedAt: timestamp("observed_at", { withTimezone: true, mode: 'string' }).notNull(),
	expiresAt: timestamp("expires_at", { withTimezone: true, mode: 'string' }).notNull(),
	observation: jsonb().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId],
			foreignColumns: [residentsApplications.id],
			name: "resident_social_observations_application_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_social_observations_user_id_fkey"
		}).onDelete("cascade"),
	primaryKey({ columns: [table.userId, table.profile, table.adapterVersion], name: "resident_social_observations_pkey"}),
	check("resident_social_observations_adapter_version_check", sql`length(adapter_version) <= 100`),
	check("resident_social_observations_check", sql`expires_at = (observed_at + '24:00:00'::interval)`),
	check("resident_social_observations_observation_check", sql`(jsonb_typeof(observation) = 'object'::text) AND (octet_length((observation)::text) <= 16000)`),
	check("resident_social_observations_profile_check", sql`length(profile) <= 2048`),
]);

export const residentTagDecisions = pgTable("resident_tag_decisions", {
	draftId: uuid("draft_id").notNull(),
	revision: integer().notNull(),
	identity: text().notNull(),
	decision: text().notNull(),
	reason: text().notNull(),
	managerId: uuid("manager_id").notNull(),
	sessionHash: text("session_hash").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.draftId],
			foreignColumns: [expertCardDrafts.id],
			name: "resident_tag_decisions_draft_id_fkey"
		}).onDelete("cascade"),
	foreignKey({
			columns: [table.managerId],
			foreignColumns: [users.id],
			name: "resident_tag_decisions_manager_id_fkey"
		}),
	primaryKey({ columns: [table.draftId, table.revision, table.identity], name: "resident_tag_decisions_pkey"}),
	check("resident_tag_decisions_decision_check", sql`decision = ANY (ARRAY['approve'::text, 'reject'::text])`),
	check("resident_tag_decisions_identity_check", sql`(length(identity) >= 1) AND (length(identity) <= 200)`),
	check("resident_tag_decisions_reason_check", sql`(length(btrim(reason)) >= 1) AND (length(btrim(reason)) <= 1000)`),
	check("resident_tag_decisions_revision_check", sql`revision >= 0`),
]);

export const expertCardRequests = pgTable("expert_card_requests", {
	botId: text("bot_id").notNull(),
	updateId: text("update_id").notNull(),
	userId: uuid("user_id"),
	operation: text().notNull(),
	requestDigest: text("request_digest"),
	semanticDigest: text("semantic_digest"),
	resultId: uuid("result_id"),
	erasedAt: timestamp("erased_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_card_requests_user_id_fkey"
		}),
	primaryKey({ columns: [table.botId, table.updateId], name: "expert_card_requests_pkey"}),
	check("expert_card_request_digests", sql`CHECK (COALESCE((((user_id IS NOT NULL) AND (request_digest ~ '^[0-9a-f]{64}$'::text) AND (semantic_digest ~ '^[0-9a-f]{64}$'::text) AND (erased_at IS NULL)) OR ((user_id IS NULL) AND (request_digest IS NULL) AND (semantic_digest IS NULL) AND (result_id IS NULL) AND (erased_at IS NOT NULL))), false`),
	check("expert_card_request_operation", sql`CHECK (COALESCE((operation = ANY (ARRAY['entry'::text, 'submit'::text, 'promo_proof'::text, 'handoff_issue'::text, 'handoff_redeem'::text, 'main_quote'::text, 'main_accept'::text, 'main_checkout'::text, 'residency_pause'::text, 'residency_resume'::text, 'tags_toggle'::text])), false`),
	check("expert_card_request_scope", sql`CHECK (COALESCE(((bot_id ~ '^[1-9][0-9]{0,19}$'::text) AND (update_id ~ '^(0|[1-9][0-9]{0,19})$'::text)), false`),
]);

export const expertOfferProfiles = pgTable("expert_offer_profiles", {
	userId: uuid("user_id").notNull(),
	revision: integer().notNull(),
	cityCode: text("city_code").notNull(),
	millionCity: boolean("million_city").notNull(),
	serviceFormat: text("service_format").notNull(),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	ticketMinor: bigint("ticket_minor", { mode: "number" }).notNull(),
	participantKind: text("participant_kind").notNull(),
	idempotencyKey: text("idempotency_key").notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).default(sql`clock_timestamp()`).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "expert_offer_profiles_user_id_fkey"
		}),
	primaryKey({ columns: [table.userId, table.revision], name: "expert_offer_profiles_pkey"}),
	unique("expert_offer_profiles_user_id_idempotency_key_key").on(table.userId, table.idempotencyKey),
	check("expert_offer_profiles_city_code_check", sql`(length(city_code) >= 1) AND (length(city_code) <= 100)`),
	check("expert_offer_profiles_participant_kind_check", sql`participant_kind = ANY (ARRAY['expert'::text, 'space'::text])`),
	check("expert_offer_profiles_revision_check", sql`revision > 0`),
	check("expert_offer_profiles_service_format_check", sql`service_format = ANY (ARRAY['online_only'::text, 'offline'::text, 'hybrid'::text])`),
	check("expert_offer_profiles_ticket_minor_check", sql`ticket_minor >= 0`),
]);

export const residentVerificationRequests = pgTable("resident_verification_requests", {
	botId: text("bot_id").notNull(),
	botKey: text("bot_key").notNull(),
	requestKey: text("request_key").notNull(),
	userId: uuid("user_id"),
	requestDigest: text("request_digest"),
	operation: text().notNull(),
	result: jsonb(),
	erasedAt: timestamp("erased_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("resident_verification_requests_subject_idx").using("btree", table.userId.asc().nullsLast().op("uuid_ops")).where(sql`(user_id IS NOT NULL)`),
	foreignKey({
			columns: [table.userId],
			foreignColumns: [users.id],
			name: "resident_verification_requests_user_id_fkey"
		}),
	primaryKey({ columns: [table.botId, table.botKey, table.requestKey], name: "resident_verification_requests_pkey"}),
	check("resident_verification_request_erasure", sql`((user_id IS NOT NULL) AND (request_digest ~ '^[0-9a-f]{64}$'::text) AND (request_digest IS NOT NULL) AND (result IS NOT NULL) AND (erased_at IS NULL)) OR ((user_id IS NULL) AND (request_digest IS NULL) AND (result IS NULL) AND (erased_at IS NOT NULL))`),
	check("resident_verification_requests_operation_check", sql`operation = ANY (ARRAY['start'::text, 'patch'::text, 'submit'::text, 'followup'::text, 'question'::text, 'complete'::text, 'reapply'::text])`),
	check("resident_verification_requests_request_key_check", sql`(length(request_key) >= 1) AND (length(request_key) <= 200)`),
]);

export const residentEvidenceJobs = pgTable("resident_evidence_jobs", {
	applicationId: uuid("application_id").notNull(),
	generation: integer().notNull(),
	status: text().default('pending').notNull(),
	claimToken: uuid("claim_token"),
	claimedAt: timestamp("claimed_at", { withTimezone: true, mode: 'string' }),
	consentAuthority: jsonb("consent_authority"),
	result: jsonb(),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	documentCursor: integer("document_cursor").default(0).notNull(),
	documentsMaterialized: boolean("documents_materialized").default(false).notNull(),
}, (table) => [
	foreignKey({
			columns: [table.applicationId, table.generation],
			foreignColumns: [residentCheckGenerations.applicationId, residentCheckGenerations.generation],
			name: "resident_evidence_jobs_application_id_generation_fkey"
		}).onDelete("cascade"),
	primaryKey({ columns: [table.applicationId, table.generation], name: "resident_evidence_jobs_pkey"}),
	check("resident_evidence_jobs_document_cursor_check", sql`document_cursor >= 0`),
	check("resident_evidence_jobs_result_check", sql`(result IS NULL) OR ((jsonb_typeof(result) = 'object'::text) AND (octet_length((result)::text) <= 64000))`),
	check("resident_evidence_jobs_status_check", sql`status = ANY (ARRAY['pending'::text, 'claimed'::text, 'complete'::text, 'cancelled'::text, 'unknown'::text])`),
]);
export const packageBalances = pgView("package_balances", {	packageId: uuid("package_id"),
	userId: uuid("user_id"),
	balance: integer(),
}).as(sql`SELECT p.id AS package_id, p.user_id, COALESCE(sum(l.delta), 0::bigint)::integer AS balance FROM message_packages p LEFT JOIN message_ledger_entries l ON l.package_id = p.id GROUP BY p.id, p.user_id`);

export const expertReferralBalances = pgView("expert_referral_balances", {	expertId: uuid("expert_id"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	availableCreditMinor: bigint("available_credit_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	reservedCreditMinor: bigint("reserved_credit_minor", { mode: "number" }),
	nearestExpiryAt: timestamp("nearest_expiry_at", { withTimezone: true, mode: 'string' }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	lifetimeGrantedMinor: bigint("lifetime_granted_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	lifetimeSpentMinor: bigint("lifetime_spent_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	lifetimeExpiredMinor: bigint("lifetime_expired_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	debtMinor: bigint("debt_minor", { mode: "number" }),
}).as(sql`WITH ledger_totals AS ( SELECT expert_referral_ledger_entries.expert_id, COALESCE(sum(expert_referral_ledger_entries.amount_minor), 0::numeric)::bigint AS net_minor, COALESCE(- sum(expert_referral_ledger_entries.amount_minor) FILTER (WHERE expert_referral_ledger_entries.entry_kind = ANY (ARRAY['reservation'::expert_referral_ledger_entry_kind, 'release'::expert_referral_ledger_entry_kind])), 0::numeric)::bigint AS reserved_minor, COALESCE(sum(expert_referral_ledger_entries.amount_minor) FILTER (WHERE expert_referral_ledger_entries.entry_kind = 'reward_grant'::expert_referral_ledger_entry_kind), 0::numeric)::bigint AS granted_minor, COALESCE(- sum(expert_referral_ledger_entries.amount_minor) FILTER (WHERE expert_referral_ledger_entries.entry_kind = 'spend'::expert_referral_ledger_entry_kind), 0::numeric)::bigint AS spent_minor, COALESCE(- sum(expert_referral_ledger_entries.amount_minor) FILTER (WHERE expert_referral_ledger_entries.entry_kind = 'expiry'::expert_referral_ledger_entry_kind), 0::numeric)::bigint AS expired_minor FROM expert_referral_ledger_entries GROUP BY expert_referral_ledger_entries.expert_id ), grant_remaining AS ( SELECT g_1.id, g_1.expert_id, g_1.expires_at, COALESCE(sum(a.amount_minor), 0::numeric)::bigint AS remaining_minor FROM expert_referral_reward_grants g_1 LEFT JOIN expert_referral_ledger_allocations a ON a.reward_grant_id = g_1.id WHERE g_1.expires_at > transaction_timestamp() GROUP BY g_1.id, g_1.expert_id, g_1.expires_at HAVING sum(a.amount_minor) > 0::numeric ), grant_expiry AS ( SELECT grant_remaining.expert_id, min(grant_remaining.expires_at) AS nearest_expiry_at FROM grant_remaining GROUP BY grant_remaining.expert_id ) SELECT e.id AS expert_id, GREATEST(COALESCE(l.net_minor, 0::bigint), 0::bigint) AS available_credit_minor, GREATEST(COALESCE(l.reserved_minor, 0::bigint), 0::bigint) AS reserved_credit_minor, g.nearest_expiry_at, GREATEST(COALESCE(l.granted_minor, 0::bigint), 0::bigint) AS lifetime_granted_minor, GREATEST(COALESCE(l.spent_minor, 0::bigint), 0::bigint) AS lifetime_spent_minor, GREATEST(COALESCE(l.expired_minor, 0::bigint), 0::bigint) AS lifetime_expired_minor, GREATEST(- COALESCE(l.net_minor, 0::bigint), 0::bigint) AS debt_minor FROM experts e LEFT JOIN ledger_totals l ON l.expert_id = e.id LEFT JOIN grant_expiry g ON g.expert_id = e.id`);

export const hashtagsTaxonomy = pgView("hashtags_taxonomy", {	id: uuid(),
	category: text(),
	tagName: text("tag_name"),
	descriptionContext: text("description_context"),
}).as(sql`SELECT id, parent_category AS category, display_label AS tag_name, synonyms_json::text AS description_context FROM hashtags_db`);

export const residentWorkspaceAccess = pgView("resident_workspace_access", {	userId: uuid("user_id"),
	applicationId: uuid("application_id"),
	hasAccessToWorkBot: boolean("has_access_to_work_bot"),
	accessKind: text("access_kind"),
}).as(sql`SELECT a.user_id, a.id AS application_id, true AS has_access_to_work_bot, 'interview'::text AS access_kind FROM expert_onboarding_applications a JOIN users u ON u.id = a.user_id AND u.active WHERE a.verification_status = 'approved'::text AND a.onboarding_stage IS NOT NULL AND a.archived_at IS NULL AND a.archive_until_date IS NULL AND (EXISTS ( SELECT 1 FROM consent_states s JOIN consents c ON c.id = s.last_decision_id WHERE s.user_id = a.user_id AND s.purpose = 'client_messaging'::text AND expert_card_current_messaging_authority(a.user_id, c.policy_version))) AND (EXISTS ( SELECT 1 FROM expert_onboarding_invoices i JOIN expert_onboarding_payment_facts f ON f.invoice_id = i.id AND f.user_id = a.user_id AND f.admission = 'interview'::text WHERE i.application_id = a.id AND i.user_id = a.user_id AND i.status = 'settled'::text))`);

export const residentSalesApplication = pgView("resident_sales_application", {	id: uuid(),
	userId: uuid("user_id"),
	botId: text("bot_id"),
	botKey: text("bot_key"),
	channelIdentityId: uuid("channel_identity_id"),
	telegramUserId: text("telegram_user_id"),
	chatId: text("chat_id"),
	revision: integer(),
	formVersion: integer("form_version"),
	policyVersion: text("policy_version"),
	educationRequirement: text("education_requirement"),
	draft: jsonb(),
	roleType: text("role_type"),
	targetCategory: text("target_category"),
	taxStatus: text("tax_status"),
	locationCity: text("location_city"),
	socialLinksJson: jsonb("social_links_json"),
	motivationText: text("motivation_text"),
	educationRefsJson: jsonb("education_refs_json"),
	propertyRefsJson: jsonb("property_refs_json"),
	systemCheckResult: jsonb("system_check_result"),
	managerNotes: text("manager_notes"),
	currentField: text("current_field"),
	status: text(),
	progress: text(),
	submittedDraft: jsonb("submitted_draft"),
	submittedAt: timestamp("submitted_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	baseTariffAmount: bigint("base_tariff_amount", { mode: "number" }),
	baseOfferShownAt: timestamp("base_offer_shown_at", { withTimezone: true, mode: 'string' }),
	promoAcceptedFlag: boolean("promo_accepted_flag"),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	finalLockedPrice: bigint("final_locked_price", { mode: "number" }),
	offerExpiryDate: timestamp("offer_expiry_date", { withTimezone: true, mode: 'string' }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	monthlyPriceMinor: bigint("monthly_price_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	packagePriceMinor: bigint("package_price_minor", { mode: "number" }),
	// You can use { mode: "bigint" } if numbers are exceeding js number limitations
	selectedTotalMinor: bigint("selected_total_minor", { mode: "number" }),
	termMonths: integer("term_months"),
	salesStatus: text("sales_status"),
}).as(sql`SELECT f.id, f.user_id, f.bot_id, f.bot_key, f.channel_identity_id, f.telegram_user_id, f.chat_id, f.revision, f.form_version, f.policy_version, f.education_requirement, f.draft, f.role_type, f.target_category, f.tax_status, f.location_city, f.social_links_json, f.motivation_text, f.education_refs_json, f.property_refs_json, f.system_check_result, f.manager_notes, f.current_field, f.status, f.progress, f.submitted_draft, f.submitted_at, f.created_at, f.updated_at, b.base_tariff_amount, b.base_offer_shown_at, s.promo_accepted_flag, l.final_locked_price, s.offer_expiry_date, s.monthly_price_minor, s.package_price_minor, s.selected_total_minor, s.term_months, CASE WHEN l.user_id IS NOT NULL THEN 'ONBOARDING_STARTED'::text WHEN clock_timestamp() >= (b.base_offer_shown_at + '240:00:00'::interval) THEN 'STANDARD_TARIFF_LOCKED'::text ELSE 'UNPAID'::text END AS sales_status FROM residents_applications f JOIN expert_sales_bases b ON b.user_id = f.user_id LEFT JOIN LATERAL ( SELECT s_1.id, s_1.base_id, s_1.user_id, s_1.choice_id, s_1.promo_accepted_flag, s_1.term_months, s_1.monthly_price_minor, s_1.package_price_minor, s_1.selected_total_minor, s_1.energy_discount_bps, s_1.package_discount_bps, s_1.selected_at, s_1.offer_expiry_date FROM expert_sales_selections s_1 WHERE s_1.base_id = b.id ORDER BY s_1.selected_at DESC, s_1.id DESC LIMIT 1) s ON true LEFT JOIN expert_sales_paid_locks l ON l.user_id = f.user_id`);