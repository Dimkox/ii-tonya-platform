import {readFileSync,writeFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
const config=JSON.parse(readFileSync('/tmp/verification-form-20261026.compose.json','utf8'));
const env=config.services.postgres.environment;
const url=`postgresql://${encodeURIComponent(env.POSTGRES_USER)}:${encodeURIComponent(env.POSTGRES_PASSWORD)}@127.0.0.1:55483/${env.POSTGRES_DB}`;
const run=spawnSync('pnpm',['exec','vitest','run',...process.argv.slice(3)],{encoding:'utf8',env:{...process.env,II_TONYA_TEST_POSTGRES_ADMIN_URL:url},timeout:240000,maxBuffer:10*1024*1024});
writeFileSync(`.superpowers/sdd/native-scheduling-20261027/${process.argv[2]}.log`,`${run.stdout}\n${run.stderr}\nexit=${run.status}`.split(url).join('[redacted]').split(env.POSTGRES_PASSWORD).join('[redacted]'));
console.log(JSON.stringify({exit:run.status,signal:run.signal}));
process.exitCode=run.status??1;
