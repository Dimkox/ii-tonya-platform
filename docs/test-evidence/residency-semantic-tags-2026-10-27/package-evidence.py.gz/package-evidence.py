from pathlib import Path
import gzip,hashlib,json,subprocess
src=Path('.superpowers/sdd/residency-semantic-tags-20261027');out=Path('docs/test-evidence/residency-semantic-tags-2026-10-27');out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
files=[]
paths=[p for p in src.rglob('*') if p.is_file() and p.suffix in ['.log','.json','.ts','.mjs','.py','.png'] and p.name not in ['introspected-schema.ts','owned-formatted-files.json']]
# The retained historical harness must be restored to its original test path to run.
for p in sorted(paths):
 raw=p.read_bytes();name=str(p.relative_to(src)).replace('/','--')+'.gz';packed=gzip.compress(raw,compresslevel=9,mtime=0);(out/name).write_bytes(packed)
 item={'file':name,'sha256':sha(packed),'bytes':len(packed),'rawSha256':sha(raw),'rawBytes':len(raw),'originalPath':str(p)}
 if p.suffix=='.log' and p.with_suffix('.result.json').exists():
  item.update(json.loads(p.with_suffix('.result.json').read_text()));item['recordedResult']=p.with_suffix('.result.json').name+'.gz'
 files.append(item)
sourcepaths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
sourcepaths=sorted(set(p for p in sourcepaths if p not in ['AGENT-STATUS.md','docs/superpowers/implementation-artifacts/spec-residency-semantic-tags.md','docs/test-evidence/residency-semantic-tags-coordinator-2026-10-27.md'] and not p.startswith('docs/test-evidence/')))
m={'kind':'local-synthetic-semantic-tags-S3b','baselineCommit':'254c8c169cbb8432654a46de206bd20500cecc3f','controlCommit':'e0e2095664cb762811983e18b187500ad3ef329f','productionEvidence':False,'compression':'gzip level9 mtime0; one original artifact per file','files':files,'finalSources':[{'path':p,'sha256':sha(Path(p).read_bytes())} for p in sourcepaths]}
(out/'manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False)+'\n')
lines=[sha(p.read_bytes())+'  '+p.name for p in sorted(out.iterdir()) if p.name!='ARTIFACTS.sha256'];(out/'ARTIFACTS.sha256').write_text('\n'.join(lines)+'\n')
print(json.dumps({'artifacts':len(files),'finalSources':len(sourcepaths),'manifestSha256':sha((out/'manifest.json').read_bytes())}))
