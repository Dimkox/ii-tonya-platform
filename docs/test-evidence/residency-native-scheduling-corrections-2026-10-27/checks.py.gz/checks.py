import subprocess,time,json,sys
from pathlib import Path
base=Path('.superpowers/sdd/native-scheduling-corrections-20261027')
checks=[
 ('history-guard',['pnpm','exec','vitest','run','tests/repo/migration-history-integrity.test.ts']),
 ('journal-parity',['pnpm','exec','vitest','run','tests/repo/hybrid-message-gateway-schema-parity.test.ts']),
 ('scope-guard',['pnpm','exec','vitest','run','tests/repo/scope-boundary.test.ts']),
 ('state-guard',['pnpm','exec','vitest','run','tests/repo/resident-native-scheduling-state.test.ts']),
 ('renderer',['pnpm','exec','vitest','run','packages/worker/src/booking-notification-renderer.test.ts']),
 ('query-service',['pnpm','exec','vitest','run','packages/application/src/expert-telegram-query-service.test.ts']),
 ('runtime-controls',['pnpm','exec','vitest','run','apps/worker/src/booking-notifications.test.ts']),
]
for name,args in checks:
 start=time.monotonic();r=subprocess.run(args,text=True,capture_output=True);(base/(name+'.log')).write_text(r.stdout+r.stderr);(base/(name+'.result.json')).write_text(json.dumps({'command':args,'durationSeconds':round(time.monotonic()-start,3),'exitCode':r.returncode},indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
