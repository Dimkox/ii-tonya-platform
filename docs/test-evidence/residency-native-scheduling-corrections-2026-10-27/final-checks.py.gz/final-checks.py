from pathlib import Path
import subprocess,time,json,sys
base=Path('.superpowers/sdd/native-scheduling-corrections-20261027')
files=sorted(set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()))
checks=[('environment',['pwsh','-File','scripts/check-development-environment.ps1','-RequireDocker']),('types',['pnpm','typecheck']),('build',['pnpm','build']),('lint',['pnpm','exec','eslint',*[p for p in files if p.endswith(('.ts','.tsx','.js','.mjs'))]]),('format',['pnpm','exec','prettier','--check',*[p for p in files if p.endswith(('.ts','.json','.md'))]]),('whitespace',['git','diff','--check'])]
for name,args in checks:
 start=time.monotonic();r=subprocess.run(args,text=True,capture_output=True);(base/(name+'.log')).write_text(r.stdout+r.stderr);(base/(name+'.result.json')).write_text(json.dumps({'command':args,'durationSeconds':round(time.monotonic()-start,3),'exitCode':r.returncode},indent=2)+'\n');print(name,r.returncode,round(time.monotonic()-start,2),flush=True)
 if r.returncode:sys.exit(r.returncode)
