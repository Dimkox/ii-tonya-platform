from pathlib import Path
import subprocess,os,sys,json
base=Path('.superpowers/sdd/native-scheduling-corrections-20261027')
original=Path('.superpowers/sdd/native-scheduling-20261027');saved=Path('.superpowers/sdd/native-scheduling-20261027-preserved-r6')
assert original.is_dir() and not saved.exists()
original.rename(saved)
try:
 env=dict(os.environ);env.pop('II_TONYA_NATIVE_BROWSER_FIXTURE_DIR',None)
 (base/(sys.argv[1]+'.isolation.json')).write_text(json.dumps({'ignoredTaskFixtureDirectoryPresent':original.exists(),'browserFixtureExportConfigured':False,'restoredAfterRun':True},indent=2)+'\n')
 r=subprocess.run(['node',str(base/'run.mjs'),*sys.argv[1:]],env=env)
 raise SystemExit(r.returncode)
finally:
 assert not original.exists();saved.rename(original)
