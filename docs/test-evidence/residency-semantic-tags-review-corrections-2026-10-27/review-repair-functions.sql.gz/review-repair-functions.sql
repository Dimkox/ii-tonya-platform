-- Repair comparisons retain every non-selection answer and count scoped occurrences.
CREATE FUNCTION resident_tag_nonselection_content(d expert_card_drafts) RETURNS jsonb LANGUAGE sql STABLE AS $$
 SELECT (to_jsonb(d)-ARRAY['semantic_tags','tag_preview','revision','status','owner_confirmed_digest','preview_page','preview_token_digest','preview_content_digest','approved_review_id','updated_at']) || jsonb_build_object(
 'rich_profile',CASE WHEN d.rich_profile IS NULL THEN NULL ELSE jsonb_set(d.rich_profile,'{services}',coalesce((SELECT jsonb_agg(s-'tags' ORDER BY n) FROM jsonb_array_elements(d.rich_profile->'services') WITH ORDINALITY a(s,n)),'[]')) END,
 'rich_guided',d.rich_guided-'tags','rich_pending_services',coalesce((SELECT jsonb_agg(s-'tags' ORDER BY n) FROM jsonb_array_elements(d.rich_pending_services) WITH ORDINALITY a(s,n)),'[]'))
$$;
--> statement-breakpoint
CREATE FUNCTION resident_tag_selection_items(d expert_card_drafts) RETURNS TABLE(scope text,label text) LANGUAGE sql STABLE AS $$
 SELECT 'profile',jsonb_array_elements_text(d.semantic_tags)
 UNION ALL SELECT 'guided',jsonb_array_elements_text(coalesce(d.rich_guided->'tags','[]'))
 UNION ALL SELECT 'service:'||n,jsonb_array_elements_text(coalesce(s->'tags','[]')) FROM jsonb_array_elements(coalesce(d.rich_profile->'services','[]')) WITH ORDINALITY a(s,n)
 UNION ALL SELECT 'pending:'||n,jsonb_array_elements_text(coalesce(s->'tags','[]')) FROM jsonb_array_elements(d.rich_pending_services) WITH ORDINALITY a(s,n)
 UNION ALL SELECT 'catalogue:'||h.id,h.display_label FROM expert_card_draft_tags t JOIN hashtags_db h ON h.id=t.tag_id WHERE t.draft_id=d.id
$$;
--> statement-breakpoint
CREATE FUNCTION resident_tag_obsolete(label text) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
BEGIN
 RETURN EXISTS(SELECT 1 FROM hashtags_db h WHERE resident_tag_identity(label)='catalogue:'||h.id::text AND NOT h.is_active)
 OR (resident_safety_assess(jsonb_build_object('tag',label),0)->>'blocked')::boolean;
END $$;
--> statement-breakpoint
CREATE FUNCTION resident_tag_repair_allowed(previous expert_card_drafts,current_draft expert_card_drafts) RETURNS boolean LANGUAGE sql VOLATILE AS $$
 SELECT current_draft.status IN('collecting','changes_requested') AND current_draft.owner_confirmed_digest IS NULL
 AND resident_tag_nonselection_content(previous)=resident_tag_nonselection_content(current_draft)
 AND NOT EXISTS(SELECT * FROM resident_tag_selection_items(current_draft) EXCEPT ALL SELECT * FROM resident_tag_selection_items(previous))
 AND EXISTS(SELECT 1 FROM (SELECT * FROM resident_tag_selection_items(previous) EXCEPT ALL SELECT * FROM resident_tag_selection_items(current_draft)) removed WHERE resident_tag_obsolete(label))
$$;
--> statement-breakpoint
CREATE FUNCTION resident_tag_unselected_safe(d expert_card_drafts) RETURNS boolean LANGUAGE plpgsql VOLATILE AS $$
DECLARE fields jsonb:='{}'; f record;
BEGIN
 FOR f IN SELECT * FROM jsonb_each_text(resident_card_pre_semantic_fields(d.id)) LOOP
  IF f.key LIKE 'tag:%' THEN CONTINUE; END IF;
  fields:=fields||jsonb_build_object(f.key,CASE WHEN f.key='rich:guided' OR f.key LIKE 'rich:service:%' OR f.key LIKE 'rich:pending:%' THEN (f.value::jsonb-'tags')::text ELSE f.value END);
 END LOOP;
 RETURN NOT (resident_safety_assess(fields,d.revision)->>'blocked')::boolean;
END $$;
--> statement-breakpoint
