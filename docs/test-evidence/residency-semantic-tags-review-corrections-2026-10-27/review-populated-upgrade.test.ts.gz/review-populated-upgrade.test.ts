import {readFileSync} from "node:fs";
import {
  createExpertCardComposition,
  type ExpertCardCapability,
} from "../../apps/api/src/expert-card-composition.js";
import type { RuntimeConfig } from "../../packages/config/src/index.js";
import { PostgresPrivacyRepository } from "../../packages/db/src/repositories/privacy-repository.js";
import { richDocumentFixtures } from "../support/resident-rich-document-fixtures.js";
import { createRequire } from "node:module";
import { telegramWebhookRoutes } from "../../apps/api/src/routes/telegram-webhook.js";
import { PostgresExpertOnboardingMainPaymentRepository } from "../../packages/db/src/repositories/expert-onboarding-main-payment-repository.js";
import { createHash, randomUUID } from "node:crypto";
import { afterAll, beforeAll, it, expect } from "vitest";
import { sql } from "drizzle-orm";
import {
  createYooKassaClient,
  YooKassaOnboardingPaymentVerifier,
} from "@ii-tonya/integrations";
import { verifyExpertOfferProfile } from "../../packages/db/src/repositories/expert-offer-v2.js";
import { PostgresExpertPromoRepository } from "../../packages/db/src/repositories/expert-promo-repository.js";
import { PostgresExpertVerificationRepository } from "../../packages/db/src/repositories/expert-verification-repository.js";
import { PostgresExpertCardRepository } from "../../.superpowers/sdd/residency-semantic-tags-20261027/baseline/expert-card-repository.js";
import {
  startExpertReferralTestDatabase,
  type ExpertReferralTestDatabase,
} from "../../packages/db/src/testkit/expert-referral.js";
import { seedClientConsent } from "../../packages/db/src/testkit/client-consent.js";
import { createExpertCardService } from "../../packages/application/src/expert-card-service.js";

const promoScope = { botId: "717171", botKey: "core-promo" };
const workScope = { botId: "818181", botKey: "core-work" };
const hash = (s: string) => createHash("sha256").update(s).digest("hex");
let database: ExpertReferralTestDatabase;
let verification: PostgresExpertVerificationRepository;
let promo: PostgresExpertPromoRepository;
let manager: { sessionHash: string; token: string };
let tariffId: string;
let sequence = 970000;
const event = <T extends { botId: string }>(scope: T) => {
  const requestKey = `${scope.botId}:${++sequence}`;
  return { ...scope, requestKey, requestDigest: hash(requestKey) };
};
async function staff() {
  const userId = await database.createUser();
  const token = `synthetic_staff_${randomUUID()}`;
  const sessionHash = `sha256:${hash(token)}`;
  await database.db.execute(
    sql`insert into admin_sessions(session_id_hash,admin_id,mfa_verified_at,expires_at) values(${sessionHash},${userId}::uuid,clock_timestamp(),clock_timestamp()+interval '1 hour')`,
  );
  await database.db.execute(
    sql`insert into admin_role_assignments(admin_id,role) values(${userId}::uuid,'support')`,
  );
  return { token, sessionHash };
}
function client(body: Record<string, unknown>, calls: string[] = []) {
  return createYooKassaClient(
    { mode: "test", shopId: "test-shop", secretKey: "synthetic-fixture-only" },
    async (url, init) => {
      calls.push(`${String(init.method)} ${url}`);
      return new Response(JSON.stringify(body), {
        status: 200,
        headers: { "content-type": "application/json" },
      });
    },
  );
}
function providerPayment(
  id: string,
  orderId: string,
  minor: string,
  metadata: Record<string, string> = {},
) {
  const amount = BigInt(minor);
  return {
    id,
    status: "succeeded",
    paid: true,
    test: true,
    amount: {
      value: `${amount / 100n}.${String(amount % 100n).padStart(2, "0")}`,
      currency: "RUB",
    },
    created_at: new Date(Date.now() - 1000).toISOString(),
    captured_at: new Date().toISOString(),
    metadata: { order_id: orderId, ...metadata },
    refundable: true,
  };
}
type ExistingActor = { userId: string; telegramUserId: string };
async function onboarding(refCode?: string, existing?: ExistingActor) {
  const userId = existing?.userId ?? (await database.createUser());
  const telegramUserId = existing?.telegramUserId ?? String(++sequence);
  const scope = { ...promoScope, telegramUserId, chatId: telegramUserId };
  if (!existing)
    await database.db.execute(
      sql`insert into channel_identities(user_id,provider,external_id,bot_key,external_chat_id,status) values(${userId}::uuid,'telegram',${telegramUserId},${scope.botKey},${telegramUserId},'active')`,
    );
  const consent = await seedClientConsent(
    database.db,
    userId,
    "client_messaging",
  );
  await database.db.execute(
    sql`insert into expert_promo_enrollments(user_id,channel_identity_id,bot_id,presentation_id,policy_version,status) select ${userId}::uuid,ci.id,${scope.botId},c.presentation_id,'client-messaging-v1','granted' from channel_identities ci join consents c on c.id=${consent.decisionId}::uuid where ci.user_id=${userId}::uuid and ci.provider='telegram' and ci.bot_key=${scope.botKey} and ci.external_id=${scope.telegramUserId} and ci.external_chat_id=${scope.chatId} and ci.status='active' on conflict(user_id) do nothing`,
  );
  await promo.register({ ...event(scope), ...(refCode ? { refCode } : {}) });
  const profile = await promo.saveProfile({
    ...event(scope),
    cityCode: "kazan",
    millionCity: false,
    serviceFormat: "offline",
    ticketMinor: "300000",
    participantKind: "expert",
  });
  await verifyExpertOfferProfile(database.db, {
    sessionHash: manager.sessionHash,
    userId,
    revision: profile.revision,
  });
  const quote = await promo.createQuote({
    ...event(scope),
    tariffVersionId: tariffId,
    termMonths: 1,
  });
  const application = await promo.createApplication({
    ...event(scope),
    quoteId: quote.id,
  });
  const decision = await verification.decide({
    sessionHash: manager.sessionHash,
    applicationId: application.applicationId,
    decision: "approved",
    reasonCode: "identity_verified",
    idempotencyKey: randomUUID(),
  });
  const invoice = await verification.invoiceForOwner(
    scope,
    decision.invoiceId!,
  );
  if (!invoice) throw new Error("fixture_invoice_missing");
  const providerObjectId = `synthetic_${randomUUID()}`;
  await verification.bindPayment(invoice.id, {
    id: invoice.operationId,
    providerObjectId,
    userId,
    purpose: "onboarding",
    amountMinor: "300000",
    currency: "RUB",
    mode: "test",
  });
  const binding = await verification.findOnboardingPaymentBinding(invoice.id);
  if (!binding) throw new Error("fixture_onboarding_binding_missing");
  return {
    userId,
    scope,
    applicationId: application.applicationId,
    invoice,
    binding,
  };
}

async function paid() {
  const f = await onboarding();
  const body = providerPayment(
    f.binding.providerObjectId,
    f.binding.invoiceId,
    "300000",
    {
      user_id: f.userId,
      purpose: f.binding.purpose,
      operation_id: f.binding.operationId,
    },
  );
  const verifier = new YooKassaOnboardingPaymentVerifier(
    client(body),
    verification,
  );
  const proof = await verifier.verify(f.invoice.id);
  if (!proof) throw new Error("fixture_verified_proof_missing");
  await verification.settleVerified(proof);
  return { ...f, proof };
}
function cards(richOnboarding = true) {
  return new PostgresExpertCardRepository(database.db, {
    richOnboarding,
    messagingConsentPolicyVersion: "client-messaging-v1",
    workBotId: workScope.botId,
    workBotKey: workScope.botKey,
  });
}
async function linked(richOnboarding = true) {
  const f = await paid();
  const card = cards(richOnboarding);
  const token = await card.issueWorkHandoff(event(f.scope));
  if (token.kind !== "issued") throw new Error("fixture_handoff_missing");
  const scope = {
    ...workScope,
    telegramUserId: f.scope.telegramUserId,
    chatId: f.scope.chatId,
  };
  await card.redeemWorkHandoff({ ...event(scope), token: token.token });
  return { ...f, card, work: scope };
}
beforeAll(async () => {
  database = await startExpertReferralTestDatabase(async db=>{await db.transaction(async tx=>{const journal=JSON.parse(readFileSync("packages/db/migrations/meta/_journal.json","utf8"));for(const e of journal.entries.filter((e:{idx:number})=>e.idx<=68))for(const statement of readFileSync("packages/db/migrations/"+e.tag+".sql","utf8").split("--> statement-breakpoint").filter((s:string)=>s.trim()))await tx.execute(sql.raw(statement));});});
  await database.enableExpertReferralCommands();
  expect(
    (await database.db.execute(sql`show server_version_num`)).rows[0]
      ?.server_version_num,
  ).toBe("170005");
  verification = new PostgresExpertVerificationRepository(database.db, {
    providerMode: "test",
    messagingConsentPolicyVersion: "client-messaging-v1",
  });
  promo = new PostgresExpertPromoRepository(database.db, {
    messagingConsentPolicyVersion: "client-messaging-v1",
  });
  manager = await staff();
  tariffId = await database.createResidencyTariff({
    tariffKey: "PRO",
    displayName: "PRO",
    priceMinor: 999000,
    durationSeconds: 2592000,
  });
}, 120000);
afterAll(async () => {
  await database?.stop();
}, 120000);
async function secondRichFixture() {
  const f = await linked();
  const repo = new PostgresExpertCardRepository(database.db, {
    richOnboarding: true,
    workBotId: workScope.botId,
    workBotKey: workScope.botKey,
    messagingConsentPolicyVersion: "client-messaging-v1",
    photoCustody: {
      read: async () => new Uint8Array([1]),
      put: async () => true,
      presign: async (i) => "https://example.com/private-photo/" + i.custodyId,
    },
  });
  const bio =
    "Помогаю разобраться в жизненных задачах и выбрать собственные следующие шаги без обещаний результата.";
  const service = {
    id: randomUUID(),
    title: "Консультация",
    format: "ONLINE",
    eventDelivery: null,
    durationMinutes: 60,
    price: { kind: "exact", minRub: "1000.00", maxRub: null },
    description: bio,
    audience: "Взрослые",
    result: "План",
    expiryDate: null,
    detailsUrl: null,
    tags: ["поддержка"],
  };
  const workflow = () => repo.getWorkflow(f.work);
  const revision = async () => (await workflow())!.revision;
  const photos = async () => {
    const ids: string[] = [];
    for (let i = 0; i < 3; i++) {
      const e = event(f.work),
        reference = "telegram:file:second_" + sequence;
      const entry = await repo.addEntry({
        ...e,
        expectedRevision: await revision(),
        entry: { kind: "photo", reference },
      });
      ids.push(
        (
          await repo.ingestRichPhoto({
            ...e,
            expectedRevision: entry.revision,
            reference,
            size: 1,
            mimeType: "image/jpeg",
          })
        ).id,
      );
    }
    return ids;
  };
  const initialPhotos = await photos();
  await repo.richAction({
    ...event(f.work),
    expectedRevision: await revision(),
    action: "patch",
    value: {
      fullName: "Анна",
      specialization: "Консультант",
      bio,
      socialLinks: ["https://example.com/profile"],
      photos: initialPhotos,
      onlineRoomType: "STATIC_LINK",
      staticRoomLink: "https://example.com/room",
      services: [0,1,2].map(i=>({...service,id:randomUUID(),title:"Услуга "+i,tags:[...Array.from({length:8},(_,j)=>i===0&&j===0?"#тревожность":"Авторская тема "+(i*8+j)),...(i===1?["#тревожность"]:[])]})),
    },
  });
  const approve = async () => {
    let rev = await revision();
    rev = (
      await repo.editPublicCard({
        sessionHash: manager.sessionHash,
        applicationId: f.applicationId,
        expectedRevision: rev,
        idempotencyKey: randomUUID(),
        publicCard: {
          displayName: "Анна",
          profession: "Консультант",
          city: "Казань",
          summary: bio,
        },
      })
    ).revision;
    let preview = await repo.richAction({
      ...event(f.work),
      expectedRevision: rev,
      action: "preview",
    });
    while (preview.pageText!.split("\n").at(-1)!.startsWith("/card_preview")) {
      const parts = preview.pageText!.split("\n").at(-1)!.split(" ");
      preview = await repo.richAction({
        ...event(f.work),
        expectedRevision: rev,
        action: "preview",
        page: Number(parts[2]),
        token: parts[3]!,
      });
    }
    await repo.richAction({
      ...event(f.work),
      expectedRevision: rev,
      action: "confirm",
      token: preview.pageText!.split(" ").at(-1)!,
    });
    await repo.submitDraft({ ...event(f.work), expectedRevision: rev });
    const detail = (await repo.readDraft(
      manager.sessionHash,
      f.applicationId,
    ))!;
    return repo.reviewCard({
      sessionHash: manager.sessionHash,
      applicationId: f.applicationId,
      expectedRevision: rev,
      idempotencyKey: randomUUID(),
      action: "approve",
      warningAcknowledgment: detail.safety.digest,
    });
  };
  return { ...f, repo, service, photos, initialPhotos, revision, approve };
}

it("R2 populated over20 repeated inactive occurrence is removable without reducing unique count or rewriting history",async()=>{
 const f=await secondRichFixture(),approved=await f.approve();
 const tables=["resident_card_versions","expert_card_reviews","expert_onboarding_invoices","expert_onboarding_payment_facts"];
 const snapshot=async()=>Object.fromEntries(await Promise.all(tables.map(async name=>[name,(await database.db.execute(sql.raw("select coalesce(jsonb_agg(to_jsonb(t) order by to_jsonb(t)::text),'[]'::jsonb) value from "+name+" t"))).rows[0]!.value])));
 const before=await snapshot();
 for(const statement of readFileSync("packages/db/migrations/0069_resident_semantic_tags.sql","utf8").split("--> statement-breakpoint").filter(s=>s.trim()))await database.db.execute(sql.raw(statement));
 expect(await snapshot()).toEqual(before);
 const {PostgresExpertCardRepository:Current}=await import("../../packages/db/src/repositories/expert-card-repository.js");
 const current=new Current(database.db,{workBotId:workScope.botId,workBotKey:workScope.botKey,messagingConsentPolicyVersion:"client-messaging-v1",richOnboarding:true});
 expect((await current.getWorkflow(f.work))!.status).toBe("approved");
 const originalProfile=(await database.db.execute<{rich_profile:{services:{tags:string[]}[]}}>(sql`select rich_profile from expert_card_drafts where id=${approved.draftId}::uuid`)).rows[0]!.rich_profile;
 const moved=structuredClone(originalProfile);moved.services[0]!.tags.splice(1,1);moved.services[1]!.tags.push(moved.services[0]!.tags[1]!);
 await expect(database.db.execute(sql`update expert_card_drafts set rich_profile=${JSON.stringify(moved)}::jsonb,revision=revision+1,status='collecting',approved_review_id=null where id=${approved.draftId}::uuid`)).rejects.toThrow();
 await database.db.execute(sql`update hashtags_db set is_active=false where tag_value='тревожность'`);
 let r=await current.tagAction({...event(f.work),action:"recommend",scope:"service:1"});
 // Deselect proposed format metadata, then remove one inherited tag:24 ->23.
 for(const c of r.preview!.candidates)if(r.preview!.selected.includes(c.label))r=await current.tagAction({...event(f.work),action:"toggle",token:r.preview!.token,index:r.preview!.choices.indexOf(c.label)});
 r=await current.tagAction({...event(f.work),action:"toggle",token:r.preview!.token,index:0});
 await current.tagAction({...event(f.work),action:"confirm",token:r.preview!.token});
 expect((await database.db.execute(sql`select count(distinct identity)::int n from expert_card_drafts d cross join lateral resident_selected_tags(d) t where d.id=${approved.draftId}::uuid`)).rows[0]!.n).toBe(24);
 const state=(await database.db.execute(sql`select rich_profile,resident_rich_digest(d) digest from expert_card_drafts d where id=${approved.draftId}::uuid`)).rows[0]!;
 expect(state.rich_profile).toMatchObject({fullName:"Анна",bio:expect.stringContaining("Помогаю")});
 await expect(database.db.execute(sql`update expert_card_drafts d set owner_confirmed_digest=resident_rich_digest(d) where id=${approved.draftId}::uuid`)).rejects.toThrow();
 r=await current.tagAction({...event(f.work),action:"recommend",scope:"service:2"});
 for(const c of r.preview!.candidates)if(r.preview!.selected.includes(c.label))r=await current.tagAction({...event(f.work),action:"toggle",token:r.preview!.token,index:r.preview!.choices.indexOf(c.label)});
 r=await current.tagAction({...event(f.work),action:"toggle",token:r.preview!.token,index:r.preview!.choices.indexOf("#тревожность")});
 for(let i=0;i<3;i++)r=await current.tagAction({...event(f.work),action:"toggle",token:r.preview!.token,index:i});
 await current.tagAction({...event(f.work),action:"confirm",token:r.preview!.token});
 expect((await database.db.execute(sql`select count(distinct identity)::int n from expert_card_drafts d cross join lateral resident_selected_tags(d) t where d.id=${approved.draftId}::uuid`)).rows[0]!.n).toBe(20);
 expect(await snapshot()).toEqual(before);
 console.log("Populated0068->0069: immutable24tag approval and financial facts unchanged; explicit repeated obsolete occurrence removal keeps24 unique, then reaches20; above20 confirmation rejected.");
},30000);
