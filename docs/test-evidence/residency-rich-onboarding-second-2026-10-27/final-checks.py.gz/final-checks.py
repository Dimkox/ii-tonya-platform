import subprocess,sys
paths=['apps/web/src/expert-card-client.ts','apps/web/src/expert-card-client.test.ts','apps/web/src/expert-card-view.ts','packages/db/src/repositories/expert-card-repository.ts','tests/integration/resident-rich-onboarding.test.ts','tests/repo/expert-referral-scope-guards.test.ts','tests/repo/migration-history-integrity.test.ts','tests/repo/resident-rich-onboarding-state.test.ts','tests/repo/support/payment-scope-boundary-core.ts','packages/db/migrations/meta/_journal.json','packages/db/migrations/meta/0068_snapshot.json','packages/db/migrations/state/0068_manifest.json','docs/runbooks/resident-rich-onboarding.md','docs/test-evidence/residency-rich-onboarding-second-2026-10-27.md']
for name,args in [('format-final',['pnpm','exec','prettier','--check',*paths]),('whitespace',['git','diff','--check'])]:
 r=subprocess.run([sys.executable,'.superpowers/sdd/rich-onboarding-second-20261027/run.py',name+'.log',*args])
 if r.returncode:sys.exit(r.returncode)
