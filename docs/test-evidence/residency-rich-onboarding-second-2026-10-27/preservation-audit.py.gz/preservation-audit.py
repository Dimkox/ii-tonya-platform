from pathlib import Path
import subprocess,hashlib,json,gzip
root=Path.cwd();control='be8a0c7d71cc5ed22b551cc2ce1cc6332adaed3e'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',control,'packages/db/migrations','docs/test-evidence/residency-rich-onboarding-2026-10-27','docs/test-evidence/residency-rich-onboarding-corrections-2026-10-27'],text=True).splitlines()
frozen=[p for p in paths if p.startswith('docs/test-evidence/') or (p.startswith('packages/db/migrations/') and p!='packages/db/migrations/meta/_journal.json')]
for p in frozen:
 assert Path(p).read_bytes()==subprocess.check_output(['git','show',control+':'+p]),p
counts=[]
for folder in ['residency-rich-onboarding-2026-10-27','residency-rich-onboarding-corrections-2026-10-27']:
 d=Path('docs/test-evidence')/folder;m=json.loads((d/'manifest.json').read_text())
 for row in m['files']:
  packed=(d/row['file']).read_bytes();raw=gzip.decompress(packed)
  assert hashlib.sha256(packed).hexdigest()==row['sha256'] and hashlib.sha256(raw).hexdigest()==row['rawSha256']
 counts.append(len(m['files']))
base=Path('packages/db/migrations/0066_resident_rich_onboarding.sql').read_text();start=base.index('CREATE OR REPLACE FUNCTION enforce_expert_published_card_source()');old=base[start:base.index('--> statement-breakpoint',start)]
new=Path('packages/db/migrations/0068_resident_latest_approved_publication.sql').read_text();new=new[new.index('CREATE OR REPLACE FUNCTION'):]
assert new==old.replace("(d.approved_review_id=r.id AND d.status='approved')","(r.id=(SELECT latest.review_id FROM resident_card_versions latest WHERE latest.draft_id=d.id ORDER BY latest.revision DESC LIMIT 1))")
print(json.dumps({'frozenArtifactsVerified':len(frozen),'archiveCountsVerified':counts,'publicationTriggerOnlyChangedLatestApprovalSelection':True,'paidCoverageAdmissionConsentSafetyPausedAbuseGuards':'byte-preserved from0066','rootOwnedDocuments':'excluded'}))
