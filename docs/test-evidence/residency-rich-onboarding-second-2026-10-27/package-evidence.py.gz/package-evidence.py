from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd(); local=root/'.superpowers/sdd/rich-onboarding-second-20261027'; dest=root/'docs/test-evidence/residency-rich-onboarding-second-2026-10-27';dest.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
secret=json.loads(Path('/tmp/verification-form-20261026.compose.json').read_text())['services']['postgres']['environment']['POSTGRES_PASSWORD'].encode()
files=sorted([p for p in local.iterdir() if p.is_file() and (p.suffix in ['.log','.json','.ts','.mjs','.py','.md','.png'])])

manifest={'kind':'local-synthetic-rich-onboarding-second-correction-R4-R5-R6','controlCommit':'be8a0c7d71cc5ed22b551cc2ce1cc6332adaed3e','reviewedRuntimeCommit':'5602413c7dca6809569d788b9d8254df80846cc8','historicalFixtureCommit':'219f8e0c9d0938fccb4188cf0081f71b3f8b2db9','historicalEvidenceManifest':'docs/test-evidence/residency-rich-onboarding-2026-10-27/manifest.json','historicalEvidenceManifestSha256':sha((root/'docs/test-evidence/residency-rich-onboarding-2026-10-27/manifest.json').read_bytes()),'firstCorrectionManifest':'docs/test-evidence/residency-rich-onboarding-corrections-2026-10-27/manifest.json','firstCorrectionManifestSha256':sha((root/'docs/test-evidence/residency-rich-onboarding-corrections-2026-10-27/manifest.json').read_bytes()),'compression':'gzip level9 mtime0; one original artifact per file','productionEvidence':False,'files':[]}
for p in files:
 raw=p.read_bytes()
 if secret in raw:raise RuntimeError('secret detected in retained evidence; refusing archive')
 name=p.name+'.gz';packed=gzip.compress(raw,compresslevel=9,mtime=0);(dest/name).write_bytes(packed)
 row={'file':name,'sha256':sha(packed),'bytes':len(packed),'rawSha256':sha(raw),'rawBytes':len(raw),'originalPath':str(p.relative_to(root))}
 if p.suffix=='.log':
  side=p.with_suffix('.result.json')
  if side.exists():
   result=json.loads(side.read_text())
   if result['logSha256']!=sha(raw):raise RuntimeError('recorded log hash mismatch')
   row.update(result);row['recordedResult']=side.name+'.gz'
  else:row.update({'command':None,'exitCode':None,'metadataNote':'Generated introspection output; parent reconstruction command has the recorded exit code.'})
 manifest['files'].append(row)
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['pnpm','exec','prettier','--write',str(dest/'manifest.json')],check=True,stdout=subprocess.PIPE)
for row in manifest['files']:
 packed=(dest/row['file']).read_bytes();raw=gzip.decompress(packed)
 assert sha(packed)==row['sha256'] and sha(raw)==row['rawSha256'] and len(raw)==row['rawBytes']
print(json.dumps({'archives':len(files),'manifestSha256':sha((dest/'manifest.json').read_bytes()),'hashesVerified':True,'secretScan':'no protected database password found; protected config, environment files, runtimes and dependency stores excluded'}))
