import {createServer} from 'node:http';import {spawn} from 'node:child_process';import {createRequire} from 'node:module';import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';import {tmpdir} from 'node:os';import assert from 'node:assert/strict';
const req=createRequire(new URL('../../../package.json',import.meta.url));const {build}=createRequire(req.resolve('tsup'))('esbuild');
const compiled=await build({stdin:{contents:`import {renderExpertCardReview,bindExpertCardReview} from './apps/web/src/expert-card-view.ts';import {createExpertCardClient} from './apps/web/src/expert-card-client.ts';document.body.innerHTML='<button id="logout">Выйти</button>'+renderExpertCardReview();let client=createExpertCardClient(async(path,body)=>{const r=await fetch('/v1/admin/expert-cards'+path,{method:body?'POST':'GET',headers:{authorization:'Bearer synthetic-session','content-type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});return r.json()});const ui=bindExpertCardReview(document.body,{getClient:()=>client,onUnauthorized:()=>{client=undefined}});ui.sync();document.querySelector('#logout').onclick=()=>{client=undefined;ui.reset()};`,resolveDir:process.cwd()},bundle:true,write:false,format:'iife',platform:'browser'});
const fixture=JSON.parse(await readFile('.superpowers/sdd/rich-onboarding-second-20261027/manager-api-fixture.json','utf8'));
const detail=fixture.detail.item,id=detail.applicationId;const grants=[];
assert.equal(fixture.retainedRows,12);
const server=createServer(async(q,s)=>{
 if(q.url==='/'){s.setHeader('content-type','text/html');s.end('<!doctype html><meta charset="utf-8"><script src="/bundle.js" defer></script><body></body>');return}
 if(q.url==='/bundle.js'){s.setHeader('content-type','text/javascript');s.end(compiled.outputFiles[0].text);return}
 if(!q.url.startsWith('/v1/')){s.statusCode=404;s.end();return}
 assert.equal(q.headers.authorization,'Bearer synthetic-session');s.setHeader('content-type','application/json');s.setHeader('cache-control','no-store');
 const mediaId=q.url.match(/\/media\/([^/]+)\/link$/)?.[1];
 if(mediaId){assert.equal(q.method,'POST');assert(fixture.links[mediaId]);grants.push(mediaId);s.end(JSON.stringify(fixture.links[mediaId]));return}
 s.end(JSON.stringify(q.url.endsWith(id)?fixture.detail:{items:[detail]}));
});await new Promise(r=>server.listen(0,'127.0.0.1',r));
const profile=await mkdtemp(tmpdir()+'/rich-browser-');const chrome=spawn('/usr/bin/google-chrome',['--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking','--no-proxy-server','--remote-debugging-port=0','--user-data-dir='+profile,'about:blank'],{stdio:'ignore'});const wait=ms=>new Promise(r=>setTimeout(r,ms));let ws;
try{let port;for(let i=0;i<100;i++){try{port=(await readFile(profile+'/DevToolsActivePort','utf8')).split('\n')[0];break}catch{await wait(50)}}assert(port);const pages=await(await fetch(`http://127.0.0.1:${port}/json`)).json();ws=new WebSocket(pages.find(p=>p.type==='page').webSocketDebuggerUrl);await new Promise(r=>ws.addEventListener('open',r,{once:true}));let n=0;const pending=new Map();ws.addEventListener('message',e=>{const r=JSON.parse(e.data);if(r.id){pending.get(r.id)?.(r);pending.delete(r.id)}});const call=(method,params={})=>new Promise(resolve=>{const id=++n;pending.set(id,resolve);ws.send(JSON.stringify({id,method,params}))});const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,awaitPromise:true,returnByValue:true});if(r.result.exceptionDetails)throw Error(JSON.stringify(r.result.exceptionDetails));return r.result.result.value};
await call('Runtime.enable');await call('Page.enable');await call('Page.navigate',{url:`http://127.0.0.1:${server.address().port}/`});await wait(400);
await evaluate(`document.querySelector('[data-card-refresh]').click()`);await wait(100);await evaluate(`document.querySelector('[data-card-queue] button').click()`);await wait(100);
assert.deepEqual(await evaluate(`[...document.querySelectorAll('[data-card-media-version="current"]')].map(b=>b.getAttribute('data-card-media-id'))`),fixture.selected);
assert.deepEqual(await evaluate(`[...document.querySelectorAll('[data-card-media-version="approved"]')].map(b=>b.getAttribute('data-card-media-id'))`),fixture.prior);
assert.equal(grants.length,0);
assert(await evaluate(`document.body.textContent.includes('Фото текущего черновика') && document.body.textContent.includes('Фото последней одобренной версии')`));
const expected=[...fixture.selected,...fixture.prior];
for(const mediaId of expected){
 await evaluate(`document.querySelector('[data-card-media-id="${mediaId}"]').click()`);await wait(100);
}
assert.deepEqual(grants,expected);
const hrefs=await evaluate(`[...document.querySelectorAll('[data-card-detail] a')].map(a=>a.href)`);
for(const mediaId of expected)assert(hrefs.includes(fixture.links[mediaId].url));
await call('Emulation.setDeviceMetricsOverride',{width:1200,height:1200,deviceScaleFactor:1,mobile:false});const screenshot=await call('Page.captureScreenshot');await writeFile('.superpowers/sdd/rich-onboarding-second-20261027/manager-browser.png',Buffer.from(screenshot.result.data,'base64'));
await evaluate(`document.querySelector('#logout').click()`);assert.equal(await evaluate(`document.querySelector('[data-card-detail]').textContent`),'');
console.log(JSON.stringify({actualChrome:true,actualManagerApiReplay:true,retainedRows:fixture.retainedRows,currentOrdered:fixture.selected,approvedOrdered:fixture.prior,protectedRequestsOnClick:grants.length,allReturnedLinksInspectable:true,logoutClears:true,limitation:'Synthetic custody adapter URLs; actual manager API grants verified by PostgreSQL integration witness, replayed here into real browser/client/view.'}));
}finally{ws?.close();chrome.kill('SIGTERM');await new Promise(r=>chrome.once('exit',r));server.closeAllConnections();await new Promise(r=>server.close(r));await rm(profile,{recursive:true,force:true})}
