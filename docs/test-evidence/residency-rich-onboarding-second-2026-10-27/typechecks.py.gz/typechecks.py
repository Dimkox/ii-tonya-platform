import subprocess,sys
for name,args in [('db-typecheck',['pnpm','--filter','@ii-tonya/db','typecheck']),('web-typecheck',['pnpm','--filter','@ii-tonya/web','typecheck']),('tests-typecheck',['pnpm','exec','tsc','--noEmit','-p','tsconfig.tests.json'])]:
 result=subprocess.run([sys.executable,'.superpowers/sdd/rich-onboarding-second-20261027/run.py',name+'.log',*args])
 if result.returncode:sys.exit(result.returncode)
